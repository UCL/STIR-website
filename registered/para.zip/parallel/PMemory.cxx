// Memory debugger

// @(#)PMemory.cxx	1.2: 11/15/98

// Modification history:
//
// Jun-Jul 98 -- Alexey Zverovich -- created

#include "PMemory.h"
#include "PEPX.h"

#if defined(P_MEMDEBUG)

#include <map>

struct SMemoryBlock
{
    void       *m_Ptr;
    int         m_Size;
    const char *m_File;
    int         m_Line;
    bool        m_Array;
};

//typedef map<void*, SMemoryBlock*> TAllocationInfo;
class TAllocationInfo: public map<void*, SMemoryBlock*>
{
public:

	TAllocationInfo(void)
	{
		cout << "+++ Constructing TAllocationInfo" << endl;
	};

	~TAllocationInfo(void)
	{
		cout << "+++ Destructing TAllocationInfo" << endl;
	};
};

// PAllocationInfo and PAllocationInfoSema used to be global vars.
// However, that was a bad idea, because global instances of classes that
// used memory allocation routines in their ctors/dtors were depending
// on PAllocationInfo and PAllocationInfoSema being initialised first.
// And an order of initialisation of global variables declared in different
// modules is up to the compiler and no specific order is guaranteed.

// The only remaining constraint on using allocation routines from ctors/dtors
// of globals objects applies only when both of the following conditions are held:
// 1) an object's ctor DOES NOT use memory routines;
// 2) its dtor DOES use memory routines;
// In this case you must call PMemGetNULL() function in the object's ctor (body
// or member initialisation list are fine). If you fail to do so, internal
// data structures of memory debugger might get destroyed earlier than your
// object's destructor will be called, wreaking havoc.

static inline TAllocationInfo& PGetAllocationInfo(void)
{
	static TAllocationInfo PAllocationInfo;
	return PAllocationInfo;
};

#ifdef P_EPX

static inline PEpxSemaphore& PGetAllocationInfoSema(void)
{
	static PEpxSemaphore PAllocationInfoSema(1);
	return PAllocationInfoSema;
};

#endif //P_EPX

template <>
void* PRegisterAllocation<void>(void *Ptr, int Size, const char *File, int Line, bool Array)
{
	assert(Size != 0);

    if (Ptr == NULL)
    {
        cout << "PMem: error: memory allocation failed in file " << File << ", line " << Line << endl;
    }
	else
	{
#ifdef P_EPX
		PGetAllocationInfoSema().Acquire();
#endif //P_EPX

		TAllocationInfo::iterator AllocationInfo = PGetAllocationInfo().find(Ptr);
		if (AllocationInfo != PGetAllocationInfo().end())
		{
			cout << "PMem: error: memory block is already registered (allocated in file " << AllocationInfo->second->m_File << ", line " << AllocationInfo->second->m_Line << ")" << endl;
		}
		else
		{
			SMemoryBlock *Block = new SMemoryBlock;
			assert(Block != NULL);
			Block->m_Ptr = Ptr;
			Block->m_Size = Size;
			Block->m_File = File;
			Block->m_Line = Line;
			Block->m_Array = Array;
			PGetAllocationInfo().insert(pair<void*, SMemoryBlock*>(Ptr, Block));
			Block = NULL;

			cout << "[" << File << ", " << Line << "]: allocated " << Size << " bytes" << endl;
		};

#ifdef P_EPX
		PGetAllocationInfoSema().Release();
#endif //P_EPX
	};

    return Ptr;
};

template<>
void PDeregisterAllocation<void>(void *Ptr, const char *File, int Line, bool Array)
{
    if (Ptr == NULL) return;

#ifdef P_EPX
	PGetAllocationInfoSema().Acquire();
#endif //P_EPX

    TAllocationInfo::iterator AllocationInfo = PGetAllocationInfo().find(Ptr);
    if (AllocationInfo == PGetAllocationInfo().end())
    {
        cout << "PMem: error: attempt to deallocate an unknown block (already deallocated?)   [" << File << ", line " << Line << "]" << endl;
    }
	else
	{
		SMemoryBlock *Block = AllocationInfo->second;
		assert(Block != NULL);

		cout << "[" << File << ", " << Line << "]: deallocated memory block (" << Block->m_Size << " bytes)" << endl;

		if (Array != Block->m_Array)
		{
			cout << "PMem: error: incorrect deallocation function called from " << File << ", line " << Line << endl;
		};

		PGetAllocationInfo().erase(AllocationInfo);

		delete Block;
		Block = NULL;
	};

#ifdef P_EPX
	PGetAllocationInfoSema().Release();
#endif //P_EPX
};

void PReportMemoryLeaks(void)
{
#ifdef P_EPX
	PGetAllocationInfoSema().Acquire();
#endif //P_EPX

    bool Found = false;

    for (TAllocationInfo::iterator AllocationInfo = PGetAllocationInfo().begin();
         AllocationInfo != PGetAllocationInfo().end();
         AllocationInfo++)
    {
        if (!Found)
        {
            cout << "PMem: error: memory leaks detected" << endl;
            cout << "-------------------------------------------------------" << endl;
            Found = true;
        };

        SMemoryBlock *Block = AllocationInfo->second;
        assert(Block != NULL);

        cout << Block->m_Size << " bytes allocated from " << Block->m_File << ", line " << Block->m_Line << endl;
    };

    if (Found)
    {
        cout << "-------------------------------------------------------" << endl;
    };

#ifdef P_EPX
	PGetAllocationInfoSema().Release();
#endif //P_EPX
};

void* PMemGetNULL(void)
{
	PGetAllocationInfo();
#ifdef P_EPX
	PGetAllocationInfoSema();
#endif
	return NULL;
};

#endif	// P_MEMDEBUG
