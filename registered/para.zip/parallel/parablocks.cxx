// @(#)parablocks.cxx	1.6: 99/04/14

// Modification history:
//
//  12 Feb 99 -- Alexey Zverovich -- Optimised performance of most of the operators
//  11 Feb 99 -- Alexey Zverovich -- Added serialisation ctor for PETViewgram
//  15 Nov 98 -- Alexey Zverovich -- * Created serialisation operators for PETScanInfo;
//                                   * Modified operators for PETScannerInfo to use explicit cast for
//                                     Scanner_type enum;
//                                   * Removed scale_factor and changed PETScannerInfo for PETScanInfo
//                                     in all relevant classes;
//   1 Nov 98 -- Alexey Zverovich -- Created serialisation operators for PETSegment, PETSegmentBySinogram
//                                   and PETSegmentByView
//  22 Oct 98 -- Alexey Zverovich -- Added forgotten 'return msg' to all functions

#include "parablocks.h"

PMessage& operator<<(PMessage& msg,  const PETScannerInfo& scanner)
{
  msg << static_cast<int>(scanner.type); //AZ 15/10/98 changed cast style
  msg << scanner.num_rings;
  msg << scanner.num_bins;
  msg << scanner.num_views;
  msg << scanner.ring_radius;
  msg << scanner.FOV_radius;
  msg << scanner.FOV_axial;
  msg << scanner.ring_spacing;
  msg << scanner.bin_size;
  msg << scanner.intrinsic_tilt;

  return msg;
};

PMessage& operator>>(PMessage& msg,  PETScannerInfo& scanner)
{
  { 
    int type;
    msg >> type;
    scanner.type = static_cast<PETScannerInfo::Scanner_type>(type); //AZ 15/10/98 added explicit cast
  }
  msg >> scanner.num_rings;
  msg >> scanner.num_bins;
  msg >> scanner.num_views;
  msg >> scanner.ring_radius;
  msg >> scanner.FOV_radius;
  msg >> scanner.FOV_axial;
  msg >> scanner.ring_spacing;
  msg >> scanner.bin_size;
  msg >> scanner.intrinsic_tilt;

  return msg;
};

PMessage& operator<<(PMessage& msg, const PETSinogram& sino)
{
	msg << sino.segment_num;
	msg << sino.ring_num;
	msg << sino.min_ring_difference;
	msg << sino.max_ring_difference;
	//AZ 15/10/98 msg << sino.scale_factor;
	//AZ 15/10/98 msg << *sino.scanner;
	msg << sino.scan_info; // AZ 15/10/98
	msg << *((Tensor2D<float> *)&sino);

	return msg;
};

PMessage& operator>>(PMessage& msg, PETSinogram& sino)
{
	Tensor2D<float> data;
	int segnum;
	int ringnum;
	PETScanInfo scan_info;
	int mindiff;
	int maxdiff;

	msg >> segnum;
	msg >> ringnum;
	msg >> mindiff;
	msg >> maxdiff;
	msg >> scan_info;
	msg >> data;

//	cout<<"recv'd segnum "<<segnum<<", ringnum "<<ringnum<<endl;
//	cout<<"recv'd width "<<data.get_width()<<", height "<<data.get_height()<<endl;
	sino = PETSinogram(data, scan_info, ringnum, segnum, mindiff, maxdiff); //AZ 15/10/98 changed &pinfo to scan_info

	return msg;
};

PMessage& operator<<(PMessage& msg, const PETViewgram& viewgram)
{
	msg << viewgram.segment_num;
	msg << viewgram.view_num;
	msg << viewgram.min_ring_difference;
	msg << viewgram.max_ring_difference;
	//AZ 15/10/98 msg << viewgram.scale_factor;
	//AZ 15/10/98 msg << *viewgram.scanner;
	msg << viewgram.scan_info; // AZ 15/10/98
	msg << *static_cast<const Tensor2D<float>*>(&viewgram); // AZ 12/02/99 Changed to static_cast

	return msg;
};

PMessage& operator>>(PMessage& msg, PETViewgram& viewgram)
{
// AZ 12/02/99 Commented out
#if 0
	Tensor2D<float> data(0, 0, 0, 0);
	int segnum;
	int viewnum;
	PETScanInfo scan_info;
	int mindiff;
	int maxdiff;

	msg >> segnum;
	msg >> viewnum;
	msg >> mindiff;
	msg >> maxdiff;
	msg >> scan_info;
	// AZ 12/02/99 msg >> data;

#ifdef _DEBUG
//	cout << "recv'd segnum " << segnum << ", viewnum " << viewnum << endl;
//	cout << "recv'd width " << data.get_width() << ", height " << data.get_height() << endl;
#endif
	viewgram = PETViewgram(data, scan_info, viewnum, segnum, mindiff, maxdiff); //AZ 15/10/98 changed &pinfo to scan_info

	msg >> *static_cast<Tensor2D<float>*>(&viewgram); // AZ 12/02/99 Added
#endif // 0

	// AZ 12/02/99 Added
	msg >> viewgram.segment_num;
	msg >> viewgram.view_num;
	msg >> viewgram.min_ring_difference;
	msg >> viewgram.max_ring_difference;
	msg >> viewgram.scan_info;
	msg >> *static_cast<Tensor2D<float>*>(&viewgram);

	return msg;
};

PETViewgram::PETViewgram(PMessage& msg)
{
	msg >> segment_num;
	msg >> view_num;
	msg >> min_ring_difference;
	msg >> max_ring_difference;
	msg >> scan_info;
	msg >> *static_cast<Tensor2D<float>*>(this);
};

PMessage& operator<<(PMessage& msg, const PETPlane& img)
{
	msg << img.plane_num;
	msg << img.origin;
	msg << img.voxel_size;
	//AZ 15/10/98 msg << img.scale_factor;
	msg << *static_cast<const Tensor2D<float>*>(&img); // AZ 12/02/99 Changed to static_cast

	return msg;
};

PMessage& operator>>(PMessage& msg, PETPlane& img)
{
// AZ 12/02/99 Commented out
#if 0
	Tensor2D<float> imgdata;
	msg >> img.plane_num;
	msg >> img.origin;
	msg >> img.voxel_size;
	//AZ 15/10/98 msg >> img.scale_factor;
	msg >> imgdata;
	img = PETPlane(imgdata,img.plane_num, img.origin, img.voxel_size);
#endif // 0

	// AZ 12/02/99 Added
	msg >> img.plane_num;
	msg >> img.origin;
	msg >> img.voxel_size;
	msg >> *static_cast<Tensor2D<float>*>(&img);

	return msg;
};

PMessage& operator<<(PMessage& msg, const Point3D& pt)
{
	msg << pt.x << pt.y << pt.z;

	return msg;
};

PMessage& operator>>(PMessage& msg, Point3D& pt)
{
	msg >> pt.x >> pt.y >> pt.z;

	return msg;
};

PMessage& operator<<(PMessage& msg, const PETImageOfVolume& img)
{
	msg << img.origin;
	msg << img.voxel_size;
	msg << *static_cast<const Tensor3D<float>*>(&img); // AZ 12/02/99 Changed to static_cast

	return msg;
};

PMessage& operator>>(PMessage& msg, PETImageOfVolume& img)
{
// AZ 12/02/99 Commented out
#if 0
	Tensor3D<float> imgdata;
	msg >> img.origin;
	msg >> img.voxel_size;
	msg >> imgdata;
	img = PETImageOfVolume(imgdata, img.origin, img.voxel_size);
#endif // 0

	// AZ 12/02/99 Added
	msg >> img.origin;
	msg >> img.voxel_size;
	msg >> *static_cast<Tensor3D<float>*>(&img);

	return msg;
};

PMessage& operator<<(PMessage& msg, const PETSegment& seg)
{
        msg << seg.segment_num;
	msg << seg.min_ring_difference;
	msg << seg.max_ring_difference;
	msg << seg.scan_info;

        return msg;
};

PMessage& operator>>(PMessage& msg, PETSegment& seg)
{
        // AZ 12/02/99 PETScanInfo scan_info; //AZ 15/10/98

	msg >> seg.segment_num;
	//cout << "segment_num = " << seg.segment_num << endl;
	msg >> seg.min_ring_difference;
	//cout << "min_ring_difference = " << seg.min_ring_difference << endl;
	msg >> seg.max_ring_difference;
	//cout << "max_ring_difference = " << seg.max_ring_difference << endl;
	msg >> seg.scan_info;
	//cout << "read scanner info" << endl;

	return msg;
};

PMessage& operator<<(PMessage& msg, const PETSegmentBySinogram& seg)
{
  //cout << "packing PETSegment" << endl;
  operator<<(msg, *static_cast<const PETSegment*>(&seg));
  //cout << "packed PETSegment" << endl;
  //cout << "packing Tensor3D" << endl;
  operator<<(msg, *static_cast<const Tensor3D<float>*>(&seg));
  //cout << "packed Tensor3D" << endl;
  return msg;
};

PMessage& operator>>(PMessage& msg, PETSegmentBySinogram& seg)
{
  //cout << "unpacking PETSegment" << endl;
  operator>>(msg, *static_cast<PETSegment*>(&seg));
  //cout << "unpacked PETSegment" << endl;
  //cout << "unpacking Tensor3D" << endl;
  operator>>(msg, *static_cast<Tensor3D<float>*>(&seg));
  //cout << "unpacked Tensor3D" << endl;
  return msg;
};

PMessage& operator<<(PMessage& msg, const PETSegmentByView& seg)
{
  //cout << "packing PETSegment" << endl;
  operator<<(msg, *static_cast<const PETSegment*>(&seg));
  //cout << "packed PETSegment" << endl;
  //cout << "packing Tensor3D" << endl;
  operator<<(msg, *static_cast<const Tensor3D<float>*>(&seg));
  //cout << "packed Tensor3D" << endl;
  return msg;
};

PMessage& operator>>(PMessage& msg, PETSegmentByView& seg)
{
  //cout << "unpacking PETSegment" << endl;
  operator>>(msg, *static_cast<PETSegment*>(&seg));
  //cout << "unpacked PETSegment" << endl;
  //cout << "unpacking Tensor3D" << endl;
  operator>>(msg, *static_cast<Tensor3D<float>*>(&seg));
  //cout << "unpacked Tensor3D" << endl;
  return msg;
};

PMessage& operator<<(PMessage& msg, const PETScanInfo& si)
{
  msg << si.num_rings;		/* number of direct planes */
  msg << si.num_bins; 	        /* default number of bins */
  msg << si.num_views;		/* default number of angles */
  msg << si.ring_radius;	/* detector radius in mm */
  msg << si.ring_spacing;	/* plane separation in mm */
  msg << si.bin_size;		/* bin size in mm (spacing of transaxial elements) */
  msg << si.view_offset;        /* angle of first view, in radians */
  msg << static_cast<int>(si.scanner_type);

  return msg;
};

PMessage& operator>>(PMessage& msg, PETScanInfo& si)
{
  msg >> si.num_rings;		/* number of direct planes */
  msg >> si.num_bins; 	        /* default number of bins */
  msg >> si.num_views;		/* default number of angles */
  msg >> si.ring_radius;	/* detector radius in mm */
  msg >> si.ring_spacing;	/* plane separation in mm */
  msg >> si.bin_size;		/* bin size in mm (spacing of transaxial elements) */
  msg >> si.view_offset;        /* angle of first view, in radians */
  int scanner_type;
  msg >> scanner_type;
  si.scanner_type = static_cast<PETScannerInfo::Scanner_type>(scanner_type);

  return msg;
};

