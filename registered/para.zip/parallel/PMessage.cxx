// PMessage class definition
// @(#)PMessage.cxx	1.2: 98/11/15

// Modification history:
//
//  15 Oct 98 -- Alexey Zverovich -- implemented single-threaded communications under EPX
//  14 Oct 98 -- Alexey Zverovich -- changed <assert.h> to "PAssert.h"
// Jun-Jul 98 -- Alexey Zverovich -- created

#include "PAssert.h"
#include "PMessage.h"
#include "PMemory.h"
#include "PInternal.h"

#if defined(P_PVM)

int				PMessage::s_ActiveSendBufId = -1;
int				PMessage::s_ActiveRecvBufId = -1;

#elif defined(P_EPX)

byte*           PMessage::s_RecvBuf(NULL);
int             PMessage::s_RecvBufSize(PEnvironment::DEFAULT_RECV_BUF_SIZE);
int             PMessage::s_NumberOfMessageObjects(0);

#ifdef P_MT_COMM
PEpxSemaphore   PMessage::s_Semaphore(1);
#endif //P_MT_COMM

#endif

PMessage::PMessage(PEnvironment *Env /* = PObject::GetDefaultEnvironment() */)
:   PObject(),
    m_Env(Env),
#if defined(P_PVM)
    m_SendBufId(-1),
    m_RecvBufId(-1)
#elif defined(P_EPX)
    m_SendBuf(NULL),
    m_SendBufSize(0),
    m_SendBufPtr(0),
    m_RecvBuf(NULL),
    m_RecvBufSize(0),
    m_RecvBufReadPtr(0),
    m_RecvBufEndPtr(0)
#ifdef P_MT_COMM
    ,
    m_CurrentSendJob(NULL),
    m_CurrentSendJobSem(1)
#endif //P_MT_COMM
#endif
{
    assert(m_Env != NULL);

#if defined(P_PVM)

    // Allocate send buffer

    m_SendBufId = pvm_mkbuf(m_Env->m_PvmEncoding);
    if (m_SendBufId < 0)
    {
        PError("pvm_mkbuf failed", m_SendBufId);
    };

    PTRACE("allocated send buffer " << m_SendBufId);

#elif defined(P_EPX)

#ifdef P_MT_COMM
    s_Semaphore.Acquire();
#endif //P_MT_COMM
    if (s_NumberOfMessageObjects++ == 0)
    {
        PTRACE("allocating receive buffer");

        assert(s_RecvBuf == NULL);
        assert(s_RecvBufSize > 0);

        s_RecvBuf = PNewArray(byte, s_RecvBufSize);
        assert(s_RecvBuf != NULL);
    };
#ifdef P_MT_COMM
    s_Semaphore.Release();
#endif //P_MT_COMM

    assert(s_RecvBuf != NULL);
    assert(s_RecvBufSize >= PEnvironment::DEFAULT_RECV_BUF_SIZE);

#endif
};

PMessage::~PMessage(void)
{
#if defined(P_PVM)

    // Dispose the send buffer

    if (m_SendBufId >= 0)
    {
        PTRACE("deallocating send buffer " << m_SendBufId);

        int pvm_rc = pvm_freebuf(m_SendBufId);
        if (pvm_rc >= 0)
        {
            if (s_ActiveSendBufId == m_SendBufId)
            {
                s_ActiveSendBufId = -1;
            };
            m_SendBufId = -1;
        }
        else
        {
            PError("pvm_freebuf failed", pvm_rc);
        };
    };

    /* Hmm... comments are really a good idea... now I have no clue why I have
       commented this code out... probably, it is not necessary, but WHY? :-(

    if (m_RecvBufId >= 0)
    {
        PTRACE("deallocating receive buffer " << m_RecvBufId);

        int pvm_rc = pvm_freebuf(m_RecvBufId);
        if (pvm_rc >= 0)
        {
            m_RecvBufId = -1;
        }
        else
        {
            PError("pvm_freebuf failed", pvm_rc);
        };
    };
    */

    // Not sure this is really necessary, but it won't hurt anyway
    if (s_ActiveRecvBufId == m_RecvBufId)
    {
        s_ActiveRecvBufId = -1;
    };

#elif defined(P_EPX)

    Clear();
    ClearReceiveBuffer();
    assert(m_SendBuf == NULL && m_SendBufSize == 0 && m_SendBufPtr == 0);
    assert(m_RecvBuf == NULL && m_RecvBufSize == 0 && m_RecvBufReadPtr == 0 && m_RecvBufEndPtr == 0);

#ifdef P_MT_COMM
    s_Semaphore.Acquire();
#endif //P_MT_COMM
    if (--s_NumberOfMessageObjects == 0)
    {
        PTRACE("deallocating receive buffer");

        assert(s_RecvBuf != NULL);
        PDeleteArray(s_RecvBuf);
        //s_RecvBuf = NULL;
    };
#ifdef P_MT_COMM
    s_Semaphore.Release();
#endif //P_MT_COMM

#endif
};

#if defined(P_PVM)

void PMessage::PvmActivateSendBuffer(void)
{
    assert(m_SendBufId >= 0);

    if (m_SendBufId != s_ActiveSendBufId)
    {
        int pvm_rc = pvm_setsbuf(m_SendBufId);
        if (pvm_rc < 0)
        {
            PError("pvm_setsbuf failed", pvm_rc);
        }
        else
        {
            // Check that nobody is tampering with buffers
            assert(s_ActiveSendBufId == -1 || pvm_rc == s_ActiveSendBufId);
        };

        s_ActiveSendBufId = m_SendBufId;

        PTRACE("Activated send buffer " << m_SendBufId);
    }
    else
    {
        PTRACE("Send buffer " << m_SendBufId << " is already active");
    };
};

void PMessage::PvmActivateRecvBuffer(void)
{
    assert(m_RecvBufId >= 0);

    if (m_RecvBufId != s_ActiveRecvBufId)
    {
        int pvm_rc = pvm_setrbuf(m_RecvBufId);
        if (pvm_rc < 0)
        {
            PError("pvm_setrbuf failed", pvm_rc);
        }
        else
        {
            // Check that nobody is tampering with buffers
            assert(s_ActiveRecvBufId == -1 || pvm_rc == s_ActiveRecvBufId);
        };

        s_ActiveRecvBufId = m_RecvBufId;

        PTRACE("Activated receive buffer " << m_RecvBufId);
    }
    else
    {
        PTRACE("Receive buffer " << m_RecvBufId << " is already active");
    };
};

#elif defined(P_EPX)

void PMessage::WriteData(const void* Data, int Size)
{
    if (Size == 0) return;

    // Check buffer consistency
    assert(m_SendBuf == NULL && m_SendBufSize == 0 && m_SendBufPtr == 0 ||
           m_SendBuf != NULL && m_SendBufSize > 0  && m_SendBufPtr >= 0 && m_SendBufPtr <= m_SendBufSize);

    PTRACE("writing " << Size << " byte(s) of data to send buffer");

    int SendBufSize = (m_SendBufSize != 0) ? m_SendBufSize : DEFAULT_SEND_BUF_SIZE;
    int RequiredBufSize = m_SendBufPtr + Size + sizeof(int); // Synchronize "sizeof(int)" with actual header if changed!

    while (SendBufSize < RequiredBufSize)
    {
        SendBufSize *= 2;
    };

    assert(SendBufSize >= m_SendBufSize); // can't shrink buffer

    if (SendBufSize != m_SendBufSize)
    {
        // Reallocate buffer

        PTRACE("growing send buffer... new size = " << SendBufSize);

        byte *SendBuf = PNewArray(byte, SendBufSize);
        assert(SendBuf != NULL);

        PTRACE("allocated new send buffer");

        if (m_SendBuf != NULL)
        {
            if (m_SendBufPtr != 0)
            {
                memcpy(SendBuf, m_SendBuf, m_SendBufPtr);
                PTRACE("copied data to the new send buffer");
            };

#ifdef P_MT_COMM
            m_CurrentSendJobSem.Acquire();
            if (m_CurrentSendJob != NULL)
            {
                DetachSendJob();
                PTRACE("detached old send buffer");
            };
            m_CurrentSendJobSem.Release();
#endif //P_MT_COMM

            if (m_SendBuf != NULL)
            {
                PDeleteArray(m_SendBuf);
                PTRACE("deleted old send buffer");
            };
        };

        m_SendBuf = SendBuf;
        SendBuf = NULL;
        m_SendBufSize = SendBufSize;
    };

    if (m_SendBufPtr == 0)
    {
        PTRACE("writing message header to the send buffer");
        assert(m_SendBufSize >= sizeof(int));
        ((int*)m_SendBuf)[0] = PEnvironment::TAG_USER_MESSAGE;
        assert(((int*)m_SendBuf)[0] == PEnvironment::TAG_USER_MESSAGE);
        m_SendBufPtr += sizeof(int);
        RequiredBufSize += sizeof(int);
        PTRACE("done writing message header to the send buffer");
        assert(m_SendBufPtr <= m_SendBufSize);
    };

    assert(RequiredBufSize <= SendBufSize);

    PTRACE("writing " << Size << " byte(s) of data to the send buffer at position " << m_SendBufPtr);
    memcpy(m_SendBuf + m_SendBufPtr, Data, Size);

    m_SendBufPtr += Size;

    assert(m_SendBufPtr <= m_SendBufSize);
    assert(((int*)m_SendBuf)[0] == PEnvironment::TAG_USER_MESSAGE); // +++

    PTRACE("finished writing data");
};

void PMessage::ReadData(void* Data, int Size)
{
    assert(Size != 0);

    PTRACE("reading " << Size << " byte(s) of data from the receive buffer at position " << m_RecvBufReadPtr);

    assert(m_RecvBuf != NULL); // received anything?
    assert(m_RecvBufReadPtr + Size <= m_RecvBufEndPtr); // is there enough data?

    memcpy(Data, m_RecvBuf + m_RecvBufReadPtr, Size);
    m_RecvBufReadPtr += Size;

    assert(m_RecvBufReadPtr <= m_RecvBufEndPtr);

    PTRACE("finished reading data");
};

void PMessage::ReadData(void* Data, char Delimiter)
{
    assert(m_RecvBuf != NULL); // received anything?

    PTRACE("reading delimited data from the receive buffer at position " << m_RecvBufReadPtr);

    byte *Src   = m_RecvBuf + m_RecvBufReadPtr;
    byte *Dest  = (byte*)Data;

    for (;;)
    {
        assert(Src < m_RecvBuf + m_RecvBufEndPtr); // end of buffer & still no delimiter?

        if (Src >= m_RecvBuf + m_RecvBufEndPtr)
        {
            // error: delimiter not found
            *Dest = Delimiter;
            break;
        };

        if ((*(Dest++) = *(Src++)) == Delimiter)
        {
            break;
        };
    };

    PTRACE((Src - m_RecvBuf - m_RecvBufReadPtr) << " bytes read");
    m_RecvBufReadPtr = Src - m_RecvBuf;
    assert(m_RecvBufReadPtr <= m_RecvBufEndPtr);
};

#ifdef P_MT_COMM
void PMessage::DetachSendJob(void)
{
    // m_CurrentSendJobSem must be acquired when you call this

    if (m_CurrentSendJob != NULL)
    {
        m_CurrentSendJob->m_Semaphore.Acquire();

        assert(m_CurrentSendJob != NULL); // add another 'if (m_CurrentSendJob != NULL)' around the remaining code if this assertion fails
        assert(m_CurrentSendJob->m_Message == this);

        if (m_CurrentSendJob->m_NumberOfActiveSends != 0)
        {
            PEnvironment::SJobInfo_Send *CurrentSendJob = m_CurrentSendJob;
            m_CurrentSendJob = NULL;
            CurrentSendJob->m_Message = NULL;
            CurrentSendJob->m_Semaphore.Release();
            m_SendBuf = NULL;
            m_SendBufPtr = m_SendBufSize = 0;
            // now a sending thread is responsible for freeing the buffer
        }
        else
        {
            // retain the buffer
            assert(m_CurrentSendJob->m_Buffer == m_SendBuf);
            PEnvironment::SJobInfo_Send *CurrentSendJob = m_CurrentSendJob;
            m_CurrentSendJob = NULL;
            CurrentSendJob->m_Semaphore.Release();
            PDelete(CurrentSendJob);
        };
    };
};
#endif //P_MT_COMM

#endif // P_EPX

#if defined(P_PVM)

#define DECLARE_PVM_WRITE(type, pvm_type, pvm_fn)                                   \
                                                                                    \
    PMessage& PMessage::Write(const type *Items, int Count)                         \
    {                                                                               \
        PvmActivateSendBuffer();                                                    \
                                                                                    \
        PTRACE("writing " << Count << " " # type "(s) to buffer " << m_SendBufId);  \
                                                                                    \
        int pvm_rc = pvm_fn((pvm_type*)Items, Count, 1);                            \
        if (pvm_rc < 0)                                                             \
        {                                                                           \
            PError(#pvm_fn " failed", pvm_rc);                                      \
        };                                                                          \
                                                                                    \
        return (*this);                                                             \
    }

DECLARE_PVM_WRITE(signed char, char, pvm_pkbyte);
DECLARE_PVM_WRITE(unsigned char, char, pvm_pkbyte);
DECLARE_PVM_WRITE(char, char, pvm_pkbyte);
DECLARE_PVM_WRITE(signed short, short, pvm_pkshort);
DECLARE_PVM_WRITE(unsigned short, unsigned short,pvm_pkushort);
DECLARE_PVM_WRITE(signed int, int, pvm_pkint);
DECLARE_PVM_WRITE(unsigned int, unsigned int, pvm_pkuint);
DECLARE_PVM_WRITE(signed long, long, pvm_pklong);
DECLARE_PVM_WRITE(unsigned long, unsigned long, pvm_pkulong);
DECLARE_PVM_WRITE(float, float, pvm_pkfloat);
DECLARE_PVM_WRITE(double, double, pvm_pkdouble);
DECLARE_PVM_WRITE(bool, char, pvm_pkbyte);

PMessage& PMessage::Write(const char* Item)
{
    PvmActivateSendBuffer();

    PTRACE("writing 1 string to buffer " << m_SendBufId);

    int pvm_rc = pvm_pkstr((char*)Item);
    if (pvm_rc < 0)
    {
        PError("pvk_pkstr failed", pvm_rc);
    };

    return (*this);
};

#undef DECLARE_PVM_READ

#define DECLARE_PVM_READ(type, pvm_type, pvm_fn)                                     \
                                                                                     \
    PMessage& PMessage::Read(type *Items, int Count)                                 \
    {                                                                                \
        PvmActivateRecvBuffer();                                                     \
                                                                                     \
        PTRACE("reading " << Count << " " # type "(s) from buffer " << m_RecvBufId); \
                                                                                     \
        int pvm_rc = pvm_fn((pvm_type*)Items, Count, 1);                             \
        if (pvm_rc < 0)                                                              \
        {                                                                            \
            PError(#pvm_fn " failed", pvm_rc);                                       \
        };                                                                           \
                                                                                     \
        return (*this);                                                              \
    }

DECLARE_PVM_READ(signed char, char, pvm_upkbyte);
DECLARE_PVM_READ(unsigned char, char, pvm_upkbyte);
DECLARE_PVM_READ(char, char, pvm_upkbyte);
DECLARE_PVM_READ(signed short, short, pvm_upkshort);
DECLARE_PVM_READ(unsigned short, unsigned short,pvm_upkushort);
DECLARE_PVM_READ(signed int, int, pvm_upkint);
DECLARE_PVM_READ(unsigned int, unsigned int, pvm_upkuint);
DECLARE_PVM_READ(signed long, long, pvm_upklong);
DECLARE_PVM_READ(unsigned long, unsigned long, pvm_upkulong);
DECLARE_PVM_READ(float, float, pvm_upkfloat);
DECLARE_PVM_READ(double, double, pvm_upkdouble);
DECLARE_PVM_READ(bool, char, pvm_upkbyte);

PMessage& PMessage::Read(char* Item)
{
    PvmActivateRecvBuffer();

    PTRACE("reading 1 string from buffer " << m_RecvBufId);

    int pvm_rc = pvm_upkstr(Item);
    if (pvm_rc < 0)
    {
        PError("pvk_upkstr failed", pvm_rc);
    };

    return (*this);
};

#undef DECLARE_PVM_READ

#elif defined(P_EPX)

#define DECLARE_EPX_WRITE(type)                                                     \
                                                                                    \
    PMessage& PMessage::Write(const type *Items, int Count)                         \
    {                                                                               \
        PTRACE("writing " << Count << " " # type "(s) to send buffer");             \
                                                                                    \
        WriteData(Items, sizeof(type) * Count);                                     \
                                                                                    \
        return (*this);                                                             \
    }

DECLARE_EPX_WRITE(signed char);
DECLARE_EPX_WRITE(unsigned char);
DECLARE_EPX_WRITE(char);
DECLARE_EPX_WRITE(signed short);
DECLARE_EPX_WRITE(unsigned short);
DECLARE_EPX_WRITE(signed int);
DECLARE_EPX_WRITE(unsigned int);
DECLARE_EPX_WRITE(signed long);
DECLARE_EPX_WRITE(unsigned long);
DECLARE_EPX_WRITE(float);
DECLARE_EPX_WRITE(double);
DECLARE_EPX_WRITE(bool);

PMessage& PMessage::Write(const char* Item)
{
    PTRACE("writing 1 string to send buffer");

    WriteData(Item, strlen(Item) + 1);

    return (*this);
};

#undef DECLARE_EPX_READ

#define DECLARE_EPX_READ(type)                                                       \
                                                                                     \
    PMessage& PMessage::Read(type *Items, int Count)                                 \
    {                                                                                \
        PTRACE("reading " << Count << " " # type "(s) from receive buffer");         \
                                                                                     \
        ReadData(Items, int(sizeof(type) * Count));                                  \
                                                                                     \
        return (*this);                                                              \
    }

DECLARE_EPX_READ(signed char);
DECLARE_EPX_READ(unsigned char);
DECLARE_EPX_READ(char);
DECLARE_EPX_READ(signed short);
DECLARE_EPX_READ(unsigned short);
DECLARE_EPX_READ(signed int);
DECLARE_EPX_READ(unsigned int);
DECLARE_EPX_READ(signed long);
DECLARE_EPX_READ(unsigned long);
DECLARE_EPX_READ(float);
DECLARE_EPX_READ(double);
DECLARE_EPX_READ(bool);

PMessage& PMessage::Read(char* Item)
{
    PTRACE("reading 1 string from receive buffer");

    ReadData(Item, char(0));

    return (*this);
};

#undef DECLARE_EPX_READ

#endif

void PMessage::Clear(void)
{
    PTRACE("clearing send buffer");

#if defined(P_PVM)

    PvmActivateSendBuffer();

    int pvm_rc = pvm_initsend(m_Env->m_PvmEncoding);
    if (pvm_rc < 0)
    {
        PError("pvm_initsend failed", pvm_rc);
    }
    else
    {
#if !defined(P_PVM_AP)
        assert(pvm_rc == m_SendBufId);
#else
        s_ActiveSendBufId = m_SendBufId = pvm_rc;
#endif
    };

#elif defined(P_EPX)

#ifdef P_MT_COMM
    m_CurrentSendJobSem.Acquire();
    if (m_CurrentSendJob != NULL)
    {
        DetachSendJob();
    };
    m_CurrentSendJobSem.Release();
#endif //P_MT_COMM

    if (m_SendBuf != NULL)
    {
        PDeleteArray(m_SendBuf);
        m_SendBufPtr = m_SendBufSize = 0;
    };

#endif
};

#if defined(P_EPX)

void PMessage::ClearReceiveBuffer(void)
{
    PTRACE("clearing receive buffer");

    if (m_RecvBuf != NULL)
    {
        PDeleteArray(m_RecvBuf);
        m_RecvBufSize = m_RecvBufReadPtr = m_RecvBufEndPtr = 0;
    };

};

#endif

