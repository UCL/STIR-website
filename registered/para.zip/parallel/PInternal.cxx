// Parallel library internal stuff

// @(#)PInternal.cxx	1.2: 11/15/98

// Modification history:
//
// Jun-Jul 98 -- Alexey Zverovich -- created

#include <stdio.h>
#include "PInternal.h"

void PError(const char* msg, int code)
{
    printf("Error: %s, code %d\n", msg, code);
};
