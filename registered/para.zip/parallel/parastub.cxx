// THIS FILE IS NOW OBSOLETE [AZ]

// @(#)parastub.cxx	1.2: 98/11/15

//////////////////////////////////////////////////////////
// Parallel stub code starts here
#include "Para.h"

PEnvironment PEnv;
void main_start();
void PDispatch();

main(int argc, char **argv)
{
	PEnv.Init(argc, argv);

	if (PEnv.AmIMaster())	// master code
	{
		cout<<"Starting master task"<<endl;
		main_start();
	}
	else					// slave code
	{
		cout<<"Starting slave task "<<PEnv.GetMyProcessId()<<endl;
		PDispatch();
	}
};

// Parallel stub code ends - rename main() to main_start()
//////////////////////////////////////////////////////////

