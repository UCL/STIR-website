// PMessageHandlerRegistration class definition
// @(#)PMsgHandlerReg.cxx	1.1: 98/11/15

// Modification history:
//
//   3 Nov 98 -- Alexey Zverovich -- created

#include "PMsgHandlerReg.h"

#ifdef PARALLEL

PMessageHandlerRegistration::THandlers* PMessageHandlerRegistration::s_Handlers = NULL;

PMessageHandlerRegistration::PMessageHandlerRegistration(const int id, const string& name, THandler handler)
:  m_Id(id),
   m_Name(name),
   m_Handler(handler)
{
  //  cerr << "PMessageHandlerRegistration ctor" << endl;
  if (s_Handlers == NULL)
  {
    s_Handlers = new THandlers;
  };
  assert(s_Handlers != NULL);
  if (!s_Handlers->insert(pair<int, PMessageHandlerRegistration*>(id, this)).second)
  {
    cerr << "ERROR: PMessageHandlerRegistration: a handler for function id " << id << " is already registered" << endl;
  };
};

PMessageHandlerRegistration::~PMessageHandlerRegistration(void)
{
  assert(s_Handlers != NULL);
  s_Handlers->erase(m_Id);
  if (s_Handlers->begin() == s_Handlers->end())
  {
    delete s_Handlers;
    s_Handlers = NULL;
  };
};

bool PMessageHandlerRegistration::ProcessMessage(PMessage& msg)
{
  assert(s_Handlers != NULL);
  int id = -1;
  msg >> id;
#ifdef P_TRACE
  cout << "Slave " << PEnv.GetMyProcessId() << " received a message with id " << id;
#endif // P_TRACE
  THandlers::iterator handler = s_Handlers->find(id);
  if (handler == s_Handlers->end())
  {
#ifdef P_TRACE
    cout << " [UNKNOWN ID]" << endl;
#endif // P_TRACE
    cerr << "ERROR: slave " << PEnv.GetMyProcessId() << " recevied a message with unknown function id (" << id << ")" << endl;
    return true; // terminate
  }
  else
  {
#ifdef P_TRACE
    cout << " [" << handler->second->m_Name << "]. Processing..." << endl;
#endif // P_TRACE
    bool result = (handler->second->m_Handler)(msg);
#ifdef P_TRACE
    cout << "Slave " << PEnv.GetMyProcessId() << " finished processing " << handler->second->m_Name << endl;
#endif // P_TRACE
    return result;
  };
};

#endif // PARALLEL
