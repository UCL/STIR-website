// @(#)PDispatch.cxx	1.4: 00/03/23

/*!
 \file PDispatch.cxx

 \brief Task farming support routines

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 If a program uses PDispatch.h, then it
 should not define <tt>main()</tt>; the main program should be
 called \c master_main and have the following signature:
 <tt>int master_main(int argc, char** argv)</tt>. \c master_main
 will only be called in the context of the master (root) process.
 Worker processes will automatically enter the <tt>PDispatch()</tt>
 routine, which accepts tasks from the root node and passes them
 to appropriate handler routines (see PMsgHandlerReg.h for details).

 If \c PARALLEL is not defined, then \c main simply calls \c master_main.

 Skeleton of a program that uses this module:
 \code
 #include "PDispatch.h"

 PEnvironment PEnv;

 // Message handlers and corresponding id's go here

 int master_main(int argc, char** argv)
 {
   // root node code goes here
 };
 \endcode

 Modification history:

 <TT>
   6 Apr 99 -- Alexey Zverovich -- A new dynamic job scheduling scheme has been introduced.\n
   4 Nov 98 -- Alexey Zverovich -- created
 </TT>

*/

#include "PDispatch.h"

#include <vector>
#include <deque>

#ifdef PARALLEL

#ifndef DOXYGEN_SKIP

static bool MsgHandler_QUIT(PMessage&)
{
  return true; // terminate
};

P_REGISTER_MESSAGE_HANDLER(QUIT);

#endif // DOXYGEN_SKIP

/*!
   This is an internal routine which is automatically called
   on the worker processes on program startup. This routine
   accepts incoming messages and processes them by passing them
   to appropriate message handlers.
*/
void PDispatch(void)
{
  bool Terminate = false;

  while (!Terminate)
  {
    PMessage msg;
#ifdef P_NO_TREE_BCAST
    PEnv.ReceiveMessage(PEnv.GetMasterProcessId(), msg);
#else
    PEnv.ReceiveMessage(/*PEnv.GetMasterProcessId(),*/ msg);
#endif //P_NO_TREE_BCAST
    //cout << "Slave " << PEnv.GetMyProcessId() << ": received a job" << endl;
    Terminate = PMessageHandlerRegistration::ProcessMessage(msg);
    //cout << "Slave " << PEnv.GetMyProcessId() << ": idle" << endl;
  };

#ifdef P_TRACE
  cout << "Slave " << PEnv.GetMyProcessId() << " is shutting down" << endl;
#endif // P_TRACE
};

/*!
  \param msg Message containing the job
  \param expectResults <i>currently unused</i>
  \param broadcast \c true if the job should be broadcast to all workers rather than
         assigned to just one; this is useful, for example, to instruct all workers to
         send the results of processing back to the root process.
  \param waitAll \c true if the routine should wait until \e all the workers become free before
         submitting the job, \c false otherwise.
  \param willConfirm indicates whether a worker will send back a confirmation message after processing
         this job.
*/
void PSubmitJob(PMessage& msg, bool /* expectResults */, bool broadcast, bool waitAll, bool willConfirm)
{
#ifdef P_ROUNDROBIN_DISPATCH

  static int nextTask = 1;

#ifdef P_TRACE
  cout << "Master: submitting a job to slave " << nextTask << endl;
#endif // P_TRACE

  PEnv.SendMessage(nextTask, msg);

#ifdef P_TRACE
  cout << "Master: finished submitting job" << endl;
#endif // P_TRACE

  nextTask = nextTask % (PEnv.GetNumberOfTasks() - 1) + 1;

#else // !P_ROUNDROBIN_DISPATCH

  static bool initialised = false;
  static vector<bool> busy(PEnv.GetNumberOfTasks(), false);
  static deque<int> freeNodes;

  if (!initialised)
  {
#ifdef P_INFO
    cout << "Master: initialising message dispatcher" << endl;
#endif // P_INFO

    for (int i = 1; i < PEnv.GetNumberOfTasks(); i++)
    {
      freeNodes.push_back(i);
    };
    initialised = true;
  };

  if (waitAll)
  {
    for (int i = 1; i < PEnv.GetNumberOfTasks(); i++)
    {
      if (busy[i])
      {
#ifdef P_INFO
        cout << "Master: awaiting for confirmation from slave " << i << endl;
#endif // P_INFO
        PMessage confirmation;
        PEnv.ReceiveMessage(i, confirmation);
        unsigned long hdr;
        confirmation >> hdr;
        int slave;
        confirmation >> slave;
        assert(hdr == 0x01020304 && slave == i); //TODO
        busy[i] = false;
        freeNodes.push_back(i);
#ifdef P_INFO
        cout << "Master: received confirmation from slave " << i << endl;
#endif // P_INFO
      };
    };
  };

  if (!broadcast)
  {
    if (freeNodes.empty())
    {
#ifdef P_INFO
      cout << "Master: awaiting for confirmation from any slave" << endl;
#endif // P_INFO
      PMessage confirmation;
      PEnv.ReceiveMessage(confirmation);
      unsigned long hdr;
      confirmation >> hdr;
      int slave;
      confirmation >> slave;
      assert(hdr == 0x01020304); //TODO
      busy[slave] = false;
      freeNodes.push_back(slave);
#ifdef P_INFO
      cout << "Master: received confirmation from slave " << slave << endl;
#endif // P_INFO
    };
    int node = freeNodes.front();
    freeNodes.pop_front();
#ifdef P_INFO
    cout << "Master: sending message to slave " << node << endl;
#endif // P_INFO
    PEnv.SendMessage(node, msg);
#ifdef P_INFO
    cout << "Master: sent message to slave " << node << endl;
#endif // P_INFO
    if (willConfirm)
    {
      busy[node] = true;
    }
    else
    {
      freeNodes.push_back(node);
    };
  }
  else
  {
#ifdef P_INFO
    cout << "Master: broadcasting message" << endl;
#endif // P_INFO
    PEnv.BroadcastMessage(msg);
#ifdef P_INFO
    cout << "Master: finished broadcasting message" << endl;
#endif // P_INFO
    if (willConfirm)
    {
      freeNodes.clear();
      fill(busy.begin(), busy.end(), true);
    };
  };

#endif //P_ROUNDROBIN_DISPATCH
};

#endif // PARALLEL

/*! \brief The parallel \c main routine

   The program that uses PDispatch.cxx should not define \c main, but
   call it \c master_main instead.

   This routine does the following:
   <UL>
   <LI>If \c PARALLEL is not defined, call \c master_main
   <LI>If \c PARALLEL is defined:
    <UL>
    <LI>The parallel environment is initialised
    <LI>On the root process, \c master_main is called, and FNID_QUIT is broadcast when \c master_main finishes;
    <LI>On the worker nodes, \c PDispatch is executed.
    </UL>
   </UL>
*/
int main(int argc, char **argv)
{
#ifdef PARALLEL
  PEnv.Init(argc, argv);

  int result = 0;

  if (PEnv.AmIMaster())
  {
     result = master_main(argc, argv);
     PMessage msg;

#ifdef P_TRACE
     cout << "Master: broadcasting FNID_QUIT" << endl;
#endif // P_TRACE

     msg << FNID_QUIT;
     PEnv.BroadcastMessage(msg);
  }
  else
  {
    PDispatch();
  };

  return result;
#else // !PARALLEL
  return master_main(argc, argv);
#endif // PARALLEL?
};

