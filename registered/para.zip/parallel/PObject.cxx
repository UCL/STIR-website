// PObject class definition

// @(#)PObject.cxx	1.2: 11/15/98

// Modification history:
//
// Jun-Jul 98 -- Alexey Zverovich -- created

#include <stdlib.h>		// For NULL
#include "PObject.h"

PEnvironment *PObject::s_DefaultEnvironment = NULL;
