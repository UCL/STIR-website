// Parallel library testing code
// @(#)PTest.cxx	1.2: 98/11/15

// Modification history:
//
//  14 Oct 98 -- Alexey Zverovich -- changed <assert.h> to "PAssert.h"
// Jun-Jul 98 -- Alexey Zverovich -- created

#include "Para.h"

#include <time.h>
#include <iostream>
#include <stdlib.h>

PEnvironment PEnv;

/***********************************************************************************/

#if defined(P_PVM)
typedef unsigned char byte;
#endif

class PTestMessage
{
public:

    PTestMessage(PEnvironment *Env = PObject::GetDefaultEnvironment());
    virtual ~PTestMessage(void);

    void Clear(void);
    void Generate(void);

    int GetNextAddressee(void); // returns -1 if I'm the final destination (and the original sender)
    int GetDataSize(void);

    bool operator==(const PTestMessage& Message) const;

    friend PMessage& operator<<(PMessage& Stream, const PTestMessage& Message);
    friend PMessage& operator>>(PMessage& Stream, PTestMessage& Message);

protected:

private:

    int  Rand(int LowerBound, int UpperBound); // upper bound not included
    byte RandByte(void);
    void RandByteArray(byte *Array, int Size);

    PEnvironment   *m_Env;

    enum TStatus
    {
        STATUS_NONE,
        STATUS_GENERATED,
        STATUS_RECEIVED
    };

    int             m_RoutingSlipSize;
    int            *m_RoutingSlip;
    int             m_PatternSize;
    byte           *m_Pattern;
    int             m_PatternRepetitions;
    int             m_DataSize;
    byte           *m_Data;
    int             m_Hops;
    TStatus         m_Status;

    enum
    {
        MIN_PATTERN_SIZE        = 4,
        MAX_PATTERN_SIZE        = 4096,
        MIN_PATTERN_REPETITIONS = 1,
        MAX_PATTERN_REPETITIONS = 2048
    };
};

PTestMessage::PTestMessage(PEnvironment *Env /* = PObject::GetDefaultEnvironment() */)
:   m_Env(Env),
    m_RoutingSlipSize(0),
    m_RoutingSlip(NULL),
    m_PatternSize(0),
    m_Pattern(NULL),
    m_PatternRepetitions(0),
    m_DataSize(0),
    m_Data(NULL),
    m_Hops(0),
    m_Status(STATUS_NONE)
{
    assert(m_Env != NULL);
};

PTestMessage::~PTestMessage(void)
{
    Clear();
};

void PTestMessage::Clear(void)
{
    // According to C++ standard 'delete NULL' is fine and does nothing
    PDeleteArray(m_RoutingSlip);
    PDeleteArray(m_Pattern);
    PDeleteArray(m_Data);
    m_RoutingSlipSize = 0;
    m_PatternSize = 0;
    m_PatternRepetitions = 0;
    m_DataSize = 0;
    m_Hops = 0;
    m_Status = STATUS_NONE;
};

void PTestMessage::Generate(void)
{
    Clear();

    // pattern

    m_PatternSize = Rand(MIN_PATTERN_SIZE, MAX_PATTERN_SIZE);
    m_Pattern = PNewArray(byte, m_PatternSize);
    assert(m_Pattern != NULL);
    RandByteArray(m_Pattern, m_PatternSize);
    m_PatternRepetitions = Rand(MIN_PATTERN_REPETITIONS, MAX_PATTERN_REPETITIONS);

    // routing slip

    int NumberOfTasks = m_Env->GetNumberOfTasks();
    int MyProcessId = m_Env->GetMyProcessId();
    m_RoutingSlipSize = NumberOfTasks;
    m_RoutingSlip = PNewArray(int, NumberOfTasks);
    assert(m_RoutingSlip != NULL);
    for (int iTask = 0; iTask < NumberOfTasks - 1; iTask++)
    {
        m_RoutingSlip[iTask] = (iTask < MyProcessId) ? iTask : iTask + 1;
    };
    m_RoutingSlip[NumberOfTasks - 1] = MyProcessId;

    // shuffle routing slip

    for (int i = 0; i < NumberOfTasks; i++)
    {
// Why check that they're not equal? Moreover, the following code doesn't work
// with 2 processes.
#if 0
        int Entry1 = Rand(0, NumberOfTasks - 1);
        int Entry2 = -1;

        if (Entry1 == NumberOfTasks - 2 || (Entry1 != 0 && (rand() & 0x40) != 0))
        {
            Entry2 = Rand(0, Entry1);
        }
        else
        {
            Entry2 = Rand(Entry1 + 1, NumberOfTasks - 1);
        };

        assert(Entry1 >= 0 && Entry1 <= NumberOfTasks - 2 &&
               Entry2 >= 0 && Entry2 <= NumberOfTasks - 2 &&
               Entry1 != Entry2);

#endif
        int Entry1 = Rand(0, NumberOfTasks - 1);
        int Entry2 = Rand(0, NumberOfTasks - 1);

        assert(Entry1 >= 0 && Entry1 <= NumberOfTasks - 2 &&
               Entry2 >= 0 && Entry2 <= NumberOfTasks - 2);

        if (Entry1 != Entry2)
        {
            // swap 'em
            int Tmp = m_RoutingSlip[Entry1];
            m_RoutingSlip[Entry1] = m_RoutingSlip[Entry2];
            m_RoutingSlip[Entry2] = Tmp;
        };
    };

    // ensure that the message will finally arrive back to me
    assert(m_RoutingSlip[m_RoutingSlipSize - 1] == MyProcessId);

    m_Status = STATUS_GENERATED;
};

int PTestMessage::GetNextAddressee(void)
{
    assert(m_Status == STATUS_GENERATED || m_Status == STATUS_RECEIVED);
    assert(m_RoutingSlipSize >= 0);

    if (m_RoutingSlipSize > 0)
    {
        return m_RoutingSlip[0];
    };

    return -1;
};

int PTestMessage::GetDataSize(void)
{
    if (m_Status == STATUS_GENERATED)
    {
        assert(m_PatternSize != 0);
        assert(m_PatternRepetitions != 0);

        return (m_PatternSize * m_PatternRepetitions);
    }
    else if (m_Status == STATUS_RECEIVED)
    {
        assert(m_DataSize != 0);

        return m_DataSize;
    }
    else
    {
        assert(false);
    };

    return -1;
};

bool PTestMessage::operator==(const PTestMessage& Message) const
{
    if (m_Status == STATUS_RECEIVED && Message.m_Status == STATUS_GENERATED)
    {
        return Message.operator==(*this);
    };

    assert(m_Status == STATUS_GENERATED && Message.m_Status == STATUS_RECEIVED);
    assert(Message.m_RoutingSlipSize == 0);
    assert(Message.m_Hops == m_Env->GetNumberOfTasks() - 1);

    if (m_PatternSize * m_PatternRepetitions != Message.m_DataSize) return false;

    assert(Message.m_Data != NULL);
    assert(m_PatternSize != 0);
    assert(m_Pattern != NULL);
    assert(m_PatternRepetitions != 0);

    for (int iRepetition = 0; iRepetition < m_PatternRepetitions; iRepetition++)
    {
        if (memcmp(Message.m_Data + m_PatternSize * iRepetition,
                   m_Pattern,
                   m_PatternSize) != 0) return false;
    };

    return true;
};

int PTestMessage::Rand(int LowerBound, int UpperBound)
{
    assert(LowerBound < UpperBound);

    int Result = rand() * (UpperBound - LowerBound - 1) / RAND_MAX + LowerBound;

    assert(Result >= LowerBound && Result <= UpperBound);

    PTRACE("Generated random value of " << Result << "; range = [" << LowerBound << "..." << UpperBound << ")");

    return Result;
};

byte PTestMessage::RandByte(void)
{
    return (rand() >> 4) & 0xFF;
};

void PTestMessage::RandByteArray(byte *Array, int Size)
{
    for (byte *Ptr = Array; Size != 0; Ptr++, Size--)
    {
        *Ptr = RandByte();
    };
};

PMessage& operator<<(PMessage& Stream, const PTestMessage& Message)
{
    assert(Message.m_Status == PTestMessage::STATUS_GENERATED ||
           Message.m_Status == PTestMessage::STATUS_RECEIVED);

    Stream << (Message.m_RoutingSlipSize - 1);
    Stream.Write(Message.m_RoutingSlip + 1, Message.m_RoutingSlipSize - 1);

    if (Message.m_Status == PTestMessage::STATUS_GENERATED)
    {
        assert(Message.m_PatternSize != 0);
        assert(Message.m_Pattern != NULL);
        assert(Message.m_PatternRepetitions != 0);
        assert(Message.m_Hops == 0);

        Stream << Message.m_Hops;
        Stream << int(Message.m_PatternSize * Message.m_PatternRepetitions);

        for (int iRepetition = 0; iRepetition < Message.m_PatternRepetitions; iRepetition++)
        {
            Stream.Write(Message.m_Pattern, Message.m_PatternSize);
        };
    }
    else if (Message.m_Status == PTestMessage::STATUS_RECEIVED)
    {
        assert(Message.m_DataSize != 0);
        assert(Message.m_Data != NULL);

        Stream << (Message.m_Hops + 1);
        Stream << Message.m_DataSize;
        Stream.Write(Message.m_Data, Message.m_DataSize);
    }
    else
    {
        assert(false);
    };

    return Stream;
};

PMessage& operator>>(PMessage& Stream, PTestMessage& Message)
{
    Message.Clear();

    Stream >> Message.m_RoutingSlipSize;
    if (Message.m_RoutingSlipSize != 0)
    {
        Message.m_RoutingSlip = PNewArray(int, Message.m_RoutingSlipSize);
        assert(Message.m_RoutingSlip != NULL);
        Stream.Read(Message.m_RoutingSlip, Message.m_RoutingSlipSize);
    };
    Stream >> Message.m_Hops;
    Stream >> Message.m_DataSize;
    assert(Message.m_DataSize != 0);
    Message.m_Data = PNewArray(byte, Message.m_DataSize);
    assert(Message.m_Data != NULL);
    Stream.Read(Message.m_Data, Message.m_DataSize);

    Message.m_Status = PTestMessage::STATUS_RECEIVED;

    return Stream;
};

#if 0

int main(int argc, char** argv)
{
    PEnv.Init(argc, argv);

    //AsyncInit(16);

    cout << "Number of hosts: " << PEnv.GetNumberOfHosts() << endl;
    cout << "Number of tasks: " << PEnv.GetNumberOfTasks() << endl;
    cout << (PEnv.IsHomogenous() ? "Homogenous" : "Heterogenous") << " environment" << endl;
    cout << "Master process id: " << PEnv.GetMasterProcessId() << endl;
    cout << "My process id: " << PEnv.GetMyProcessId() << endl;
    cout << "I am " << (PEnv.AmIMaster() ? "the master" : "a slave") << endl;

    if (!PEnv.AmIMaster())
    {
        PMessage Msg;
        Msg << 'a' << 'b' << 'c' << 'd';
        Msg << (const char*)"abcd";//PEnv.GetMyProcessId() << PEnv.GetMyProcessId() * 11;
        Msg << "aecdf";//PEnv.GetMyProcessId() << PEnv.GetMyProcessId() * 11;
        Msg << "cdf";//PEnv.GetMyProcessId() << PEnv.GetMyProcessId() * 11;
        Msg << PEnv.GetMyProcessId() << PEnv.GetMyProcessId() * 11;
        PEnv.SendMessage(PEnv.GetMasterProcessId(), Msg, false);
        Msg << PEnv.GetMyProcessId() << PEnv.GetMyProcessId() * 22;
        PEnv.SendMessage(PEnv.GetMasterProcessId(), Msg);
        Msg.Clear();
    }
    else
    {
#if defined(P_PVM) || defined(P_EPX)
        for (int iTask = 0; iTask < (PEnv.GetNumberOfTasks() - 1) * 2; iTask++)
        {
            PMessage Msg;
            char a, b, c, d;
            PEnv.ReceiveMessage(Msg);
            Msg >> a >> b >> c >> d;
            cout << "{" << a << b << c << d << "}" << endl;
            char str[100];
            Msg >> str;
            cout << "{" << str << "}" << endl;
            Msg >> str;
            cout << "{" << str << "}" << endl;
            Msg >> str;
            cout << "{" << str << "}" << endl;
            int i, j;
            Msg >> i >> j;
            cout << "{" << i << ", " << j << "}" << endl;
        };
#elif defined(P_EPX)
        for (int iTask = 1; iTask < PEnv.GetNumberOfTasks(); iTask++)
        {
            char buf[10240];
            int received = Recv(PEnv.m_TopologyId, iTask, buf, sizeof(buf));
            cout << "[received " << received << " byte(s)]:" << endl;
            cout << "[";
            for (int i = 0; i < received; i++)
            {
                cout << buf[i];
            };
            cout << "]" << endl;
        };
#endif

#if 0 //defined(P_PVM)

        for (int iTask = 0; iTask < (PEnv.GetNumberOfTasks() - 1) * 2; iTask++)
        {
            int i, j;

            pvm_recv(-1, -1);
            pvm_upkint(&i, 1, 1);
            pvm_upkint(&j, 1, 1);

            cout << "master received a message: " << i << ", " << j << endl;
        };

#endif

    };

    //AsyncExit();

    return 0;
};

#endif

//////////////////////////////////////////////////////////////////////////////////////////

#if defined(P_INFO)
#   define PINFO(x) do { cout << x; } while (0)
#else
#   define PINFO(x) do {} while (0)
#endif

int main(int argc, char** argv)
{
    PEnv.Init(argc, argv);

    int             OwnMessagesToBeSent = 20;
    int             OwnMessagesSent = 0;
    int             OwnMessagesReceived = 0;
    PTestMessage  **OwnMessages = PNewArray(PTestMessage*, OwnMessagesToBeSent);
    int             MessagesReceived = 0;
    int             MessagesToBeReceived = OwnMessagesToBeSent * PEnv.GetNumberOfTasks();
    int             OwnDataSent = 0; // size in bytes
    int             TotalDataTransmitted = 0;

    if (PEnv.AmIMaster())
    {
        MessagesToBeReceived += PEnv.GetNumberOfTasks() - 1; // results from slaves
    };

#if 0

    PINFO("Tesing broadcasts" << endl);
    if (PEnv.AmIMaster())
    {
        PMessage Msg;
        Msg << "broadcast test" << PEnv.GetMyProcessId();
        PEnv.BroadcastMessage(Msg);
        for (int iProcess = 0; iProcess < PEnv.GetNumberOfTasks(); iProcess++)
        {
            if (iProcess == PEnv.GetMyProcessId()) continue;
/*
            Msg << "broadcast test" << PEnv.GetMyProcessId();
            PEnv.SendMessage(iProcess, Msg);
*/
            cout << "Master: waiting for a message from process " << iProcess << endl;
            PEnv.ReceiveMessage(iProcess, Msg);
            char Text[128] = "";
            int  i;
            Msg >> Text >> i;
            assert(strcmp(Text, "broadcast test") == 0 &&  i == PEnv.GetMyProcessId());
            cout << Text << " " << i << endl;
        };
    }
    else
    {
        PMessage Msg;
        PEnv.ReceiveMessage(PEnv.GetMasterProcessId(), Msg);
        cout << "Process " << PEnv.GetMyProcessId() << " received a message from the master" << endl;
        char Text[128];
        int  i;
        Msg >> Text >> i;
        Msg << Text << i;
        PEnv.SendMessage(PEnv.GetMasterProcessId(), Msg);
        cout << "Process " << PEnv.GetMyProcessId() << " sent the message back to the master" << endl;
    };
//    PEnv.Barrier();
    cout << "Finished testing broadcasts" << endl;

    PINFO("Tesing multicasts" << endl);
    if (PEnv.AmIMaster())
    {
        PMessage Msg;
        Msg << "multicast test" << PEnv.GetMyProcessId();

        int  MyProcessId        = PEnv.GetMyProcessId();
        int  NumberOfProcessIds = PEnv.GetNumberOfTasks() - 1;
        int *ProcessIds         = PNewArray(int, NumberOfProcessIds);

        for (int iProcess = 0; iProcess < NumberOfProcessIds; iProcess++)
        {
            ProcessIds[iProcess] = ((iProcess < MyProcessId) ? iProcess : (iProcess + 1));
        };

        PEnv.SendMessage(NumberOfProcessIds, ProcessIds, Msg);

        PDeleteArray(ProcessIds);

        for (int iProcess = 0; iProcess < PEnv.GetNumberOfTasks(); iProcess++)
        {
            if (iProcess == PEnv.GetMyProcessId()) continue;
            cout << "Master: waiting for a message from process " << iProcess << endl;
            PEnv.ReceiveMessage(iProcess, Msg);
            char Text[128] = "";
            int  i;
            Msg >> Text >> i;
            assert(strcmp(Text, "multicast test") == 0 &&  i == PEnv.GetMyProcessId());
            cout << Text << " " << i << endl;
        };
    }
    else
    {
        PMessage Msg;
        PEnv.ReceiveMessage(PEnv.GetMasterProcessId(), Msg);
        cout << "Process " << PEnv.GetMyProcessId() << " received a message from the master" << endl;
        char Text[128];
        int  i;
        Msg >> Text >> i;
        Msg << Text << i;
        PEnv.SendMessage(PEnv.GetMasterProcessId(), Msg);
        cout << "Process " << PEnv.GetMyProcessId() << " sent the message back to the master" << endl;
    };
    cout << "Finished testing multicasts" << endl;

#endif

    PMessage Message;

    enum
    {
        MSGTYPE_INVALID,
        MSGTYPE_TEST_DATA,
        MSGTYPE_RESULTS
    };

    time_t StartTime = -1;
    time_t EndTime   = -1;

    if (PEnv.AmIMaster())
    {
        StartTime = time(NULL);
    };

    for (OwnMessagesSent = 0; OwnMessagesSent < OwnMessagesToBeSent; OwnMessagesSent++)
    {
        PTestMessage *Data = PNew(PTestMessage);
        Data->Generate();
        Message << int(MSGTYPE_TEST_DATA) << PEnv.GetMyProcessId() << OwnMessagesSent << *Data;

        PINFO("Process " << PEnv.GetMyProcessId() << " is sending message #" << OwnMessagesSent << " to process " << Data->GetNextAddressee() << "(size: " << Data->GetDataSize() << ")" << endl);

        PEnv.SendMessage(Data->GetNextAddressee(), Message, true /* clear it */);

        OwnDataSent += Data->GetDataSize();

        OwnMessages[OwnMessagesSent] = Data;
        Data = NULL;
    };

    for (MessagesReceived = 0; MessagesReceived < MessagesToBeReceived; MessagesReceived++)
    {
        PEnv.ReceiveMessage(Message);
        int MsgType = MSGTYPE_INVALID;
        Message >> MsgType;
        if (MsgType == MSGTYPE_TEST_DATA)
        {
            int OriginatingProcess  = -1;
            int MessageNumber       = -1;
            PTestMessage Data;

            Message >> OriginatingProcess >> MessageNumber >> Data;

            int NextAddressee       = Data.GetNextAddressee();

            if (NextAddressee == -1)
            {
                assert(OriginatingProcess == PEnv.GetMyProcessId());
                assert(OwnMessages[MessageNumber] != NULL);
                assert(Data == *OwnMessages[MessageNumber]);

                PINFO("Process " << PEnv.GetMyProcessId() << " received its message #" << MessageNumber << " back" << endl);

                PDelete(OwnMessages[MessageNumber]);
                //OwnMessages[MessageNumber] = NULL;

                OwnMessagesReceived++;
            }
            else
            {
                PINFO("Process " << PEnv.GetMyProcessId() << " is relaying message [" << OriginatingProcess << "/" << MessageNumber << "] to process " << NextAddressee << endl);
                Message << int(MSGTYPE_TEST_DATA) << OriginatingProcess << MessageNumber << Data;
                PEnv.SendMessage(NextAddressee, Message, true /* clear it */);
            };
        }
        else if (MsgType == MSGTYPE_RESULTS)
        {
            assert(PEnv.AmIMaster());

            int SlaveProcessId = -1;
            int DataTransmittedBySlave = 0;

            Message >> SlaveProcessId >> DataTransmittedBySlave;

            TotalDataTransmitted += DataTransmittedBySlave * PEnv.GetNumberOfTasks();

            PINFO("The master received results from the slave process " << SlaveProcessId << endl);
        }
        else
        {
            assert(false);
        };
    };

    if (PEnv.AmIMaster())
    {
        EndTime = time(NULL);
    };

    PDeleteArray(OwnMessages);
    //OwnMessages = NULL;

    assert(OwnMessagesReceived == OwnMessagesSent);

    if (!PEnv.AmIMaster())
    {
        Message << int(MSGTYPE_RESULTS) << PEnv.GetMyProcessId() << OwnDataSent;

        PINFO("Process " << PEnv.GetMyProcessId() << " is sending results to the master" << endl);

        PEnv.SendMessage(PEnv.GetMasterProcessId(), Message, true /* clear it */);
    }
    else
    {
        TotalDataTransmitted += OwnDataSent * PEnv.GetNumberOfTasks();
        cout << "----------------------------------------------------------" << endl;
        cout << "Data transmitted (by all processes): " << TotalDataTransmitted << " bytes" << endl;
        cout << "Messages transmitted (by all processes): " << (OwnMessagesToBeSent * PEnv.GetNumberOfTasks()) << endl;
        cout << "Average message size: " << (TotalDataTransmitted / (OwnMessagesToBeSent * PEnv.GetNumberOfTasks()) / PEnv.GetNumberOfTasks()) << " bytes" << endl;
        cout << "Time: " << (EndTime - StartTime) << " seconds" << endl;
        cout << "Speed: " << (TotalDataTransmitted/(EndTime - StartTime)) << " bytes/sec" << endl;
        cout << "----------------------------------------------------------" << endl;
    };

#if 0
    if (PEnv.AmIMaster())
    {
        PTestMessage Data;
        Data.Generate();
        PMessage Message;
        Message << Data;
        PEnv.SendMessage(Data.GetNextAddressee(), Message, true /* clear it */);
        cout << "Message sent by host " << PEnv.GetMyProcessId() << " (master)" << endl;
        PEnv.ReceiveMessage(Message);
        PTestMessage ReceivedData;
        Message >> ReceivedData;
        cout << "Master received the message" << endl;
        assert(ReceivedData.GetNextAddressee() == -1);
        assert(ReceivedData == Data);
    }
    else
    {
        // Relay one incoming message
        PTestMessage Data;
        PMessage Message;
        PEnv.ReceiveMessage(Message);
        Message >> Data;
        Message << Data;
        PEnv.SendMessage(Data.GetNextAddressee(), Message, true /* clear it */);
        cout << "Host " << PEnv.GetMyProcessId() << " relayed the message... exiting" << endl;
    };
#endif

    return 0;
};

/*
4 processes
MIN_PATTERN_SIZE        = 4,
MAX_PATTERN_SIZE        = 4096,
MIN_PATTERN_REPETITIONS = 1,
MAX_PATTERN_REPETITIONS = 2048
OwnMessagesToBeSent     = 8
no trace
no memory debugging
----------------------------------------------------------
Data transmitted (by all processes): 312256256 bytes
Messages transmitted (by all processes): 32
Average message size: 2439502 bytes
Time: 745 seconds
Speed: 419135 bytes/sec
----------------------------------------------------------

  
11 processes
MIN_PATTERN_SIZE        = 4,
MAX_PATTERN_SIZE        = 4096,
MIN_PATTERN_REPETITIONS = 1,
MAX_PATTERN_REPETITIONS = 2048
OwnMessagesToBeSent     = 4
no trace
no memory debugging
----------------------------------------------------------
Data transmitted (by all processes): 631437895 bytes
Messages transmitted (by all processes): 44
Average message size: 1304623 bytes
Time: 15 seconds
Speed: 42095859 bytes/sec
----------------------------------------------------------
*/

/*

TODO:

* "Shared" streams
* Ability to limit amount of memory used by asynchronous communications
  (any call that is about to exceed this limit will be blocked) or, alternatively,
  provide  [EPX]
* It's still not clear if simultaneous operations on the same link are prohibited.
  If so, it'll be necessary to create some sort of additional synchonisation mechanism
  for communication threads [EPX]

*/
