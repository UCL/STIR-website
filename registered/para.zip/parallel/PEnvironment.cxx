// PEnvironment class definition
// @(#)PEnvironment.cxx	1.3: 99/04/14

// Modification history:
//
//  15 Oct 98 -- Alexey Zverovich -- * Implemented single-threaded communications under EPX.
//                                   * Now doesn't call pvm_bufinfo after receiving a message unless
//                                     DEBUG is defined -- to speed up a bit.
//                                   * Removed a call to Select when not necessary -- now runs up to
//                                     40% faster on small messages.
//
//  14 Oct 98 -- Alexey Zverovich -- changed <assert.h> to "PAssert.h"
//   7 Oct 98 -- Alexey Zverovich -- added support for PVM/AP
// Jun-Jul 98 -- Alexey Zverovich -- created

#include "PAssert.h"
#include "PEnvironment.h"
#include "PMemory.h"
#include "PMessage.h"
#include "PInternal.h"

PEnvironment::PEnvironment(void)
:   PObject(),
    m_Homogenous(false),
    m_NumberOfHosts(0),
    m_NumberOfTasks(0),
    m_Initialised(false),
    m_MyTaskId(TaskId_None),
    m_MasterTaskId(TaskId_None)
#if defined(P_PVM)
   ,m_TaskIds(NULL),
    m_PvmEncoding(PvmDataDefault),
    m_GroupName("DefaultProcessGroup"),
    m_MyProcessId(-1)
#elif defined(P_EPX)
   ,m_ReqId(REQID_USER_MESSAGES),
    m_TopologyId(-1),
    m_Links(NULL),
    m_Options(NULL),
    // async i/o
#ifdef P_MT_COMM
    m_AsyncNumberOfThreads(-1),
    m_AsyncThreads(NULL),
    m_AsyncThreadsExitCodes(NULL),
    m_AsyncJobQueue(NULL),
#endif //P_MT_COMM
    m_BufferSizes(NULL)
#ifdef P_MT_COMM
    ,
    m_BufferSizesSem(1)
#endif //P_MT_COMM
#endif
{
    PMemGetNULL(); // please don't touch this... see PMemory.C for explanation

    if (GetDefaultEnvironment() == NULL)
    {
        SetDefaultEnvironment(this);
    };
};

PEnvironment::~PEnvironment(void)
{
    if (m_Initialised)
    {
        if (GetDefaultEnvironment() == this)
        {
            SetDefaultEnvironment(NULL);
        };

#if defined(P_EPX)

        PTRACE("shutting down");

#ifdef P_MT_COMM
        PTRACE("shutting down asynchronous communications subsystem");
        AsyncExit();
        PTRACE("asynchronous communications subsystem stopped");
#endif //P_MT_COMM

//        Barrier();

        if (m_TopologyId >= 0)
        {
            if (m_Links != NULL)
            {
                PDeleteArray(m_Links);
                //m_Links = NULL;
            };
            if (m_Options != NULL)
            {
                PDeleteArray(m_Options);
                //m_Options = NULL;
            };
            FreeClique(m_TopologyId);
            m_TopologyId = -1;
        };

#elif defined(P_PVM)

        PTRACE("shutting down");

#if 0
        if (m_MyTaskId == m_MasterTaskId)
        {
            PTRACE("awaiting for shutdown notifications from slaves");

            for (TTaskId iTask = 1 /* 0 is the master itself */; iTask < m_NumberOfTasks; iTask++)
            {
                TTaskId SlaveTaskId = TaskId_None;

                int pvm_rc = pvm_recv(m_TaskIds[iTask], TAG_SHUTDOWN);
                if (pvm_rc >= 0) pvm_rc = pvm_upkint(&SlaveTaskId, 1, 1);
                assert(SlaveTaskId == m_TaskIds[iTask]);

                PTRACE("got notification from slave " << iTask);

                /*
                PTRACE("killing slave " << iTask);

                pvm_rc = pvm_kill(SlaveTaskId);
                if (pvm_rc < 0)
                {
                    PError("pvm_kill failed", pvm_rc);
                };
                */
            };
        }
        else
        {
            PTRACE("broadcasting shutdown notification");

            int pvm_rc = pvm_initsend(m_PvmEncoding);
            if (pvm_rc >= 0) pvm_rc = pvm_pkint(&m_MyTaskId, 1, 1);
            if (pvm_rc >= 0) pvm_rc = pvm_mcast(m_TaskIds, m_NumberOfTasks, TAG_SHUTDOWN);

            if (pvm_rc < 0) PError("unable to broadcast shutdown message", pvm_rc);

            /*
            PTRACE("entering infinite loop (expecting to be killed by the master)");

            for (;;)
            {
            };
            */
        };
#endif  // 0

        PTRACE("deleting m_TaskIds");

        if (m_TaskIds != NULL)
        {
            PDeleteArray(m_TaskIds);
            //m_TaskIds = NULL;
        };

        PTRACE("awaiting for all other tasks to finish shutdown, leaving the group & calling pvm_exit");
        //PTRACE("synchronising all processes, leaving the group & calling pvm_exit");

/*
        int pvm_rc = pvm_joingroup(m_GroupName);
        if (pvm_rc >= 0) pvm_rc = pvm_barrier(m_GroupName, m_NumberOfTasks);
        if (pvm_rc >= 0) pvm_rc = pvm_lvgroup(m_GroupName);

        if (pvm_rc < 0)
        {
            PError("unable to synchronise", pvm_rc);
        };
*/

        Barrier();
        pvm_lvgroup((char*)m_GroupName);
        pvm_exit();

#elif defined(P_MPI)

        MPI_Finalize();

#endif
        m_Initialised = false;
    };

#if defined(P_MEMDEBUG)

    PReportMemoryLeaks();

#endif
};

inline bool PEnvironment::IsHomogenous(void)
{
    assert(m_Initialised);
    return m_Homogenous;
};

inline int PEnvironment::GetNumberOfHosts(void)
{
    assert(m_Initialised);
    return m_NumberOfHosts;
};

inline int PEnvironment::GetNumberOfTasks(void)
{
    assert(m_Initialised);
    return m_NumberOfHosts;
};

inline int PEnvironment::GetMasterProcessId(void)
{
    assert(m_Initialised);
    return 0;
};

inline int PEnvironment::GetMyProcessId(void)
{
	if (!m_Initialised) return -1;

#if defined(P_PVM)

    return m_MyProcessId;

#else

    return m_MyTaskId;

#endif
};

inline bool PEnvironment::AmIMaster(void)
{
    assert(m_Initialised);

    return (GetMyProcessId() == GetMasterProcessId());
};

void PEnvironment::Barrier(void)
{
    assert(m_Initialised);

#if defined(P_PVM)

    PTRACE("entering barrier");

    int pvm_rc = pvm_barrier((char*)m_GroupName, m_NumberOfTasks);
    if (pvm_rc < 0)
    {
        PError("pvm_barrier failed", pvm_rc);
    };

    PTRACE("exiting from barrier");

#elif defined(P_EPX)

    static int s_BarrierId = 0;

    enum BarrierOperation
    {
        BARRIER_INVALID,    // Invalid operation
        BARRIER_REQUEST,
        BARRIER_REPLY
    };

    // Please make sure the size of this structure is divisible by 4. This will make
    // send/receive operations work faster.
    struct SBarrierData
    {
        BarrierOperation    m_Operation;
        int                 m_BarrierId;
//        byte                m_Reserved0[1];
    };

    int BarrierId = s_BarrierId++;

    if (AmIMaster())
    {
        // Collect barrier notifications from all slaves and then send replies
        // to all of them.

        PTRACE("entering barrier " << BarrierId);

        int ProcessId = -1;

        for (ProcessId = 1; ProcessId < GetNumberOfTasks(); ProcessId++)
        {
            SBarrierData BarrierData = { BARRIER_INVALID };

            int BytesReceived = RecvNode(ProcessId,
                                         REQID_BARRIER_REQUEST,
                                         &BarrierData,
                                         sizeof(BarrierData));

            assert(BytesReceived == sizeof(BarrierData) &&
                   BarrierData.m_Operation == BARRIER_REQUEST &&
                   BarrierData.m_BarrierId == BarrierId);

            PTRACE("received barrier notification from slave " << ProcessId);
        };

        for (ProcessId = 1; ProcessId < GetNumberOfTasks(); ProcessId++)
        {
            SBarrierData BarrierData = { BARRIER_REPLY, BarrierId };

            int epx_rc = SendNode(ProcessId,
                                  REQID_BARRIER_REPLY,
                                  &BarrierData,
                                  sizeof(BarrierData));

            if (epx_rc == sizeof(BarrierData))
            {
                PTRACE("hmm... got strange return code from SendNode()...");
                epx_rc = 0;
            };

            if (epx_rc < 0)
            {
                PError("SendNode failed", epx_rc);
            }
            else
            {
                PTRACE("sent barrier reply to slave " << ProcessId);
            };
        };

        PTRACE("exiting barrier");
    }
    else
    {
        // Send barrier notification to the master and block until received
        // a reply from the master.

        PTRACE("entering barrier " << BarrierId);

        SBarrierData BarrierData = { BARRIER_REQUEST, BarrierId };

        int epx_rc = SendNode(GetMasterProcessId(),
                              REQID_BARRIER_REQUEST,
                              &BarrierData,
                              sizeof(BarrierData));

        if (epx_rc == sizeof(BarrierData))
        {
            PTRACE("hmm... got strange return code from SendNode()...");
            epx_rc = 0;
        };

        PTRACE("sent barrier notification to the master");

        if (epx_rc == 0)
        {
            int BytesReceived = RecvNode(GetMasterProcessId(),
                                         REQID_BARRIER_REPLY,
                                         &BarrierData,
                                         sizeof(BarrierData));

            assert(BytesReceived == sizeof(BarrierData) &&
                   BarrierData.m_Operation == BARRIER_REPLY &&
                   BarrierData.m_BarrierId == BarrierId);

            PTRACE("received barrier reply from the master");
        }
        else
        {
            PError("SendNode failed", epx_rc);
        };

        PTRACE("exiting barrier");
    };

#endif
};

void PEnvironment::SendMessage(int ProcessId, PMessage& Message, bool ClearMessage /* = true */)
{
    //TODO: assert that 'this' == Message's environment
    //Message.Send(ProcessId, ClearMessage);
    assert(ProcessId >= 0 && ProcessId < m_NumberOfTasks);
    assert(ProcessId != GetMyProcessId());

#if defined(P_PVM)

    Message.PvmActivateSendBuffer();

    PTRACE("sending message to " << ProcessId << "(" << m_TaskIds[ProcessId] << ") from buffer " << Message.m_SendBufId);

    int pvm_rc = pvm_send(m_TaskIds[ProcessId], TAG_USER_MESSAGE);
    if (pvm_rc < 0)
    {
        PError("pvm_send failed", pvm_rc);
    };

#elif defined(P_EPX)

#ifdef P_MT_COMM

    AsyncSend(ProcessId, Message);

#else  // !P_MT_COMM

    assert(Message.m_SendBuf != NULL);
    assert(Message.m_SendBufSize != 0);
    assert(Message.m_SendBufPtr != 0);

    EpxSendRawData(ProcessId, Message.m_SendBuf, Message.m_SendBufPtr);

#endif //P_MT_COMM

#endif

    if (ClearMessage)
    {
        Message.Clear();
    };
};

void PEnvironment::SendMessage(int NumberOfProcessIds, const int ProcessIds[], PMessage& Message, bool ClearMessage /* = true */)
{
    //TODO: assert that 'this' == Message's environment
    assert(ProcessIds != NULL);

#if defined(P_PVM)

    Message.PvmActivateSendBuffer();

    PTRACE("sending message from buffer " << Message.m_SendBufId << " to the following processes:");
#if defined(P_TRACE)
    for (int iProcess = 0; iProcess < NumberOfProcessIds; iProcess++)
    {
        PTRACE("   " << ProcessIds[iProcess] << "(" << m_TaskIds[ProcessIds[iProcess]] << ")");
    };
#endif

    TTaskId *TaskIds = PNewArray(TTaskId, NumberOfProcessIds);

    for (int iProcess = 0; iProcess < NumberOfProcessIds; iProcess++)
    {
        int ProcessId = ProcessIds[iProcess];

        assert(ProcessId >= 0 && ProcessId < m_NumberOfTasks);
        assert(ProcessId != GetMyProcessId());

        TaskIds[iProcess] = m_TaskIds[ProcessId];
    };
    
    int pvm_rc = pvm_mcast(TaskIds, NumberOfProcessIds, TAG_USER_MESSAGE);
    if (pvm_rc < 0)
    {
        PError("pvm_mcast failed", pvm_rc);
    };

    PDeleteArray(TaskIds);

#elif defined(P_EPX)

#ifdef P_MT_COMM

    AsyncSend(NumberOfProcessIds, ProcessIds, Message);

#else // !P_MT_COMM

    assert(Message.m_SendBuf != NULL);
    assert(Message.m_SendBufSize != 0);
    assert(Message.m_SendBufPtr != 0);

#ifdef P_NO_TREE_BCAST

    for (int iProcess = 0; iProcess < NumberOfProcessIds; iProcess++)
    {
        int ProcessId = ProcessIds[iProcess];

        assert(ProcessId >= 0 && ProcessId < m_NumberOfTasks);
        assert(ProcessId != GetMyProcessId());

        EpxSendRawData(ProcessId, Message.m_SendBuf, Message.m_SendBufPtr);
    };

#else

    EpxMcastRawData(NumberOfProcessIds, ProcessIds, Message.m_SendBuf, Message.m_SendBufPtr);

#endif //P_NO_TREE_BCAST

#endif //P_MT_COMM

#endif

    if (ClearMessage)
    {
        Message.Clear();
    };
};

void PEnvironment::BroadcastMessage(PMessage& Message, bool ClearMessage /* = true */)
{

#if defined(P_PVM)

    Message.PvmActivateSendBuffer();

    PTRACE("broadcasting message from buffer " << Message.m_SendBufId);

    int pvm_rc = pvm_bcast(const_cast<char*>(m_GroupName), TAG_USER_MESSAGE);
    if (pvm_rc < 0)
    {
        PError("pvm_bcast failed", pvm_rc);
    };

#elif defined(P_EPX)

    int  MyProcessId        = GetMyProcessId();
    int  NumberOfProcessIds = GetNumberOfTasks() - 1;
    int *ProcessIds         = PNewArray(int, NumberOfProcessIds);

    for (int iProcess = 0; iProcess < NumberOfProcessIds; iProcess++)
    {
        ProcessIds[iProcess] = ((iProcess < MyProcessId) ? iProcess : (iProcess + 1));
    };

#ifdef P_MT_COMM

    AsyncSend(NumberOfProcessIds, ProcessIds, Message);

#else // !P_MT_COMM

    SendMessage(NumberOfProcessIds, ProcessIds, Message, false);

#endif //P_MT_COMM

    PDeleteArray(ProcessIds);

#endif

    if (ClearMessage)
    {
        Message.Clear();
    };
};

void PEnvironment::ReceiveMessage(int ProcessId, PMessage& Message)
{
    //TODO: assert that 'this' == Message's environment
    assert(ProcessId == -1 || (ProcessId >= 0 && ProcessId < m_NumberOfTasks));
    assert(ProcessId != GetMyProcessId());

#if defined(P_PVM)

    TTaskId TaskId = (ProcessId == -1) ? -1 : m_TaskIds[ProcessId];

    int RecvBufId = pvm_recv(TaskId, TAG_USER_MESSAGE);
    if (RecvBufId >= 0)
    {
#if 0
        assert(RecvBufId != Message.m_RecvBufId); // This happens sometimes and probably is fine
#endif
        //assert(RecvBufId != PMessage::s_ActiveRecvBufId);
        PMessage::s_ActiveRecvBufId = Message.m_RecvBufId = RecvBufId;
        //Message.PvmActivateRecvBuffer(); // is needed to update PvmActivateRecvBuffer's internal state
    }
    else // error
    {
        PError("pvm_recv failed", RecvBufId);
    };

#ifdef DEBUG
    int Size = -1, Tag = -1, SourceTaskId = -1;
    int pvm_rc = pvm_bufinfo(RecvBufId, &Size, &Tag, &SourceTaskId);
    if (pvm_rc < 0)
    {
        PTRACE("received a message");
        PError("pvm_bufinfo failed", pvm_rc);
    }
    else
    {
        PTRACE("received a message with tag " << Tag << " from " << SourceTaskId << "; size: " << Size << " bytes");
    };
#endif

#elif defined(P_EPX)

    assert(PMessage::s_RecvBuf != NULL);
    assert(PMessage::s_RecvBufSize >= DEFAULT_RECV_BUF_SIZE);

    bool ReceivedMessage = false;

#ifndef P_NO_TREE_BCAST

    int  ForwardToCount = 0;
    int* ForwardTo      = NULL;

#endif //P_NO_TREE_BCAST

    while (!ReceivedMessage)
    {
        PTRACE("waiting for a message to arrive (blocked)");

        int SelectResult = ProcessId;

        if (ProcessId == -1)
        {
            /* TODO: this implementation gives priority to processes with smaller
             *       IDs and IMHO this is a Bad Thing (tm).
             */

            SelectResult = SelectList(m_NumberOfTasks, m_Options);
        };

        if (SelectResult >= 0 && SelectResult < m_NumberOfTasks)
        {
            if (ProcessId == -1)
            {
                PTRACE("something has arrived from process " << SelectResult << "... reading...");
            }
            else
            {
                PTRACE("waiting for data from process " << SelectResult << "...");
            };

#ifdef P_MT_COMM
            PMessage::s_Semaphore.Acquire();
#endif //P_MT_COMM

            int BytesRead = ::Recv(m_TopologyId, SelectResult, PMessage::s_RecvBuf, PMessage::s_RecvBufSize);

            assert(BytesRead != 0); // 0 (means "0 bytes received") should never be returned from Recv

            if (BytesRead >= 0)
            {
                assert(BytesRead >= sizeof(int) + 1); // header is 1 int + at least 1 byte of data

                switch (((int*)PMessage::s_RecvBuf)[0])
                {
                case TAG_USER_MESSAGE:

                    PTRACE("received user message, size: " << (BytesRead - sizeof(int)));

                    Message.ClearReceiveBuffer();
                    assert(Message.m_RecvBuf == NULL);
                    Message.m_RecvBufSize = Message.m_RecvBufEndPtr = BytesRead - sizeof(int);
                    Message.m_RecvBufReadPtr = 0;
                    Message.m_RecvBuf = PNewArray(byte, Message.m_RecvBufSize);
                    assert(Message.m_RecvBuf != NULL);
                    memcpy(Message.m_RecvBuf, PMessage::s_RecvBuf + sizeof(int), Message.m_RecvBufEndPtr);
//                    Message.m_RecvBuf = PMessage::s_RecvBuf + sizeof(int);

#ifndef P_NO_TREE_BCAST

                    if (ForwardToCount != 0)
                    {
//                        cerr << GetMyProcessId() << ": forwarding a message to " << ForwardToCount << " other nodes" << endl;
                        EpxMcastRawData(ForwardToCount, ForwardTo, PMessage::s_RecvBuf, BytesRead);
                        PDeleteArray(ForwardTo);
                        ForwardToCount = 0;
//                        cerr << GetMyProcessId() << ": finished forwarding a message" << endl;
                    };

#endif //P_NO_TREE_BCAST

                    ReceivedMessage = true;
                    break;
                
                case TAG_MSG_SIZE_INFO:

                    {
                        assert(BytesRead == 2 * sizeof(int)); // a message of this type should contain 2 ints
                        int RecvBufSize = ((int*)PMessage::s_RecvBuf)[1];
                        PTRACE("got 'grow receive buffer' message (suggested size is " << RecvBufSize << ", current buffer size is " << PMessage::s_RecvBufSize << ")");
                        if (RecvBufSize > PMessage::s_RecvBufSize)
                        {
                            PTRACE("growing receive buffer");

                            //byte *RecvBuf = new byte[RecvBufSize];
                            byte *RecvBuf = PNewArray(byte, RecvBufSize);
                            assert(RecvBuf != NULL);
                            PDeleteArray(PMessage::s_RecvBuf);
                            PMessage::s_RecvBuf = RecvBuf;
                            PMessage::s_RecvBufSize = RecvBufSize;
                            RecvBuf = NULL;
                        }
                        else
                        {
                            PTRACE("ignoring the message, receive buffer is already large enough");
                        };
                        PTRACE("still no user data, waiting again");
                    };
                    break;

#ifndef P_NO_TREE_BCAST

                case TAG_USER_MULTICAST:

                    PTRACE("received multicast request");
//                    cerr << GetMyProcessId() << ": received multicast request" << endl;

                    assert((BytesRead % sizeof(int)) == 0);
                    assert(ForwardToCount == 0 && ForwardTo == NULL);

                    ForwardToCount = (BytesRead / sizeof(int)) - 1;
                    assert(ForwardToCount != 0);
                    ForwardTo = PNewArray(int, ForwardToCount);
                    memcpy(ForwardTo, ((int*)PMessage::s_RecvBuf) + 1, ForwardToCount * sizeof(int));

                    PTRACE("still no user data, waiting again");

                    break;

#endif //P_NO_TREE_BCAST
                
                default:

                    assert(false); // unknown message type;
                    break;
                };
            }
            else
            {
                PError("Recv failed", BytesRead);
                ReceivedMessage = true; // to exit from the loop
            };

#ifdef P_MT_COMM
            PMessage::s_Semaphore.Release();
#endif //P_MT_COMM

        }
        else
        {
            PError("Select[List] failed", SelectResult);
            ReceivedMessage = true; // to exit from the loop
        };
    };

//    cerr << GetMyProcessId() << ": got a message" << endl;

#endif
};

inline void PEnvironment::ReceiveMessage(PMessage& Message)
{
    ReceiveMessage(-1, Message);
};

#if 0
void PEnvironment::ForwardMessage(int ProcessId, PMessage& Message, bool ClearMessage /* = true */)
{
    PTRACE("forwarding a message to process " << ProcessId);
#if defined(P_EPX)
    assert(Message.m_RecvBuf != NULL && Message.m_RecvBufEndPtr != 0); // can't forward an empty message
    Message.Clear();
    assert(Message.m_SendBuf == NULL && Message.m_SendBufPtr == 0 && Message.m_SendBufSize == 0);
    Message.WriteData(Message.m_RecvBuf, Message.m_RecvBufEndPtr);
    SendMessage(ProcessId, Message, ClearMessage);
#elif defined(P_PVM)
#endif
};
#endif // 0

void PEnvironment::Init(int argc, char** argv)
{
    assert(!m_Initialised);

    // Get task ids of myself and the master

#if defined(P_EPX)

    m_MyTaskId = GET_ROOT()->ProcRoot->MyProcId;
    m_MasterTaskId = 0;

#elif defined(P_PVM)

    TTaskId MyTaskId = pvm_mytid();
    if (MyTaskId >= 0)
    {
        m_MyTaskId = MyTaskId;
        PTRACE("got my task id");
    }
    else // error
    {
        PError("pvm_mytid failed", MyTaskId);
    };

    TTaskId ParentTaskId = pvm_parent();
    if (ParentTaskId == PvmNoParent)
    {
        m_MasterTaskId = m_MyTaskId;
        PTRACE("i have no parent -- i'm the master");
    }
    else if (ParentTaskId >= 0)
    {
        m_MasterTaskId = ParentTaskId;
        PTRACE("i have a parent -- i'm a slave");
    }
    else
    {
        PError("pvm_parent failed", ParentTaskId);
    };

#elif defined(P_MPI)

    int mpi_rc = MPI_Init(&argc, &argv);
    if (mpi_rc != MPI_SUCCESS)
    {
        PError("MPI_Init failed", mpi_rc);
    };

    TTaskId MyTaskId = TaskId_None;
    mpi_rc = MPI_Comm_rank(MPI_COMM_WORLD, &MyTaskId);
    if (mpi_rc == MPI_SUCCESS)
    {
        m_MyTaskId = MyTaskId;
    }
    else
    {
        PError("MPI_Comm_rank failed", mpi_rc);
    };

    m_MasterTaskId = 0;

#endif

    // Initialise m_Homogenous and m_NumberOfHosts

#if defined(P_EPX)

    m_Homogenous = true;
    m_NumberOfHosts = GET_ROOT()->ProcRoot->nProcs;

#elif defined(P_PVM)

    int                 nTasks = -1;    // Number of tasks
    int                 nHosts = -1;    // Number of hosts in this VM
    int                 nArchs = -1;    // Number of different architectures in this VM
    struct pvmhostinfo *Hosts  = NULL;  // Info about all hosts in this VM
    int                 result = PvmOk;

#if !defined(P_PVM_AP)

    result = pvm_config(&nHosts, &nArchs, &Hosts);

    if (result >= 0)
    {
        assert(nArchs >= 1);
        m_Homogenous = (nArchs == 1);
        assert(nHosts >= 1);
        m_NumberOfHosts = nHosts;
        PTRACE("number of hosts: " << nHosts);
        PTRACE("number of different architectures: " << nArchs);
    }
    else    // error
    {
        PError("pvm_config failed", result);
        m_Homogenous = false;   // assume heterogenous
        m_NumberOfHosts = 0;    // stands for "unknown"
    };

#else  // defined(P_PVM_AP)

    const   MAX_AP_NODES               = 1 << 10;  // 1024 nodes max
    TTaskId TaskIdsForAP[MAX_AP_NODES] = { m_MasterTaskId };

    if (m_MyTaskId == m_MasterTaskId)
    {
        PTRACE("trying to guess the number of nodes");

        int nAPNodes = 0;

        for (nAPNodes = 1; nAPNodes < MAX_AP_NODES; nAPNodes++)
        {
            nTasks = pvm_spawn(argv[0],             // Program name
                               NULL,                // Arguments
                               PvmTaskDefault,      // Any machine
                               NULL,
                               nAPNodes - 1,
                               TaskIdsForAP + 1          // Item 0 is for the master
                              );

            if (nTasks >= 0) break;
        };

        if (nAPNodes < MAX_AP_NODES)
        {
            assert(nTasks == nAPNodes - 1);
            PTRACE("Guessed the number of nodes to be " << nAPNodes);
        }
        else
        {
            PError("Unable to guess the number of nodes", 0);
        };

        m_NumberOfHosts = nHosts = m_NumberOfTasks = nAPNodes;
        m_Homogenous = true;
    };

#endif // defined(P_PVM_AP)?

    m_PvmEncoding = (m_Homogenous ? PvmDataRaw : PvmDataDefault);

#elif defined(P_MPI)

    m_Homogenous = false;   // Is it possible to detect if we're running in homogenous
                            // or heterogenous environment under MPI? -- AZ

    int nTasks = -1;

    mpi_rc = MPI_Comm_size(MPI_COMM_WORLD, &nTasks);
    if (mpi_rc == MPI_SUCCESS)
    {
        m_NumberOfHosts = nTasks;
    }
    else
    {
        PError("MPI_Comm_size failed", mpi_rc);
    };

#endif

    // Launch processes

#if defined(P_PVM)

    assert(m_MyTaskId != TaskId_None);

    if (m_MyTaskId == m_MasterTaskId)
    {
        m_MyProcessId = 0;  // I'm the master

        TTaskId *TaskIds = PNewArray(TTaskId, m_NumberOfHosts);
        assert(TaskIds != NULL);   //TODO: better error checking -- AZ

#if !defined(P_PVM_AP)

        char **Args = PNewArray(char*, argc);
        assert(Args != NULL);   //TODO: better error checking -- AZ

        for (int iArg = 0; iArg < argc - 1; iArg++)
        {
            Args[iArg] = argv[iArg + 1];
        };
        Args[argc - 1] = NULL; // Terminator

        TaskIds[0] = m_MyTaskId;

        PTRACE("launching slaves (" << (m_NumberOfHosts - 1) << ")");

        nTasks = pvm_spawn(argv[0],             // Program name
                           Args,                // Arguments
                           PvmTaskDefault,      // Any machine
                           NULL,
                           m_NumberOfHosts - 1, // Master is already running
                           TaskIds + 1          // Item 0 is for the master
                          );
        if (nTasks >= 0)
        {
            if (nTasks != m_NumberOfHosts - 1)
            {
                PError("pvm_spawn failed to start some processes", PvmOk);
            };
            m_NumberOfTasks = nTasks + 1;
            assert(m_TaskIds == NULL);
            PTRACE("launched all slaves successfully");
        }
        else
        {
            PError("pvm_spawn failed", nTasks);
        };

        PDeleteArray(Args);

#else
        memcpy(TaskIds, TaskIdsForAP, sizeof(TaskIds[0]) * m_NumberOfHosts);
#endif

        m_TaskIds = TaskIds;

        // Send task ids to slaves

        PTRACE("broadcasting task ids");

        int BufId = pvm_initsend(m_PvmEncoding);
        if (BufId < 0)
        {
            PError("pvm_initsend failed", BufId);
        };

        int pvm_rc = pvm_pkint(&m_NumberOfTasks, 1, 1);
        if (pvm_rc >= 0) pvm_rc = pvm_pkint(m_TaskIds, m_NumberOfTasks, 1);
        if (pvm_rc >= 0) pvm_rc = pvm_mcast(m_TaskIds + 1, m_NumberOfTasks - 1, TAG_TASK_IDS);

        if (pvm_rc < 0) PError("unable to broadcast task ids", pvm_rc);

    }
    else
    {
        // Receive task ids from the master

        PTRACE("receiving task ids from the master");

        int pvm_rc = pvm_recv(m_MasterTaskId, TAG_TASK_IDS);
        if (pvm_rc >= 0) pvm_rc = pvm_upkint(&m_NumberOfTasks, 1, 1);
        m_TaskIds = PNewArray(TTaskId, m_NumberOfTasks);
        if (pvm_rc >= 0) pvm_rc = pvm_upkint(m_TaskIds, m_NumberOfTasks, 1);
        assert(m_TaskIds[0] == m_MasterTaskId);

#if defined(P_PVM_AP)
        m_NumberOfHosts = m_NumberOfTasks;
        m_Homogenous = true;
#endif

        if (pvm_rc < 0) PError("failed to receive task ids", pvm_rc);

        // Find myself in the task list

        for (int iTask = 1 /* 0 is the master */; iTask < m_NumberOfTasks; iTask++)
        {
            if (m_TaskIds[iTask] == m_MyTaskId)
            {
                m_MyProcessId = iTask;
                break;
            };
        };
    };

    // Join the group

    int pvm_rc = pvm_joingroup((char*)m_GroupName);
    if (pvm_rc < 0)
    {
        PError("pvm_joingroup failed", pvm_rc);
    };

#else

    m_NumberOfTasks = m_NumberOfHosts;

#endif

    // Establish links

#if defined(P_EPX)

    int TopologyId = MakeClique(m_ReqId, m_NumberOfHosts,
                                MINSLICE, MAXSLICE,
                                MINSLICE, MAXSLICE,
                                MINSLICE, MAXSLICE);

    if (TopologyId >= 0)
    {
        CliqueData_t *CliqueData = GetClique_Data(TopologyId);

        assert(CliqueData != NULL && CliqueData->status == CLIQUE_IN &&
               CliqueData->id == m_MyTaskId && CliqueData->size == m_NumberOfHosts);

        m_TopologyId = TopologyId;

        m_Links = PNewArray(LinkCB_t*, m_NumberOfHosts);
        assert(m_Links != NULL);

        for (int iLink = 0; iLink < m_NumberOfHosts; iLink++)
        {
            if (iLink != m_MyTaskId)
            {
                int epx_rc = 0;

                m_Links[iLink] = GetLinkCB(TopologyId, iLink, &epx_rc);
                if (m_Links[iLink] == NULL)
                {
                    PError("GetLinkCB failed", epx_rc);
                };
            }
            else
            {
                m_Links[iLink] = NULL; // no link to myself
            };
        };

        m_Options = PNewArray(Option_t, m_NumberOfHosts);
        assert(m_Options != NULL);

        for (int iOption = 0; iOption < m_NumberOfHosts; iOption++)
        {
            m_Options[iOption] = ReceiveOption_B(m_Links[iOption], iOption != m_MyTaskId);
        };

    }
    else
    {
        PError("MakeClique failed", TopologyId);
    };

#endif

    assert(m_MyTaskId != TaskId_None);

#if defined(P_PVM)

    assert(m_MyProcessId >= 0);

#endif

    m_Initialised = true;

    // Initialise async comms

#if defined(P_EPX)

#ifdef P_MT_COMM

    PTRACE("initialising asynchronous communications subsystem");
    AsyncInit((m_NumberOfTasks - 1) > MAX_COMM_THREADS ? MAX_COMM_THREADS : (m_NumberOfTasks - 1));
    PTRACE("asynchronous communications subsystem started");

#endif //P_MT_COMM

    PTRACE("initialising receive buffer sizes");
#ifdef P_MT_COMM
    m_BufferSizesSem.Acquire();
#endif //P_MT_COMM
    m_BufferSizes = PNewArray(int, m_NumberOfTasks);
    assert(m_BufferSizes != NULL);
    for (int iTask = 0; iTask < GetNumberOfTasks(); iTask++)
    {
        m_BufferSizes[iTask] = DEFAULT_RECV_BUF_SIZE;
    };
#ifdef P_MT_COMM
    m_BufferSizesSem.Release();
#endif //P_MT_COMM
    PTRACE("finished initialisation of receive buffer sizes");

#endif

    // Synchronise all processes

#if defined(P_PVM)

    PTRACE("awaiting for all other tasks to finish initialisation");
    Barrier();

#endif

    PTRACE("finished initialisation");
};

#if defined(P_EPX)

void PEnvironment::EpxSendRawData(int ProcessId, void *Data, int DataSize)
{
    assert(ProcessId >= 0 && ProcessId < m_NumberOfTasks);
    assert(ProcessId != GetMyProcessId());
    assert(Data != NULL);
    assert(DataSize > 0);

//    cout << "Process " << GetMyProcessId() << " is using link to process " << ProcessId << endl;

    bool SendBufSizeMessage = false;

#ifdef P_MT_COMM
    m_BufferSizesSem.Acquire();
#endif //P_MT_COMM
    if (m_BufferSizes[ProcessId] < DataSize)
    {
        while (m_BufferSizes[ProcessId] < DataSize)
        {
            m_BufferSizes[ProcessId] *= 2;
        };
        SendBufSizeMessage = true;
    };
#ifdef P_MT_COMM
    m_BufferSizesSem.Release();
#endif //P_MT_COMM

    int Result = 0;

    if (SendBufSizeMessage)
    {
        PTRACE("sending 'please increase recv buffer' message");

        int    BufSizeMessage[] = { TAG_MSG_SIZE_INFO, m_BufferSizes[ProcessId] };

        Result = ::Send(m_TopologyId, ProcessId, BufSizeMessage, sizeof(BufSizeMessage));

        if (Result >= 0)
        {
            assert(Result == sizeof(BufSizeMessage));
        }
        else
        {
            PError("Send failed", Result);
        };

        PTRACE("'increase recv buffer' message sent");
    };

    /*
    //TODO: remove this
    {
        cout << "[[";
        int i;
        for (i = 0; i < DataSize; i++)
        {
            cout << ((char*)Data)[i];
        };
        cout << "]]" << endl;
    };
    */
#ifndef P_NO_TREE_BCAST

    assert(((int*)Data)[0] == TAG_USER_MESSAGE ||
           ((int*)Data)[0] == TAG_USER_MULTICAST);

#else

    assert(((int*)Data)[0] == TAG_USER_MESSAGE);

#endif //P_NO_TREE_BCAST
    
    Result = ::Send(m_TopologyId, ProcessId, Data, DataSize);

    if (Result >= 0)
    {
        if (Result != DataSize)
        {
            PTRACE("Send failed: number of bytes sent: " << Result << " out of " << DataSize);
        };
        assert(Result == DataSize);
    }
    else
    {
        PError("Send failed", Result);
    };

//    cout << "Process " << GetMyProcessId() << " is not using link to process " << ProcessId << " anymore" << endl;
};

#ifndef P_NO_TREE_BCAST

static int CompareProcessIds(const void* arg1, const void* arg2)
{
    return (*reinterpret_cast<int*>(arg1) - *reinterpret_cast<int*>(arg2));
};

void PEnvironment::EpxMcastRawData(int NumberOfProcessIds, const int ProcessIds[], void* Data, int DataSize)
{
    assert(NumberOfProcessIds > 0);
    if (NumberOfProcessIds == 1)
    {
//        cerr << "[" << GetMyProcessId() << " --> " << ProcessIds[0] << "]" << endl;
        EpxSendRawData(ProcessIds[0], Data, DataSize);
    }
    else
    {
        int* SortedProcessIds = PNewArray(int, NumberOfProcessIds);

        memcpy(SortedProcessIds, ProcessIds, NumberOfProcessIds * sizeof(int));

        qsort(SortedProcessIds, NumberOfProcessIds, sizeof(int), CompareProcessIds);

        int ProcessIdsInFirstHalf  = NumberOfProcessIds / 2;
        int ProcessIdsInSecondHalf = NumberOfProcessIds - ProcessIdsInFirstHalf;

        int Child1 = SortedProcessIds[0];
        int Child2 = SortedProcessIds[ProcessIdsInFirstHalf];

        SortedProcessIds[0] = TAG_USER_MULTICAST;
        SortedProcessIds[ProcessIdsInFirstHalf] = TAG_USER_MULTICAST;

//        cerr << "[" << GetMyProcessId() << " --> " << Child2 << " & " << Child1 << "]" << endl;

        if (ProcessIdsInSecondHalf > 1)
        {
            EpxSendRawData(Child2, SortedProcessIds + ProcessIdsInFirstHalf, ProcessIdsInSecondHalf * sizeof(int));
        };
        EpxSendRawData(Child2, Data, DataSize);

        if (ProcessIdsInFirstHalf > 1)
        {
            EpxSendRawData(Child1, SortedProcessIds, ProcessIdsInFirstHalf * sizeof(int));
        };
        EpxSendRawData(Child1, Data, DataSize);

        PDeleteArray(SortedProcessIds);
    };

//    cerr << "[" << GetMyProcessId() << " done with multicast]" << endl;
};

#endif //P_NO_TREE_BCAST

/***********************************************************************************/

#ifdef P_MT_COMM

int PAsyncThreadProc(void *Arg)
{
    assert(Arg != NULL);
    return ((PEnvironment*)Arg)->AsyncProcessJobQueue();
};

// Returns true if shutting down, false otherwise
bool PEnvironment::AsyncProcessJob(SAsyncJob *Job)
{
    assert(Job != NULL);
    assert(Job->m_JobType == SAsyncJob::JOB_SHUTDOWN ||
           Job->m_JobType == SAsyncJob::JOB_SEND);

    switch (Job->m_JobType)
    {
    case SAsyncJob::JOB_SHUTDOWN:

        PTRACE("comm thread: got JOB_SHUTDOWN, terminating");
        return true;


    case SAsyncJob::JOB_SEND:

        {
            PTRACE("comm thread: got JOB_SEND, sending data");
            assert(Job->m_Send.m_Env != NULL);
            assert(Job->m_Send.m_Info != NULL);
            assert(Job->m_Send.m_Info->m_NumberOfActiveSends >= 1);

            Job->m_Send.m_Env->EpxSendRawData(Job->m_Send.m_Dest,
                                              Job->m_Send.m_Info->m_Buffer,
                                              Job->m_Send.m_Size);

            Job->m_Send.m_Info->m_Semaphore.Acquire();

            assert(Job->m_Send.m_Info->m_NumberOfActiveSends >= 1);

            if (--Job->m_Send.m_Info->m_NumberOfActiveSends == 0 &&
                Job->m_Send.m_Info->m_Message == NULL)
            {
                SJobInfo_Send *SendInfo = Job->m_Send.m_Info;
                Job->m_Send.m_Info = NULL;
                PDeleteArray(SendInfo->m_Buffer);
                //SendInfo->m_Buffer = NULL;
                SendInfo->m_Semaphore.Release();
                PDelete(SendInfo);
                //SendInfo = NULL;
            }
            else
            {
                Job->m_Send.m_Info->m_Semaphore.Release();
            };

            PTRACE("comm thread: finished sending data");
            break;
        };

    default:

        assert(false);  // unknown job type
        break;
    };

    return false;
};

int PEnvironment::AsyncProcessJobQueue(void)
{
    SAsyncJobQueue* Queue = m_AsyncJobQueue;
    assert(Queue != NULL);

    PTRACE("communication thread started");

    Queue->m_JobListAccessSem.Acquire();
    if (Queue->m_ThreadsRunning++ == 0)
    {
        Queue->m_ShutdownSem.Acquire();
        PTRACE("comm thread: shutdown disabled");
    };
    Queue->m_JobListAccessSem.Release();

    bool Shutdown = false;

    while (!Shutdown)
    {
        Queue->m_JobListNotEmptySem.Acquire(); // will block until there is a job available for processing
        Queue->m_JobListAccessSem.Acquire();
        SAsyncJob *Job = (SAsyncJob*)RemHead(&(Queue->m_JobList));
        assert(Job != NULL);
        assert(Job->m_JobType == SAsyncJob::JOB_SHUTDOWN ||
               Job->m_JobType == SAsyncJob::JOB_SEND);
        PTRACE("offset of Node_t: " << ((char*)(Node_t*)Job - (char*)Job));
        PTRACE("offset of Node_t.Next: " << ((char*)&(Job->Next) - (char*)Job));
        PTRACE("offset of Node_t.Prev: " << ((char*)&(Job->Prev) - (char*)Job));
        PTRACE("offset of m_JobType: " << ((char*)&(Job->m_JobType) - (char*)Job));
        assert(Job->m_JobType != SAsyncJob::JOB_SEND ||
               ((int*)(Job->m_Send.m_Info->m_Buffer))[0] == TAG_USER_MESSAGE);
//+++        assert(Job->m_Environment != NULL);
        Queue->m_JobListAccessSem.Release();
        PTRACE("comm thread: got a job, processing");
        Shutdown = /*Job->m_Environment->*/AsyncProcessJob(Job);
        PDelete(Job);
        //Job = NULL;
        PTRACE("comm thread: finished processing job");
    };

    Queue->m_JobListAccessSem.Acquire();
    if (--Queue->m_ThreadsRunning == 0)
    {
        Queue->m_ShutdownSem.Release();
        PTRACE("comm thread: shutdown enabled");
    };
    Queue->m_JobListAccessSem.Release();

    PTRACE("communication thread terminated");

    return 0;
};

// Job will be delete'd by a comm thread
void PEnvironment::AsyncSubmitJob(SAsyncJob *Job)
{
    assert(m_AsyncJobQueue != NULL);
    assert(Job != NULL);
    assert(Job->m_JobType == SAsyncJob::JOB_SHUTDOWN ||
           Job->m_JobType == SAsyncJob::JOB_SEND);
    assert((void*)(Node_t*)Job == (void*)Job); // check that Node_t is indeed located in the very beginning of SAsyncJob
    PTRACE("comm: submitting job");
    assert(Job->m_JobType != SAsyncJob::JOB_SEND ||
           ((int*)(Job->m_Send.m_Info->m_Buffer))[0] == TAG_USER_MESSAGE); // +++
    m_AsyncJobQueue->m_JobListAccessSem.Acquire();
    AddTail(&(m_AsyncJobQueue->m_JobList), Job);
    m_AsyncJobQueue->m_JobListAccessSem.Release();
    m_AsyncJobQueue->m_JobListNotEmptySem.Release();
};

void PEnvironment::AsyncInit(int NumberOfThreads)
{
    assert(m_AsyncJobQueue == NULL); // already initialised?
    assert(NumberOfThreads > 0);

    PTRACE("initialising asynchronous communications");
    PTRACE("launching " << NumberOfThreads << " threads");

    m_AsyncNumberOfThreads = NumberOfThreads;

    m_AsyncJobQueue = PNew(SAsyncJobQueue);
    m_AsyncThreads = PNewArray(Thread_t*, m_AsyncNumberOfThreads);
    m_AsyncThreadsExitCodes = PNewArray(int, m_AsyncNumberOfThreads);
    assert(m_AsyncJobQueue != NULL &&
           m_AsyncThreads != NULL &&
           m_AsyncThreadsExitCodes != NULL);

    for (int Thread = 0; Thread < m_AsyncNumberOfThreads; Thread++)
    {
        // Note the 3rd arg... it is declared in <epx/thread.h> as 'int(*)()',
        // man page says that it's 'int(*)(void*)', but G++ complains about both
        // versions... must also be a bug in G++... <sigh>
        m_AsyncThreads[Thread] = CreateThread(NULL,
                                              MIN_STACKSIZE,
                                              //PAsyncThreadProc,
                                              //(int(*)()){AsyncThreadProc,
                                              PAsyncThreadProc,
                                              m_AsyncThreadsExitCodes + Thread,
                                              this/*(void*)m_AsyncJobQueue*/);

        assert(m_AsyncThreads[Thread] != NULL);
    };

    PTRACE("finished initialising asynchronous communications");
};

void PEnvironment::AsyncExit(void)
{
    assert(m_AsyncJobQueue != NULL); // initialised?

    PTRACE("shutting down asynchronous communications");

    int Thread;

    for (Thread = 0; Thread < m_AsyncNumberOfThreads; Thread++)
    {
        SAsyncJob *Job = PNew(SAsyncJob);
        assert(Job != NULL);
        Job->m_JobType = SAsyncJob::JOB_SHUTDOWN;
        AsyncSubmitJob(Job);
        Job = NULL;
    };

    for (Thread = 0; Thread < m_AsyncNumberOfThreads; Thread++)
    {
        int ThreadResult = 0;

        WaitThread(m_AsyncThreads[Thread], &ThreadResult);

        assert(ThreadResult == 0 && m_AsyncThreadsExitCodes[Thread] == 0);
    };
    
    m_AsyncJobQueue->m_ShutdownSem.Acquire();

    PDeleteArray(m_AsyncThreadsExitCodes);
    PDeleteArray(m_AsyncThreads);
    PDelete(m_AsyncJobQueue);
    PDeleteArray(m_BufferSizes);
    /*
    m_AsyncThreadsExitCodes = NULL;
    m_AsyncThreads = NULL;
    m_AsyncJobQueue = NULL;
    m_BufferSizes = NULL;
    */

    PTRACE("finished shutting down asynchronous communications");
};

void PEnvironment::AsyncSend(int NumberOfProcessIds, const int ProcessIds[], PMessage& Message)
{
    assert(Message.m_SendBuf != NULL);
    assert(Message.m_SendBufSize != 0);
    assert(Message.m_SendBufPtr != 0);

    Message.m_CurrentSendJobSem.Acquire();
    for (int iProcess = 0; iProcess < NumberOfProcessIds; iProcess++)
    {
        if (Message.m_CurrentSendJob != NULL)
        {
            assert(Message.m_CurrentSendJob->m_Message == &Message);
            assert(Message.m_CurrentSendJob->m_Buffer == Message.m_SendBuf);
            Message.m_CurrentSendJob->m_Semaphore.Acquire();
            Message.m_CurrentSendJob->m_NumberOfActiveSends++;
            Message.m_CurrentSendJob->m_Semaphore.Release();
        }
        else
        {
            SJobInfo_Send *CurrentSendJob = PNew(SJobInfo_Send);
            CurrentSendJob->m_Semaphore.Acquire();
            CurrentSendJob->m_Buffer = Message.m_SendBuf;
            CurrentSendJob->m_NumberOfActiveSends = 1;
            CurrentSendJob->m_Message = &Message;
            Message.m_CurrentSendJob = CurrentSendJob;
            CurrentSendJob->m_Semaphore.Release();
            CurrentSendJob = NULL;
        };

        SAsyncJob *Job = PNew(SAsyncJob);
        assert(Job != NULL);
        Job->m_JobType = SAsyncJob::JOB_SEND;
        Job->m_Send.m_Dest = ProcessIds[iProcess];
        Job->m_Send.m_Info = Message.m_CurrentSendJob;
        Job->m_Send.m_Size = Message.m_SendBufPtr;
        Job->m_Send.m_Env  = this;
        assert(((int*)(Job->m_Send.m_Info->m_Buffer))[0] == TAG_USER_MESSAGE); // +++
        AsyncSubmitJob(Job);
        Job = NULL;
    };
    Message.m_CurrentSendJobSem.Release();
};

void PEnvironment::AsyncSend(int ProcessId, PMessage& Message)
{
    AsyncSend(1, &ProcessId, Message);
};

#endif //P_MT_COMM

#endif // P_EPX

