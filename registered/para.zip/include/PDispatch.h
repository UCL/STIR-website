// @(#)PDispatch.h	1.4: 00/03/23

/*!
 \file PDispatch.h

 \brief Task farming support routines

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 Modification history:

 <TT>
   4 Nov 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PDISPATCH_H__
#define __PDISPATCH_H__

//! Declaration of the main routine that a parallel program must define.
int master_main(int argc, char **argv);

#ifdef PARALLEL

#include "PMsgHandlerReg.h"

//! Message dispatcher
void PDispatch(void);

//! Adds a task to the pool of jobs
void PSubmitJob(PMessage& msg, bool /* expectResults */, bool broadcast, bool waitAll, bool willConfirm);

/*! \brief Function identifier for the termination signal message

 The following function identifiers are reserved:
 <UL>
 <LI>  0-99  -- reserved for internal use
 <LI>100-199 -- MLE algorithms
 </UL>
 Please make sure that when you define function identifiers, they don't
 fall into any of these ranges
*/
const int FNID_QUIT = 0;

#endif // PARALLEL

#endif // __PDISPATCH_H__
