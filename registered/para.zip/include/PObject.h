// @(#)PObject.h	1.4: 00/03/23

/*!
 \file PObject.h

 \brief PObject class declaration

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __POBJECT_H__
#define __POBJECT_H__

#include "PCheckTarget.h"

class PEnvironment;

/*! \brief PObject is the root of the hierarchy of parallelisation library classes
*/

class PObject
{
public:

    //! Virtual dtor
    virtual ~PObject(void);

    //! Returns a pointer to the current default instance of PEnvironment
    static PEnvironment* GetDefaultEnvironment(void);

protected:

    //! Default ctor
    PObject(void);

    //! Set the default enviroment
    static void SetDefaultEnvironment(PEnvironment *Env);

private:

    PObject(const PObject&);            // Not defined
    PObject& operator=(const PObject&); // Not defined

    static PEnvironment *s_DefaultEnvironment;

};

#include "PObject.inl"

#endif	//__POBJECT_H__
