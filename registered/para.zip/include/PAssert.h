// @(#)PAssert.h	1.3: 00/03/23

/*!
 \file PAssert.h

 \brief Assertions for the parallel library

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.3

 If DEBUG is defined, standard header <assert.h> is included, otherwise
 a do-nothing assert() macro is defined.

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
 14 Oct 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PASSERT_H__
#define __PASSERT_H__

#ifndef DOXYGEN_SKIP
#  ifdef DEBUG
#   include <assert.h>
#else // !DEBUG
#   ifndef assert
#       define assert(expr) (void(0))
#   endif // assert
#  endif // DEBUG
#endif // DOXYGEN_SKIP

#endif	//__PASSERT_H__
