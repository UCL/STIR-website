// @(#)PEPX.h	1.4: 00/03/23

/*!
 \file PEPX.h

 \brief EPX-specific stuff

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PEPX_H__
#define __PEPX_H__

#include "PCheckTarget.h"

#ifdef P_EPX

extern "C"
{
#	include <virt_top.h>
#	include <epx/root.h>
#	include <epx/list.h>
#	include <epx/sem.h>
#	include <epx/select.h>
#	include <epx/sem.h>
};

#include "PObject.h"

// EPX semaphore (also used as a mutex)

class PEpxSemaphore: public PObject
{
public:

    PEpxSemaphore(int Count = 1);
    virtual ~PEpxSemaphore(void);

    void Acquire(void);
    void Release(void);
    bool TryAcquire(void);

protected:

private:

    PEpxSemaphore(const PEpxSemaphore&);            // Not defined
    PEpxSemaphore& operator=(const PEpxSemaphore&); // Not defined

    Semaphore_t m_Semaphore;

};

#endif	//P_EPX

#include "PEPX.inl"

#endif	//__PEPX_H__
