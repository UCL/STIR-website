// Check that a valid target has been defined

// @(#)PCheckTarget.h	1.3: 00/03/02

// Modification history:
//
// Jun-Jul 98 -- Alexey Zverovich -- created

#ifndef __PCHECKTARGET_H__
#define __PCHECKTARGET_H__

#if !defined(P_EPX) && !defined(P_PVM) && !defined(P_MPI)
#	error None of the P_EPX, P_PVM or P_MPI macros defined
#endif

#if	defined(P_EPX) && defined(P_PVM) || \
	defined(P_EPX) && defined(P_MPI) || \
	defined(P_PVM) && defined(P_MPI)
#	error Multiple targets defined (check P_EPX, P_PVM and P_MPI macros)
#endif

#if defined(P_MPI)
#	error MPI is not supported yet
#endif

#endif	//__PCHECKTARGET_H__
