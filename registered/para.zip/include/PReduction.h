// @(#)PReduction.h	1.4: 00/03/23

/*!
 \file PReduction.h

 \brief Support for reduction operators

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
  10 Feb 99 -- Alexey Zverovich -- made member functions public\n
  28 Jan 99 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PREDUCTION_H__
#define __PREDUCTION_H__

#include "PCheckTarget.h"

/*! \brief A binary reduction operator

    An overloaded <tt>operator()(lhs, rhs)</tt> applies the
    reduction operator to both arguments, storing the results
    in the first one.
*/

template <class T>
class BinaryReductionOperator
{
public:

  /*! \brief Applies the reduction operator

      \param lhs First argument
      \param rhs Second argument
      \retval lhs contains the result of the operator
  */
  virtual void operator()(T& lhs, const T& rhs) const = 0;
};

/*! \brief Addition operator
*/

template <class T>
class ReductionAdd: public BinaryReductionOperator<T>
{
public:

  /*! \brief Applies the operator

      Does <tt>lhs += rhs</tt>
  */
  virtual void operator()(T& lhs, const T& rhs) const
  {
    lhs += rhs;
  };
};

#endif //__PREDUCTION_H__

