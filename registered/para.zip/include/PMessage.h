// @(#)PMessage.h	1.4: 00/03/23

/*!
 \file PMessage.h

 \brief PMessage class declaration

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
  15 Oct 98 -- Alexey Zverovich -- implemented single-threaded communications under EPX\n
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PMESSAGE_H__
#define __PMESSAGE_H__

#include "PCheckTarget.h"
#include "PObject.h"
#include "PEnvironment.h"

/*! \brief PMessage class represents a single message that will be sent to another
           process or processes or has been received from another process.

   It has an iostream-like inteface and has built-in serialisation operators for
   all standard C++ types, including bool, and arrays of standard types. Overloaded
   <tt>operator<<</tt> and <tt>operator>></tt> are required for serialisation of
   user-defined datatypes
   (including classes). PMessage maintains separate "send" and "receive" buffers for
   every message. If a low-level library being used supports data buffering, the
   parallelisation library does not introduce an additional level of buffering.
*/

class PMessage: public PObject
{

public:

    //! Constructor - create an instance of the class
    PMessage(PEnvironment *Env = PObject::GetDefaultEnvironment());

    //! Destructor - destroy the instance
    virtual ~PMessage(void);

    // Output

    //! Append an array to the send buffer
    PMessage& Write(const signed char *Items, int Count);    // pkbyte
    //! Append an array to the send buffer
    PMessage& Write(const unsigned char *Items, int Count);  // pkbyte
    //! Append an array to the send buffer
    PMessage& Write(const char *Items, int Count);           // pkbyte
    //! Append an array to the send buffer
    PMessage& Write(const signed short *Items, int Count);   // pkshort
    //! Append an array to the send buffer
    PMessage& Write(const unsigned short *Items, int Count); // pkushort
    //! Append an array to the send buffer
    PMessage& Write(const signed int *Items, int Count);     // pkint
    //! Append an array to the send buffer
    PMessage& Write(const unsigned int *Items, int Count);   // pkuint
    //! Append an array to the send buffer
    PMessage& Write(const signed long *Items, int Count);    // pklong
    //! Append an array to the send buffer
    PMessage& Write(const unsigned long *Items, int Count);  // pkulong
    //! Append an array to the send buffer
    PMessage& Write(const float *Items, int Count);          // pkfloat
    //! Append an array to the send buffer
    PMessage& Write(const double *Items, int Count);         // pkdouble
    //! Append an array to the send buffer
    PMessage& Write(const bool *Items, int Count);           // pkbyte

    //! Append a single item to the send buffer
    PMessage& Write(signed char Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(unsigned char Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(char Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(signed short Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(unsigned short Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(signed int Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(unsigned int Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(signed long Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(unsigned long Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(float Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(double Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& Write(bool Item) { return Write(&Item, 1); };

    //! Append a C string to the send buffer
    PMessage& Write(const char* Item);
    //! Append a C string to the send buffer
    PMessage& Write(const unsigned char* Item) { return Write((const char*)Item); };
    //! Append a C string to the send buffer
    PMessage& Write(const signed char* Item) { return Write((const char*)Item); };

    //! Append a single item to the send buffer
    PMessage& operator<<(signed char Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(unsigned char Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(char Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(signed short Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(unsigned short Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(signed int Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(unsigned int Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(signed long Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(unsigned long Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(float Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(double Item) { return Write(&Item, 1); };
    //! Append a single item to the send buffer
    PMessage& operator<<(bool Item) { return Write(&Item, 1); };

    //! Append a C string to the send buffer
    PMessage& operator<<(const char* Item) { return Write(Item); };
    //! Append a C string to the send buffer
    PMessage& operator<<(const unsigned char* Item) { return Write(Item); };
    //! Append a C string to the send buffer
    PMessage& operator<<(const signed char* Item) { return Write(Item); };

    // Input

    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(signed char *Items, int Count);    // upkbyte
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(unsigned char *Items, int Count);  // upkbyte
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(char *Items, int Count);           // upkbyte
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(signed short *Items, int Count);   // upkshort
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(unsigned short *Items, int Count); // upkushort
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(signed int *Items, int Count);     // upkint
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(unsigned int *Items, int Count);   // upkuint
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(signed long *Items, int Count);    // upklong
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(unsigned long *Items, int Count);  // upkulong
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(float *Items, int Count);          // upkfloat
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(double *Items, int Count);         // upkdouble
    //! Read an array from the receive buffer and adjust buffer position
    PMessage& Read(bool *Items, int Count);           // upkbyte

    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(signed char& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(unsigned char& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(char& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(signed short& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(unsigned short& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(signed int& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(unsigned int& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(signed long& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(unsigned long& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(float& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(double& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& Read(bool& Item) { return Read(&Item, 1); };

    //! Read a C string from the receive buffer and adjust buffer position
    PMessage& Read(char* Item);
    //! Read a C string from the receive buffer and adjust buffer position
    PMessage& Read(unsigned char* Item) { return Read((char*)Item); };
    //! Read a C string from the receive buffer and adjust buffer position
    PMessage& Read(signed char* Item) { return Read((char*)Item); };

    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(signed char& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(unsigned char& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(char& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(signed short& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(unsigned short& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(signed int& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(unsigned int& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(signed long& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(unsigned long& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(float& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(double& Item) { return Read(&Item, 1); };
    //! Read a single item from the receive buffer and adjust buffer position
    PMessage& operator>>(bool& Item) { return Read(&Item, 1); };

    //! Read a C string from the receive buffer and adjust buffer position
    PMessage& operator>>(char* Item) { return Read(Item); };
    //! Read a C string from the receive buffer and adjust buffer position
    PMessage& operator>>(unsigned char* Item) { return Read(Item); };
    //! Read a C string from the receive buffer and adjust buffer position
    PMessage& operator>>(signed char* Item) { return Read(Item); };

    //! Clear the send buffer
    void Clear(void);

protected:

private:

    friend PEnvironment;

    PMessage(const PMessage&);              // Not defined
    PMessage& operator=(const PMessage&);   // Not defined

#if defined(P_PVM)

    void PvmActivateSendBuffer(void);
    void PvmActivateRecvBuffer(void);

#elif defined(P_EPX)

    void WriteData(const void* Data, int Size);
    void ReadData(void* Data, int Size);
    void ReadData(void* Data, char Delimiter);

#ifdef P_MT_COMM
    void DetachSendJob(void);
#endif //P_MT_COMM

#endif

    PEnvironment *m_Env;

#if defined(P_PVM)

    int           m_SendBufId;
    int           m_RecvBufId;
    static int    s_ActiveSendBufId;
    static int    s_ActiveRecvBufId;

#elif defined(P_EPX)

    byte         *m_SendBuf;
    int           m_SendBufSize;
    int           m_SendBufPtr;

    static byte            *s_RecvBuf;  // global receive buffer: data is received here and then copied to a PMessage's buffer
    static int              s_RecvBufSize; // its size
    static int              s_NumberOfMessageObjects; // number of PMessage instances currently alive
#ifdef P_MT_COMM
    static PEpxSemaphore    s_Semaphore; // mutex to protect the static data above
#endif //P_MT_COMM

    byte         *m_RecvBuf;
    int           m_RecvBufSize;
    int           m_RecvBufReadPtr;
    int           m_RecvBufEndPtr;

    enum
    {
        DEFAULT_SEND_BUF_SIZE = 0x1000 // Default send buffer size (4K). Please make it a power of 2
    };

#ifdef P_MT_COMM
    PEnvironment::SJobInfo_Send    *m_CurrentSendJob;
    PEpxSemaphore                   m_CurrentSendJobSem;
#endif //P_MT_COMM

#endif

#if defined (P_EPX)

    void ClearReceiveBuffer(void); // clear receive buffer

#endif

};

#endif	//__PMESSAGE_H__
