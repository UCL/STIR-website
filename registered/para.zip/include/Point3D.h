#ifndef __POINT3D_H__
#define __POINT3D_H__
/*
// @(#)Point3D.h	1.4: 00/03/02
*/
struct Point3D
{ Real x,y,z;

  Point3D(Real x_v, Real y_v, Real z_v)
    : x(x_v), y(y_v), z(z_v)
    {}
};
#endif
