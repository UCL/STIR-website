// @(#)PEnvironment.h	1.6: 00/03/23

/*!
 \file PEnvironment.h

 \brief PEnvironment class declaration

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.6

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
 04 Oct 99  -- Alexey Zverovich -- fixed const-ness of the parameters in PEnvironment::Reduce\n
 28 Jan 99  -- Alexey Zverovich -- Added support for reduction operators\n
 15 Oct 98  -- Alexey Zverovich -- implemented single-threaded communications under EPX\n
 15 Oct 98  -- Alexey Zverovich -- increased default receive buffer size to 64K\n
 14 Oct 98  -- Alexey Zverovich -- Added PEnvironment::ForwardMessage -- commented out; PVM version n/a\n
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PENVIRONMENT_H__
#define __PENVIRONMENT_H__

#include "PCheckTarget.h"
#include "PObject.h"
#include "PEPX.h"
#include "PPVM.h"
#include "PReduction.h"

class PMessage;

/*! \brief PEnvironment class represents the parallel programming environment.

   PEnvironment  supports the master-slave approach as well as the SPMD model
   as different reconstruction algorithms have different communication requirements.
   It contains all functions which are required by the high-level algorithms and
   that will be supported independently of a low-level message-passing interface used.

   It is responsible for:
   <UL>
  <LI> parallel environment initialisation/shutdown (for the master-slave approach as
       well as for the SPMD model depending on the parallel programming model chosen
       for a particular  algorithm);
  <LI> a selected subset of global communication operators (like broadcast and reduction);
  <LI> point-to-point communications;
  <LI> assignment and supervision of slave tasks in the master-slave approach;
  <LI> synchronisation/barrier operations;
  <LI> obtaining information about the parallel environment.
   </UL>

   A process can create at most one instance of PEnvironment.
   Optimal assignment of parallel processes with regard to an optimal
   implementation of the communication is not a task of the parallelisation library -
   here we rely on vendor-specific optimized communication libraries for PVM or MPI
   adapted to the physically available communication topology.

   Every process in a parallel environment has its own unique process identifier
  (Process id). Process id is an integer in the range [0, N-1], where N is the number
   of processes running. It should not be confused with 'task ids', which are
   platform-specific and are not guaranteed to be of any particular type.
   Task ids are hidden inside the parallelisation library and are not exposed to
   the application: the library facilitates automatic mapping of process ids to
   task ids and vice versa.

*/

class PEnvironment: public PObject
{

public:

#if defined(P_EPX) || defined(P_PVM) || defined(P_MPI)

    typedef int TTaskId;
    enum
    {
        TaskId_None = -1
    };

#endif

    //! Default ctor
    PEnvironment(void);
    //! Dtor
    virtual ~PEnvironment(void);

    //! Initialise environment.
    void Init(int argc, char** argv);

    //! Check if the environment is homogenous.
    bool IsHomogenous(void);
    //! Get the number of hosts in the current virtual machine.
    int GetNumberOfHosts(void); // returns 0 if not known
    //! returns the number of processes running
    int GetNumberOfTasks(void);
    //! returns the process id of the master process
    int GetMasterProcessId(void);
    //! Returns the process id of the calling process
    int GetMyProcessId(void); // returns -1 if not initialised
    //! Returns \c true if the calling process is the master, or \c false otherwise
    bool AmIMaster(void);

    //! Perform barrier synchronisation.
    void Barrier(void);

    //! Send a message to another process
    void SendMessage(int ProcessId, PMessage& Message, bool ClearMessage = true);
    //! Send a message to several process (multicast)
    void SendMessage(int NumberOfProcessIds, const int ProcessIds[], PMessage& Message, bool ClearMessage = true);
    //! Broadcast a message to all other processes
    void BroadcastMessage(PMessage& Message, bool ClearMessage = true);
    //TODO: both return process id of the source of the message or -1 if an error occurs
    //! Receive a message from another process.
    void ReceiveMessage(int ProcessId, PMessage& Message); // ProcessId == -1 means "any process"
    //! Receive a message from any process
    void ReceiveMessage(PMessage& Message); // from any process
    // Discard contents of the send buffer, copy recv buf to send buf, send, and optionally clear send buf
    //void ForwardMessage(int ProcessId, PMessage& Message, bool ClearMessage = true);
    //TODO: other version(s) of ForwardMessage

    // Reduce() is only capable of reduction over all of the processes

    /*! \brief Perform all-to-one reduction over all processes

        \param Data data to be consolidated
        \param Operator binary reduction operator to be applied
        \retval Data \c Data on the master process will hold the result of the reduction

        Please note that the contents of \c Data on non-master processes may get corrupt.
    */

    template <class T>
    void Reduce(T& Data, const BinaryReductionOperator<T>& Operator /* , int RootProcessId = GetMasterProcessId() */)
    {
      int NumberOfTasks = GetNumberOfTasks();
      int MyProcessId   = GetMyProcessId();

      //cout << "Slave " << PEnv.GetMyProcessId() << ": in PEnvironment::Reduce()" << endl;

      for (int i = 0x01; i < NumberOfTasks; i <<= 1)
      {
        if ((MyProcessId & i) != 0) // Binary AND
        {
          PMessage msg;
          msg << Data;
          //cout << "Slave " << PEnv.GetMyProcessId() << ": sending data to process " << (MyProcessId & ~i) << endl;
          SendMessage((MyProcessId & ~i), msg, false); // Do not clear -- will be destroyed anyway
          //cout << "Slave " << PEnv.GetMyProcessId() << ": sent data to process " << (MyProcessId & ~i) << endl;
          break;
        }
        else if ((MyProcessId | i) < NumberOfTasks)
        {
          PMessage msg;
          //cout << "Slave " << PEnv.GetMyProcessId() << ": receiving data from process " << (MyProcessId | i) << endl;
          ReceiveMessage((MyProcessId | i), msg);
          //cout << "Slave " << PEnv.GetMyProcessId() << ": received data from process " << (MyProcessId | i) << endl;
          //cout << "Slave " << PEnv.GetMyProcessId() << ": unpacking data" << endl;
          // AZ 10/02/99 TODO: get rid of copying (currently needed because images et al lack default ctors)
          T rhs(Data);
          msg >> rhs;
          //cout << "Slave " << PEnv.GetMyProcessId() << ": finished unpacking data" << endl;
          //cout << "Slave " << PEnv.GetMyProcessId() << ": applying reduction operator" << endl;
          Operator(Data, rhs);
          //cout << "Slave " << PEnv.GetMyProcessId() << ": applied reduction operator" << endl;
        };
      };

      //cout << "Slave " << PEnv.GetMyProcessId() << ": leaving PEnvironment::Reduce()" << endl;
    };

protected:

private:

    PEnvironment(const PEnvironment&);            // Not defined
    PEnvironment& operator=(const PEnvironment&); // Not defined

    friend PMessage;

#if defined(P_EPX)

    void EpxSendRawData(int ProcessId, void *Data, int DataSize);

#ifndef P_NO_TREE_BCAST
    void EpxMcastRawData(int NumberOfProcessIds, const int ProcessIds[], void* Data, int DataSize);
#endif

#ifdef P_MT_COMM

    // Asynchronous I/O

    struct SJobInfo_Send
    {
        void           *m_Buffer;
        int             m_NumberOfActiveSends;
        PMessage       *m_Message; // if this is NULL, a sending thread is responsible for freeing the buffer (i.e. the job is "detached")
        PEpxSemaphore   m_Semaphore;
    };

    struct SAsyncJob: public Node_t
    {
        enum
        {
            JOB_SHUTDOWN,
            JOB_SEND
        }
            m_JobType;

        union
        {
            // JOB_SHUTDOWN has no data

            // JOB_SEND
            struct
            {
                int             m_Dest; // destination process id
                SJobInfo_Send  *m_Info; // data
                int             m_Size; // data size
                PEnvironment   *m_Env;  // environment used for sending
            }
                m_Send;
        };
    };

    struct SAsyncJobQueue
    {
        List_t          m_JobList;
        PEpxSemaphore   m_JobListAccessSem;
        PEpxSemaphore   m_JobListNotEmptySem;
        int             m_ThreadsRunning;       // number of threads serving this queue
        PEpxSemaphore   m_ShutdownSem;          // is free when (m_ThreadsRunning == 0)

        SAsyncJobQueue(void)
        :   m_JobListAccessSem(0),
            m_JobListNotEmptySem(0),
            m_ThreadsRunning(0),
            m_ShutdownSem(1)
        {
            InitList(&m_JobList);
            assert(RemHead(&m_JobList) == NULL); // empty?
            m_JobListAccessSem.Release();
        };

        virtual ~SAsyncJobQueue(void)
        {
            assert(RemHead(&m_JobList) == NULL); // oops, not empty
            //m_JobList = NULL;
        };
    };

    int             m_AsyncNumberOfThreads;
    Thread_t      **m_AsyncThreads;
    int            *m_AsyncThreadsExitCodes;
    SAsyncJobQueue *m_AsyncJobQueue;

    bool AsyncProcessJob(SAsyncJob *Job); // Returns true if shutting down, false otherwise
    int  AsyncProcessJobQueue(void);
    void AsyncSubmitJob(SAsyncJob *Job); // Job will be deleted by a comm thread
    void AsyncInit(int NumberOfThreads);
    void AsyncExit(void);
    void AsyncSend(int NumberOfProcessIds, const int ProcessIds[], PMessage& Message);
    void AsyncSend(int ProcessId, PMessage& Message);

    friend int PAsyncThreadProc(void *Arg);

    enum
    {
        MAX_COMM_THREADS = 16 // max number of communication threads
    };
#endif //P_MT_COMM

    enum
    {
        DEFAULT_RECV_BUF_SIZE = 64*1024 // default size of the receive buffer
    };

    int            *m_BufferSizes;

#ifdef P_MT_COMM
    PEpxSemaphore   m_BufferSizesSem; // mutex protecting access to m_BufferSizes
#endif //P_MT_COMM

#endif  // P_EPX

    bool        m_Homogenous;
    int         m_NumberOfHosts;   // 0 if not known
    int         m_NumberOfTasks;   // including master
    bool        m_Initialised;
    TTaskId     m_MyTaskId;
    TTaskId     m_MasterTaskId;
#if defined(P_PVM)
    TTaskId    *m_TaskIds;         // tid's of all tasks
    int         m_PvmEncoding;
    const char *m_GroupName; //TODO: method for setting this
    int         m_MyProcessId;
#elif defined(P_EPX)
    int         m_ReqId;   //TODO: method for setting this
    int         m_TopologyId;
    LinkCB_t  **m_Links;
    Option_t   *m_Options;
#endif

#if defined(P_PVM)

    enum
    {
        TAG_TASK_IDS,
        TAG_USER_MESSAGE
    };

#elif defined(P_EPX)

    enum
    {
        REQID_USER_MESSAGES    = 1706,
        REQID_BARRIER_REQUEST  = 1609,
        REQID_BARRIER_REPLY    = REQID_BARRIER_REQUEST + 1
    };

    enum
    {
        TAG_USER_MESSAGE,
        TAG_MSG_SIZE_INFO

#ifndef P_NO_TREE_BCAST
	,
	TAG_USER_MULTICAST
#endif

    };

#endif

};

#endif	//__PENVIRONMENT_H__
