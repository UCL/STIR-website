// @(#)PMemory.h	1.4: 00/03/23

/*!
 \file PMemory.h

 \brief Memory debugger

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 Internal memory debugger for the parallelisation library.
 The debugger is only active if P_MEMDEBUG is defined.

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PMEMORY_H__
#define __PMEMORY_H__

#include "PCheckTarget.h"

#if !defined(DOXYGEN_SKIP)

#if defined(P_MEMDEBUG)

/*! \brief Register a memory allocation.

    This is an internal function which used to keep track of all heap
    objects currently allocated.
*/
template<class T>
inline T* PRegisterAllocation(T *Ptr, int Size, const char *File, int Line, bool Array)
{
    return static_cast<T*>(PRegisterAllocation(static_cast<void*>(Ptr), Size, File, Line, Array));
};

//! Specialised version of PRegisterAllocation for void*.
template <>
extern void* PRegisterAllocation<void>(void *Ptr, int Size, const char *File, int Line, bool Array);

/*! \brief Deregister a memory allocation.

    This is an internal function which used to keep track of all heap
    objects currently allocated.
*/
template<class T>
inline void PDeregisterAllocation(T *Ptr, const char *File, int Line, bool Array)
{
    PDeregisterAllocation(static_cast<void*>(Ptr), File, Line, Array);
};

//! Specialised version of PDeregisterAllocation for void*.
template<>
extern void PDeregisterAllocation<void>(void *Ptr, const char *File, int Line, bool Array);

//! Report all currently allocated objects.
extern void PReportMemoryLeaks(void);

#define PNew(type) (PRegisterAllocation(new type, sizeof(type), __FILE__, __LINE__, false))
#define PNewArray(type, size) (PRegisterAllocation(new type[size], sizeof(type) * (size), __FILE__, __LINE__, true))
#define PDelete(ptr) do { PDeregisterAllocation(ptr, __FILE__, __LINE__, false); delete ptr; ptr = NULL; } while (0)
#define PDeleteArray(ptr) do { PDeregisterAllocation(ptr, __FILE__, __LINE__, true); delete[] ptr; ptr = NULL; } while (0)

void* PMemGetNULL(void);

#else

#define PNew(type) (new type)
#define PNewArray(type, size) (new type[size])
#define PDelete(ptr) do { delete ptr; ptr = NULL; } while (0)
#define PDeleteArray(ptr) do { delete[] ptr; ptr = NULL; } while (0)

#include <stdlib.h> // For NULL

inline void* PMemGetNULL(void)
{
	return NULL;
};

#endif	// P_MEMDEBUG

#else // DOXYGEN_SKIP

// This section is solely for documentation purposes

/*! \brief Allocate an instance of \c type on the heap.

    Equivalent to \c new, but also registers the allocated memory block
    on the list of allocations if P_MEMDEBUG is defined. Memory allocated
    by PNew() should only be freed with PDelete().

    <b>
*/

#define PNew(type)

/*! \brief Allocate an instance of \c type on the heap.

    Equivalent to <tt>new[]</tt>, but also registers the allocated memory block
    on the list of allocations if P_MEMDEBUG is defined. Memory allocated
    by PNewArray() should only be freed with PDeleteArray().
*/

#define PNewArray(type, size)

/*! \brief Deallocate memory previously allocated with PNew().

    Equivalent to <tt>delete</tt>, but also deregisters the memory block
    off the list of allocations if P_MEMDEBUG is defined. PDelete() should
    only be used on memory allocated by PNew().
*/

#define PDelete(ptr)

/*! \brief Deallocate memory previously allocated with PNewArray().

    Equivalent to <tt>delete[]</tt>, but also deregisters the memory block
    off the list of allocations if P_MEMDEBUG is defined. PDeleteArray() should
    only be used on memory allocated by PNewArray().
*/

#define PDeleteArray(ptr)

/*! \brief Returns a NULL pointer.

 This function must be called from a contructor of a global object when
 1) the object's ctor DOES NOT use memory routines; \b and
 2) its dtor DOES use memory routines;
 In this case you must call PMemGetNULL() function in the object's ctor (body
 or member initialisation list are fine). If you fail to do so, internal
 data structures of memory debugger might get destroyed earlier than your
 object's destructor will be called, wreaking havoc.
*/
void* PMemGetNULL(void);

#endif // DOXYGEN_SKIP

#endif	// __PMEMORY_H__
