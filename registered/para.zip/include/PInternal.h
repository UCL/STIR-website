// @(#)PInternal.h	1.4: 00/03/23

/*!
 \file PInternal.h

 \brief Parallel library internal stuff

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PINTERNAL_H__
#define __PINTERNAL_H__

#include "PCheckTarget.h"

#include <iostream>

//! Report an error message and an error code
extern void PError(const char* msg, int code);

#ifndef DOXYGEN_SKIP
#  if defined(P_TRACE)
#    define PTRACE(x) do { cout << PObject::GetDefaultEnvironment()->GetMyProcessId() << ": " << x << endl; } while (0)
#  else
#    define PTRACE(x) do {} while (0)
#  endif
#else
/*! \brief Print a message along with the id of the current process to \c cout.

    Does nothing unless P_TRACE is defined
*/
#  define PTRACE(x)
#endif

#endif	//__PINTERNAL_H__
