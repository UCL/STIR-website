// ParaEPX.h - Support classes for EPX in Para++
// @(#)ParaEPX.h	1.4: 00/03/23

#include "pet_common.h"

#include <vector.h>
#include <list.h>
#include <pet_string.h>

const int EPX_ANYTAG = -1;
const int EPX_ANYPROC = -1;

#define SOCKET_BASE
//#define EPX_BASE


// A COMMS_BASE class must provide the methods:
//   int send(int proc_id, int size, void *buf);
//   int recv(int proc_id, int size, void *buf);
//   int probe(const int proc_id);
//   int probe();
//   int wait();

#ifdef EPX_BASE
#include <EpxComms.h>
typedef EpxComms COMMS_BASE;
#else
#include <SocketComms.h>
typedef SocketComms COMMS_BASE;
#endif  // EPX_BASE

#include "Buffer.h"

class ProcTag {
public:
	int tag;
	int proc;
	ProcTag() { };
	ProcTag(int Proc, int Tag) {
		tag = Tag; proc = Proc; };
	ProcTag(const ProcTag &pt) {
		tag = pt.tag; proc = pt.proc; };
	bool operator==(const ProcTag pt) const {
		return ((pt.tag == tag)&&(pt.proc == proc)); };
	bool operator!=(const ProcTag pt) const {
		return ((pt.tag != tag)||(pt.proc != proc)); };
};

typedef list<Buffer> BufferList;
typedef list<int> intList;

// NB the first 8 bytes of each buffer are reserved for tag id
//    and msg size. COMMS_BASE is either EpxComms or SocketComms
//    (in the future, maybe even PvmComms or MpiComms).
class EpxTagComms: public COMMS_BASE {

private:
  int send_tag;  // This is the msg tag currently being sent
  int recv_tag;  // This is the msg tag currently being received
  vector<Buffer> sendbuflist; // Buffer for each tag
  vector<ProcTag> sendtaglist;    // Tag for each buffer entry
  vector<BufferList> recvbuflist; // Buffer vector for each tag
  vector<ProcTag> recvtaglist;
  vector<intList> recvmsgorder;	// element for each msg giving
									// reception order.
  int msgnum;			// Counter for msgs to put into above
  int get_sendtag_index(int proc_id, int tag_id);
  int get_recvtag_index(int proc_id, int tag_id);

public:
	EpxTagComms() {
		send_tag = EPX_ANYTAG;
		recv_tag = EPX_ANYTAG;
		msgnum = 0;
	};

  // Send a message with tag_id to process proc_id
  int send(int proc_id, int tag_id, int size, const void *msg);

  // Receive a message with tag_id from proc_id
  int recv(int proc_id, int tag_id, int &size, void *msg);

  // Return size of next message with tag_id from proc_id
  int msgsize(int proc_id, int tag_id);

  // Flush (ie really send) a message to proc_id with tag_id
  void flush(int proc_id, int tag_id);

  // Return the source of the next msg as proc_id and tag_id
  // proc_id is -1 if there is no pending message
  ProcTag probe();

  // Return tag_id if there is a pending message from the
  // specified processor, -1 if no pending message.
  int probe(int proc_id);

  // Return true if there is a pending message from the
  // specified processor with the specified tag_id, and
  // return false otherwise.
  bool probe(int proc_id, int tag_id);

  // Return the processor id of the first msg matching the tag, -1 if none
  int probe_tag(int tag_id);

  // Wait until a msg with given tag has been received, return proc_id
  int wait_tag(int tag_id);

  // Wait until all processes have called barrier(), then return
  int barrier();
};

extern EpxTagComms EPX;
