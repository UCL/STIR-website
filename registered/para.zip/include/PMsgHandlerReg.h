// @(#)PMsgHandlerReg.h	1.3: 00/03/23

/*!
 \file PMsgHandlerReg.h

 \brief PMessageHandlerRegistration class declaration

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.3

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
    3 Nov 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PMSGHANDLERREG_H__
#define __PMSGHANDLERREG_H__

#ifdef PARALLEL

#include <map>
#include <string>
#include "Para.h"

extern PEnvironment PEnv; // must be defined somewhere

/*! \brief Associates a an integer message id with a handler function.

    A mapping of ids to to handler is maintained and whenever an
    instance of PMessageHandlerRegistration is created, an entry
    is added to the map, allowing PDispatch to call appropriate
    handlers automatically.
*/

class PMessageHandlerRegistration
{
public:

  /*! \brief Pointer to a handler function
      \param msg Message to be handled
      \return \c true if the process should terminate, \c false otherwise
  */
  typedef bool (*THandler)(PMessage&); // Message handler

  //! Ctor
  PMessageHandlerRegistration(const int id, const string& name, THandler handler);
  //! Dtor
  ~PMessageHandlerRegistration(void);

  //! Execute the message handler associated with the message type.
  static bool ProcessMessage(PMessage&);

private:

  PMessageHandlerRegistration(const PMessageHandlerRegistration&);            // Not defined
  PMessageHandlerRegistration& operator=(const PMessageHandlerRegistration&); // Not defined

  const int      m_Id;
  const string   m_Name;
  THandler       m_Handler;

  typedef map<int, PMessageHandlerRegistration*> THandlers;

  static THandlers* s_Handlers;
};

#ifndef DOXYGEN_SKIP
#define P_REGISTER_MESSAGE_HANDLER(id) \
   static PMessageHandlerRegistration Register_##id(FNID_##id, "FNID_"#id, MsgHandler_##id)
#else
/*! \brief Register a message handler.

   This macro should be used at file scope. It associates a message
   id FNID_##id with a function MsgHandler_##id by declaring a static
   instance of PMessageHandlerRegistration. For example:

   \code

   const int FNID_PRINT_INT = 1000;

   bool MsgHandler_PRINT_INT(PMessage& msg)
   {
     int i;
     msg >> i;
     std::cout << i << std::endl;
     return false; // don't terminate
   };

   P_REGISTER_MESSAGE_HANDLER(PRINT_INT);

   \endcode

   The above code will associate message id FNID_PRINT_INT with the function
   MsgHandler_PRINT_INT. This will enable PDispatch to process messages of this
   type by invoking MsgHandler_PRINT_INT on them (in the context of the receiving
   process).

   \sa PDispatch
*/
#define P_REGISTER_MESSAGE_HANDLER(id)
#endif

#endif // PARALLEL

#endif // __PMSGHANDLERREG_H__
