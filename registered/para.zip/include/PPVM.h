// @(#)PPVM.h	1.5: 00/03/23

/*!
 \file PPVM.h

 \brief PVM-specific stuff

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.5

 <b>This is an internal header and should not be included directy
    by a parallel program! Please include Para.h instead.
 </b>

 Modification history:

 <TT>
   6 Apr 99 -- Alexey Zverovich -- ported to Linux\n
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PPVM_H__
#define __PPVM_H__

#include "PCheckTarget.h"

#ifdef P_PVM
#	include <stdio.h>
#	include <pvm3.h>
#endif	// P_PVM

#endif	//__PPVM_H__
