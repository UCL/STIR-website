// @(#)Para.h	1.4: 00/03/23

/*!
 \file Para.h

 \brief Parallel library main include file

 \author Alexey Zverovich
 \author PARAPET project

 \date    00/03/23

 \version 1.4

 Includes all the necessary include files. Only Para.h needs
 to be included from a parallel application, all other files
 will be included automatically.

 Modification history:

 <TT>
  14 Oct 98 -- Alexey Zverovich -- added #include "PAssert.h"\n
 Jun-Jul 98 -- Alexey Zverovich -- created
 </TT>

*/

#ifndef __PARA_H__
#define __PARA_H__

#include "PCheckTarget.h"
#include "PAssert.h"
#include "PMemory.h"
#include "PObject.h"
#include "PEPX.h"
#include "PPVM.h"
#include "PEnvironment.h"
#include "PMessage.h"
#include "PInternal.h"

#endif	//__PARA_H__
