//
// @(#)distributable.cxx	1.4 00/03/26
//

#include "distributable.h"
#include "recon_buildblock/fwdproj.h" 
#include "recon_buildblock/bckproj.h" 
#include "Timer.h"
#include "recon_array_functions.h"

#ifdef PARALLEL



PEnvironment PEnv;

// RPC data (slave)

PETImageOfVolume RPC_slave_lambda(Tensor3D<float>(0,0,0),Point3D(0,0,0),Point3D(0,0,0));
PETImageOfVolume RPC_slave_image_x(Tensor3D<float>(0,0,0),Point3D(0,0,0),Point3D(0,0,0));
PETSegmentBySinogram* RPC_slave_seg0_data = NULL;
PETSegmentBySinogram* RPC_slave_binwise_correction_seg0 = NULL;
float* RPC_slave_f(NULL);

#endif // PARALLEL

bool RPC_slave_sens_zero_seg0_end_planes = false;

void RPC_backproj_seg0_view(PETImageOfVolume& image, PETSegmentBySinogram& segment,
			    const int view, const int view45);

void RPC_backproj_8_viewgrams(PETImageOfVolume& image_x, 
			      PETViewgram& pos_view,   PETViewgram& neg_view,
			      PETViewgram& pos_plus90, PETViewgram& neg_plus90,
			      PETViewgram& pos_min180, PETViewgram& neg_min180,
			      PETViewgram& pos_min90,  PETViewgram& neg_min90);

void RPC_backproj_4_viewgrams(PETImageOfVolume& image_x, 
			      PETViewgram& pos_view,   PETViewgram& neg_view,
			      PETViewgram& pos_plus90, PETViewgram& neg_plus90);

#ifdef PARALLEL

// AZ 04/10/99: added

void RPC_confirm(void)
{
#ifdef P_INFO
  cout << "Slave " << PEnv.GetMyProcessId() << ": sending confirmation to master" << endl;
#endif // P_INFO

  PMessage confirmation;

  confirmation << 0x01020304ul << int(PEnv.GetMyProcessId()); //TODO
  PEnv.SendMessage(PEnv.GetMasterProcessId(), confirmation);

#ifdef P_INFO
  cout << "Slave " << PEnv.GetMyProcessId() << ": sent confirmation to master" << endl;
#endif // P_INFO
};

// Message handlers

static bool MsgHandler_RPC_INIT(PMessage& msg)
{
  msg >> RPC_slave_lambda;

  // AZ 11/02/99 Added
  RPC_slave_image_x = RPC_slave_lambda.get_empty_copy();

  bool update_f;
  msg >> update_f;
  assert(RPC_slave_f == NULL);
  if (update_f) RPC_slave_f = new float(0.0);  
  msg >> RPC_slave_sens_zero_seg0_end_planes;

  return false;
};

static bool MsgHandler_RPC_INIT_SEG0_DATA(PMessage& msg)
{
  bool has_seg0_data          = false;
  bool has_binwise_correction = false;

  msg >> has_seg0_data;

  if (RPC_slave_seg0_data != NULL)
  {
    delete RPC_slave_seg0_data;
    RPC_slave_seg0_data = NULL;
  };

  if (has_seg0_data)
  {
    RPC_slave_seg0_data = new PETSegmentBySinogram(Tensor3D<float>(0,0,0),PETScanInfo(),0);
    msg >> (*RPC_slave_seg0_data);
  };

  msg >> has_binwise_correction;

  if (RPC_slave_binwise_correction_seg0 != NULL)
  {
    delete RPC_slave_binwise_correction_seg0;
    RPC_slave_binwise_correction_seg0 = NULL;
  };

  if (has_binwise_correction)
  {
    RPC_slave_binwise_correction_seg0 = new PETSegmentBySinogram(Tensor3D<float>(0,0,0),PETScanInfo(),0);
    msg >> (*RPC_slave_binwise_correction_seg0);
  };

  return false;
};



static bool MsgHandler_RPC_PROCESS_SEG0_VIEW(PMessage& msg)
{
  int view;
  int view45;

  msg >> view;
  msg >> view45;

#ifdef P_INFO
  cout << "Slave " << PEnv.GetMyProcessId() << ": view " << view << "; view45 = " << view45 << endl;
#endif // P_INFO

  int count = 0, count2 = 0;

  RPC_process_seg0_view(RPC_slave_lambda, RPC_slave_image_x,
			RPC_slave_seg0_data, view, view45, count, count2, RPC_slave_f, RPC_slave_binwise_correction_seg0);

  RPC_confirm();

  return false;
};

// AZ 04/10/99: added has_viewgrams and related stuff
static bool MsgHandler_RPC_PROCESS_8_VIEWGRAMS(PMessage& msg)
{
  bool has_viewgrams = false;

  PETViewgram* pos_view   = NULL;
  PETViewgram* neg_view   = NULL;
  PETViewgram* pos_plus90 = NULL;
  PETViewgram* neg_plus90 = NULL;
  PETViewgram* pos_min90  = NULL;
  PETViewgram* neg_min90  = NULL;
  PETViewgram* pos_min180 = NULL;
  PETViewgram* neg_min180 = NULL;

  msg >> has_viewgrams;

  if (has_viewgrams)
  {
    pos_view   = new PETViewgram(msg);
    neg_view   = new PETViewgram(msg);
    pos_plus90 = new PETViewgram(msg);
    neg_plus90 = new PETViewgram(msg);
    pos_min90  = new PETViewgram(msg);
    neg_min90  = new PETViewgram(msg);
    pos_min180 = new PETViewgram(msg);
    neg_min180 = new PETViewgram(msg);
  };

  bool has_binwise_correction = false;

  PETViewgram* bc_pos_view   = NULL;
  PETViewgram* bc_neg_view   = NULL;
  PETViewgram* bc_pos_plus90 = NULL;
  PETViewgram* bc_neg_plus90 = NULL;
  PETViewgram* bc_pos_min90  = NULL;
  PETViewgram* bc_neg_min90  = NULL;
  PETViewgram* bc_pos_min180 = NULL;
  PETViewgram* bc_neg_min180 = NULL;

  msg >> has_binwise_correction;

  if (has_binwise_correction)
  {
    bc_pos_view   = new PETViewgram(msg);
    bc_neg_view   = new PETViewgram(msg);
    bc_pos_plus90 = new PETViewgram(msg);
    bc_neg_plus90 = new PETViewgram(msg);
    bc_pos_min90  = new PETViewgram(msg);
    bc_neg_min90  = new PETViewgram(msg);
    bc_pos_min180 = new PETViewgram(msg);
    bc_neg_min180 = new PETViewgram(msg);
  };

  int count = 0, count2 = 0;

  RPC_process_8_viewgrams(RPC_slave_lambda, RPC_slave_image_x, 
			  pos_view, neg_view,
			  pos_plus90, neg_plus90,
			  pos_min180, neg_min180,
			  pos_min90, neg_min90,
			  count, count2, RPC_slave_f,
			  bc_pos_view, bc_neg_view,
			  bc_pos_plus90, bc_neg_plus90,
			  bc_pos_min90, bc_neg_min90,
			  bc_pos_min180, bc_neg_min180);

  delete pos_view;
  delete neg_view;
  delete pos_plus90;
  delete neg_plus90;
  delete pos_min90;
  delete neg_min90;
  delete pos_min180;
  delete neg_min180;

  delete bc_pos_view;
  delete bc_neg_view;
  delete bc_pos_plus90;
  delete bc_neg_plus90;
  delete bc_pos_min90;
  delete bc_neg_min90;
  delete bc_pos_min180;
  delete bc_neg_min180;

  RPC_confirm();

  return false;
};

static bool MsgHandler_RPC_PROCESS_4_VIEWGRAMS(PMessage& msg)
{
  bool has_viewgrams = false;

  PETViewgram* pos_view   = NULL;
  PETViewgram* neg_view   = NULL;
  PETViewgram* pos_plus90 = NULL;
  PETViewgram* neg_plus90 = NULL;

  msg >> has_viewgrams;

  if (has_viewgrams)
  {
    pos_view   = new PETViewgram(msg);
    neg_view   = new PETViewgram(msg);
    pos_plus90 = new PETViewgram(msg);
    neg_plus90 = new PETViewgram(msg);
  };

  bool has_binwise_correction = false;

  PETViewgram* bc_pos_view   = NULL;
  PETViewgram* bc_neg_view   = NULL;
  PETViewgram* bc_pos_plus90 = NULL;
  PETViewgram* bc_neg_plus90 = NULL;

  msg >> has_binwise_correction;

  if (has_binwise_correction)
  {
    bc_pos_view   = new PETViewgram(msg);
    bc_neg_view   = new PETViewgram(msg);
    bc_pos_plus90 = new PETViewgram(msg);
    bc_neg_plus90 = new PETViewgram(msg);
  };

  int count = 0, count2 = 0;

  RPC_process_4_viewgrams(RPC_slave_lambda, RPC_slave_image_x, 
			  pos_view, neg_view,
			  pos_plus90, neg_plus90,
			  count, count2, RPC_slave_f,
			  bc_pos_view, bc_neg_view,
			  bc_pos_plus90, bc_neg_plus90);

  delete pos_view;
  delete neg_view;
  delete pos_plus90;
  delete neg_plus90;

  delete bc_pos_view;
  delete bc_neg_view;
  delete bc_pos_plus90;
  delete bc_neg_plus90;

  RPC_confirm();

  return false;
};

static bool MsgHandler_RPC_BACKPROJ_SEG0_VIEW(PMessage& msg)
{
  int view;
  int view45;

  msg >> view;
  msg >> view45;

#ifdef P_INFO
  cout << "Slave " << PEnv.GetMyProcessId() << ": view " << view << "; view45 = " << view45 << endl;
#endif // P_INFO

  assert(RPC_slave_seg0_data != NULL);

  RPC_backproj_seg0_view(RPC_slave_image_x, *RPC_slave_seg0_data, view, view45);

  RPC_confirm();

  return false;
};

static bool MsgHandler_RPC_BACKPROJ_8_VIEWGRAMS(PMessage& msg)
{
  bool has_viewgrams = false;

  msg >> has_viewgrams;

  assert(has_viewgrams);

  PETViewgram pos_view(msg);
  PETViewgram neg_view(msg);
  PETViewgram pos_plus90(msg);
  PETViewgram neg_plus90(msg);
  PETViewgram pos_min90(msg);
  PETViewgram neg_min90(msg);
  PETViewgram pos_min180(msg);
  PETViewgram neg_min180(msg);

  bool has_binwise_correction = false;

  msg >> has_binwise_correction;

  assert(!has_binwise_correction);

  RPC_backproj_8_viewgrams(RPC_slave_image_x, 
			   pos_view, neg_view,
			   pos_plus90, neg_plus90,
			   pos_min180, neg_min180,
			   pos_min90, neg_min90);
  RPC_confirm();

  return false;
};

static bool MsgHandler_RPC_BACKPROJ_4_VIEWGRAMS(PMessage& msg)
{
  bool has_viewgrams = false;

  msg >> has_viewgrams;

  assert(has_viewgrams);

  PETViewgram pos_view(msg);
  PETViewgram neg_view(msg);
  PETViewgram pos_plus90(msg);
  PETViewgram neg_plus90(msg);

  bool has_binwise_correction = false;

  msg >> has_binwise_correction;

  assert(!has_binwise_correction);

  RPC_backproj_4_viewgrams(RPC_slave_image_x, 
			   pos_view, neg_view,
			   pos_plus90, neg_plus90);

  RPC_confirm();

  return false;
};

static bool MsgHandler_RPC_RETURN_IMAGE_AND_F(PMessage&)
{
#ifdef P_INFO
  cout << "Slave " << PEnv.GetMyProcessId() << ": Returning the image" << endl;
#endif // P_INFO
  PEnv.Reduce(RPC_slave_image_x, ReductionAdd<PETImageOfVolume>());
#ifdef P_INFO
  cout << "Slave " << PEnv.GetMyProcessId() << ": Returned the image" << endl;
#endif // P_INFO
  if (RPC_slave_f != NULL)
  {
#ifdef P_INFO
    cout << "Slave " << PEnv.GetMyProcessId() << ": Returning f" << endl;
#endif // P_INFO
    PEnv.Reduce(*RPC_slave_f, ReductionAdd<float>());
    delete RPC_slave_f;
    RPC_slave_f = NULL;
#ifdef P_INFO
    cout << "Slave " << PEnv.GetMyProcessId() << ": Returned f" << endl;
#endif // P_INFO
  };

  return false;
};


static bool MsgHandler_RPC_RETURN_F(PMessage&)
{


  if (RPC_slave_f != NULL)
  {
#ifdef P_INFO
    cout << "Slave " << PEnv.GetMyProcessId() << ": Returning f" << endl;
#endif // P_INFO
    PEnv.Reduce(*RPC_slave_f, ReductionAdd<float>());
    delete RPC_slave_f;
    RPC_slave_f = NULL;
#ifdef P_INFO
    cout << "Slave " << PEnv.GetMyProcessId() << ": Returned f" << endl;
#endif // P_INFO
  };

  return false;
};




//MJ 03/01/2000 Attempt to parallelize loglikelihood function computation

static bool MsgHandler_RPC_ACCUMULATE_LOGLIKELIHOOD_SEG0_VIEW(PMessage& msg)
{
  int view;
  int view45;

  msg >> view;
  msg >> view45;

#ifdef P_INFO
  cout << "Slave " << PEnv.GetMyProcessId() << ": view " << view << "; view45 = " << view45 << endl;
#endif // P_INFO

  
  RPC_accumulate_loglikelihood_seg0_view(RPC_slave_lambda,
			RPC_slave_seg0_data, view, view45, RPC_slave_f, RPC_slave_binwise_correction_seg0);

  RPC_confirm();

  return false;
};

//MJ 03/01/2000 Attempt to parallelize loglikelihood function computation
static bool MsgHandler_RPC_ACCUMULATE_LOGLIKELIHOOD_8_VIEWGRAMS(PMessage& msg)
{
  bool has_viewgrams = false;

  PETViewgram* pos_view   = NULL;
  PETViewgram* neg_view   = NULL;
  PETViewgram* pos_plus90 = NULL;
  PETViewgram* neg_plus90 = NULL;
  PETViewgram* pos_min90  = NULL;
  PETViewgram* neg_min90  = NULL;
  PETViewgram* pos_min180 = NULL;
  PETViewgram* neg_min180 = NULL;

  msg >> has_viewgrams;

  if (has_viewgrams)
  {
    pos_view   = new PETViewgram(msg);
    neg_view   = new PETViewgram(msg);
    pos_plus90 = new PETViewgram(msg);
    neg_plus90 = new PETViewgram(msg);
    pos_min90  = new PETViewgram(msg);
    neg_min90  = new PETViewgram(msg);
    pos_min180 = new PETViewgram(msg);
    neg_min180 = new PETViewgram(msg);
  };

  bool has_binwise_correction = false;

  PETViewgram* bc_pos_view   = NULL;
  PETViewgram* bc_neg_view   = NULL;
  PETViewgram* bc_pos_plus90 = NULL;
  PETViewgram* bc_neg_plus90 = NULL;
  PETViewgram* bc_pos_min90  = NULL;
  PETViewgram* bc_neg_min90  = NULL;
  PETViewgram* bc_pos_min180 = NULL;
  PETViewgram* bc_neg_min180 = NULL;

  msg >> has_binwise_correction;

  if (has_binwise_correction)
  {
    bc_pos_view   = new PETViewgram(msg);
    bc_neg_view   = new PETViewgram(msg);
    bc_pos_plus90 = new PETViewgram(msg);
    bc_neg_plus90 = new PETViewgram(msg);
    bc_pos_min90  = new PETViewgram(msg);
    bc_neg_min90  = new PETViewgram(msg);
    bc_pos_min180 = new PETViewgram(msg);
    bc_neg_min180 = new PETViewgram(msg);
  };


  RPC_accumulate_loglikelihood_8_viewgrams(RPC_slave_lambda, 
			  pos_view, neg_view,
			  pos_plus90, neg_plus90,
			  pos_min180, neg_min180,
			  pos_min90, neg_min90,
			  RPC_slave_f,
			  bc_pos_view, bc_neg_view,
			  bc_pos_plus90, bc_neg_plus90,
			  bc_pos_min90, bc_neg_min90,
			  bc_pos_min180, bc_neg_min180);

  delete pos_view;
  delete neg_view;
  delete pos_plus90;
  delete neg_plus90;
  delete pos_min90;
  delete neg_min90;
  delete pos_min180;
  delete neg_min180;

  delete bc_pos_view;
  delete bc_neg_view;
  delete bc_pos_plus90;
  delete bc_neg_plus90;
  delete bc_pos_min90;
  delete bc_neg_min90;
  delete bc_pos_min180;
  delete bc_neg_min180;

  RPC_confirm();

  return false;
};

//MJ 03/01/2000 Attempt to parallelize loglikelihood function computation
static bool MsgHandler_RPC_ACCUMULATE_LOGLIKELIHOOD_4_VIEWGRAMS(PMessage& msg)
{
  bool has_viewgrams = false;

  PETViewgram* pos_view   = NULL;
  PETViewgram* neg_view   = NULL;
  PETViewgram* pos_plus90 = NULL;
  PETViewgram* neg_plus90 = NULL;

  msg >> has_viewgrams;

  if (has_viewgrams)
  {
    pos_view   = new PETViewgram(msg);
    neg_view   = new PETViewgram(msg);
    pos_plus90 = new PETViewgram(msg);
    neg_plus90 = new PETViewgram(msg);
  };

  bool has_binwise_correction = false;

  PETViewgram* bc_pos_view   = NULL;
  PETViewgram* bc_neg_view   = NULL;
  PETViewgram* bc_pos_plus90 = NULL;
  PETViewgram* bc_neg_plus90 = NULL;

  msg >> has_binwise_correction;

  if (has_binwise_correction)
  {
    bc_pos_view   = new PETViewgram(msg);
    bc_neg_view   = new PETViewgram(msg);
    bc_pos_plus90 = new PETViewgram(msg);
    bc_neg_plus90 = new PETViewgram(msg);
  };


  RPC_accumulate_loglikelihood_4_viewgrams(RPC_slave_lambda, 
			  pos_view, neg_view,
			  pos_plus90, neg_plus90,
			  RPC_slave_f,
			  bc_pos_view, bc_neg_view,
			  bc_pos_plus90, bc_neg_plus90);

  delete pos_view;
  delete neg_view;
  delete pos_plus90;
  delete neg_plus90;

  delete bc_pos_view;
  delete bc_neg_view;
  delete bc_pos_plus90;
  delete bc_neg_plus90;

  RPC_confirm();

  return false;
};




P_REGISTER_MESSAGE_HANDLER(RPC_INIT);
P_REGISTER_MESSAGE_HANDLER(RPC_INIT_SEG0_DATA);
P_REGISTER_MESSAGE_HANDLER(RPC_PROCESS_SEG0_VIEW);
P_REGISTER_MESSAGE_HANDLER(RPC_PROCESS_8_VIEWGRAMS);
P_REGISTER_MESSAGE_HANDLER(RPC_PROCESS_4_VIEWGRAMS);
P_REGISTER_MESSAGE_HANDLER(RPC_RETURN_IMAGE_AND_F);
P_REGISTER_MESSAGE_HANDLER(RPC_BACKPROJ_SEG0_VIEW);
P_REGISTER_MESSAGE_HANDLER(RPC_BACKPROJ_8_VIEWGRAMS);
P_REGISTER_MESSAGE_HANDLER(RPC_BACKPROJ_4_VIEWGRAMS);

//MJ 03/01/2000 Attempt to parallelize loglikelihood function computation
P_REGISTER_MESSAGE_HANDLER(RPC_ACCUMULATE_LOGLIKELIHOOD_SEG0_VIEW);
P_REGISTER_MESSAGE_HANDLER(RPC_ACCUMULATE_LOGLIKELIHOOD_8_VIEWGRAMS);
P_REGISTER_MESSAGE_HANDLER(RPC_ACCUMULATE_LOGLIKELIHOOD_4_VIEWGRAMS);
P_REGISTER_MESSAGE_HANDLER(RPC_RETURN_F);

#endif // PARALLEL

void RPC_backproj_seg0_view(PETImageOfVolume& image, PETSegmentBySinogram& segment,
			    const int view, const int view45)
{
  Backprojection_2D(segment, image, view);
};

void RPC_backproj_8_viewgrams(PETImageOfVolume& image_x, 
			      PETViewgram& pos_view,   PETViewgram& neg_view,
			      PETViewgram& pos_plus90, PETViewgram& neg_plus90,
			      PETViewgram& pos_min180, PETViewgram& neg_min180,
			      PETViewgram& pos_min90,  PETViewgram& neg_min90)
{
  back_project(pos_view, 
	       neg_view, 
	       pos_plus90, 
	       neg_plus90, 
	       pos_min180, 
	       neg_min180, 
	       pos_min90, 
	       neg_min90, 
	       image_x);
};

void RPC_backproj_4_viewgrams(PETImageOfVolume& image_x, 
			      PETViewgram& pos_view,   PETViewgram& neg_view,
			      PETViewgram& pos_plus90, PETViewgram& neg_plus90)
{
  back_project(pos_view, 
	       neg_view, 
	       pos_plus90, 
	       neg_plus90, 
	       image_x);
};

// AZ&MJ 03/10/99 added binwise_correction
// AZ&MJ 03/10/99 added binwise_correction
void distributable_compute_gradient(PETImageOfVolume& lambda,
				    PETImageOfVolume& image_x,
				    const PETSinogramOfVolume* proj_dat,
				    int subset_num, int num_subsets,
				    int view45, int min_segment, int max_segment,
				    bool zero_seg0_end_planes,
				    float* f /* = NULL */,
				    PETSinogramOfVolume* binwise_correction /* = NULL */)
{
  // AZ 06/10/99: added assertion

  assert(min_segment >= 0 && min_segment <= max_segment);

  // AZ 05/10/99: added assertion

  assert(proj_dat != NULL);

#ifdef P_INFO
  cout << "Processing segments " << min_segment << ".." << max_segment << endl;
#endif // P_INFO

  //int num_processed_views = 0;

  image_x.fill(0);

  if (f != NULL)
  {
    (*f) = 0.0;
  };
  
#ifdef PARALLEL    
  {
#ifdef P_INFO
    cout << "Master: broadcasting the images" << endl;
#endif // P_INFO

    PMessage msg;
    msg << FNID_RPC_INIT;
    msg << lambda;
    // AZ 11/02/99 Commented out
    msg << bool(f != NULL); // Update f?
    msg << zero_seg0_end_planes;
    PEnv.BroadcastMessage(msg); // nowait, noconfirm

#ifdef P_INFO
    cout << "Master: finished broadcasting the images" << endl;
#endif // P_INFO
  };
#else // not PARALLEL
  RPC_slave_sens_zero_seg0_end_planes = zero_seg0_end_planes;
#endif //PARALLEL
        
  // first do segment 0

  if (min_segment == 0) // AZ 06/10/99 added
  {
    
#ifndef PARALLEL
    CPUTimer segment_timer;
    segment_timer.start();
#endif // PARALLEL
    
    PETSegmentBySinogram* binwise_correction_seg0 =
      (binwise_correction == NULL) ? NULL : new PETSegmentBySinogram(binwise_correction->get_segment_sino_copy(0));

    PETSegmentBySinogram* y = NULL;

#ifdef PARALLEL
    if (subset_num == 0)
    {
#endif // PARALLEL

    if (proj_dat != NULL)
    {
      cerr << endl << "Now reading data for segment #: 0 " << endl;
      y = new PETSegmentBySinogram(proj_dat->get_segment_sino_copy(0));
      cerr << "Read data for segment #: 0" << endl;
    };

    if (zero_seg0_end_planes)
      {
	cerr << "\nZeroing end-planes of segment 0" << endl;

        if (y != NULL)
	{
	  (*y)[y->get_min_ring()].fill(0);
	  (*y)[y->get_max_ring()].fill(0);
	};

	if (binwise_correction_seg0 != NULL)
	{
	  (*binwise_correction_seg0)[binwise_correction_seg0->get_min_ring()].fill(0);
	  (*binwise_correction_seg0)[binwise_correction_seg0->get_max_ring()].fill(0);
	};
      };

    if (y != NULL &&
	y->get_num_bins() % 2 == 0)
    {
      y->grow_width(y->get_min_bin(), y->get_max_bin() + 1);
    };

    if (binwise_correction_seg0 != NULL &&
	binwise_correction_seg0->get_num_bins() % 2 == 0)
    {
      binwise_correction_seg0->grow_width(binwise_correction_seg0->get_min_bin(),
					  binwise_correction_seg0->get_max_bin() + 1);
    };

#ifdef PARALLEL
#ifdef P_INFO
    cout << "Master: broadcasting data for segment 0" << endl;
#endif // P_INFO
    PMessage msg;
    msg << FNID_RPC_INIT_SEG0_DATA;
    msg << bool(y != NULL);
    if (y != NULL)
    {
      msg << (*y);
    };
    msg << bool(binwise_correction != NULL);
    if (binwise_correction != NULL)
    {
      msg << (*binwise_correction_seg0);
    };
//      PEnv.BroadcastMessage(msg); // nowait, confirm
    PSubmitJob(msg, false, true, false, false); // true);
#ifdef P_INFO
    cout << "Master: finished broadcasting data for segment 0" << endl;
#endif // P_INFO
    };
#endif // PARALLEL

    int count=0, count2=0;
    
    for (int view = subset_num; view < view45; view += num_subsets)
    {
      
      //num_processed_views++;

#ifdef PARALLEL
      PMessage msg;
      msg << FNID_RPC_PROCESS_SEG0_VIEW;
      msg << view;
      msg << view45;
      PSubmitJob(msg, false, false, false, true); // wait, confirm
#else
      RPC_process_seg0_view(lambda, image_x, y, view, view45, count, count2, f, binwise_correction_seg0);
#endif // PARALLEL
    }

    if (binwise_correction_seg0 != NULL)
    {
      delete binwise_correction_seg0;
      binwise_correction_seg0 = NULL;
    };

#ifndef PARALLEL

    cerr<<"Number of (cancelled) singularities: "<<count<<endl;
    cerr<<"Number of (cancelled) negative numerators: "<<count2<<endl;
    
    cerr << "Segment " << 0 << ": " << segment_timer.value() << "secs " <<endl;

#endif // PARALLEL
    
    delete y;
  }  

  //int num_processed_segments = 1;//Get rid of this later 
  
  // now do a loop over the other segments

  for (int segment_num = ((min_segment == 0) ? 1 : min_segment); segment_num <= max_segment; segment_num++){
    
     cerr << "Starting to process segment pair " << segment_num << endl;

#ifndef PARALLEL
    CPUTimer segment_timer;
    segment_timer.start();
#endif // PARALLEL
    
    //num_processed_segments += 2; // get rid of this later
    
    // xxx moved up
    int count=0, count2=0;

    for (int view=subset_num; view <= view45; view += num_subsets) {

      //if (view == 0 || view == view45) continue; //TODO: Remove this!!! -- FOR DEBUGGING ONLY

#ifndef PARALLEL
      //CPUTimer view_timer;
      //view_timer.start();
#endif // PARALLEL

      //num_processed_views++; //get rid of this later

      const int             view90 = view45*2;
      const int 	    plus90 = view90+view;
      const int 	    min90  = view90-view;
      const int 	    min180 = (view == 0) ? min90 : view45 * 4 - view;

      PETViewgram* pos_view   = NULL;
      PETViewgram* neg_view   = NULL;
      PETViewgram* pos_plus90 = NULL;
      PETViewgram* neg_plus90 = NULL;
      PETViewgram* pos_min90  = NULL;
      PETViewgram* neg_min90  = NULL;
      PETViewgram* pos_min180 = NULL;
      PETViewgram* neg_min180 = NULL;

      if (proj_dat != NULL)
      {

#ifdef P_INFO
	cout << endl << "  - Getting 8 viewgrams" << endl;
#endif // P_INFO
      
	pos_view   = new PETViewgram(proj_dat->get_viewgram_copy(view, segment_num));
	neg_view   = new PETViewgram(proj_dat->get_viewgram_copy(view, -segment_num));
	pos_plus90 = new PETViewgram(proj_dat->get_viewgram_copy(plus90, segment_num));
	neg_plus90 = new PETViewgram(proj_dat->get_viewgram_copy(plus90, -segment_num));
      
	// KT 21/05/98 just read these viewgrams for view=0 || view45 as well
	// otherwise, some assert() things break in the backprojector
	//   cout <<"  - Getting other 4 viewgrams"  << endl;
	pos_min90  = new PETViewgram(proj_dat->get_viewgram_copy(min90, segment_num));
	neg_min90  = new PETViewgram(proj_dat->get_viewgram_copy(min90, -segment_num));
	pos_min180 = new PETViewgram(proj_dat->get_viewgram_copy(min180, segment_num)); 
	neg_min180 = new PETViewgram(proj_dat->get_viewgram_copy(min180, -segment_num));
      
	if (pos_view->get_num_bins() % 2 == 0)
	{
	  int min_bin_orig = pos_view->get_min_bin();
	  int max_bin_orig = pos_view->get_max_bin();
	  
	  pos_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	  pos_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	  pos_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	  pos_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	};
      };

      // AZ 03/10/99: added

      PETViewgram* bc_pos_view   = NULL;
      PETViewgram* bc_neg_view   = NULL;
      PETViewgram* bc_pos_plus90 = NULL;
      PETViewgram* bc_neg_plus90 = NULL;
	  
      PETViewgram* bc_pos_min90  = NULL;
      PETViewgram* bc_neg_min90  = NULL;
      PETViewgram* bc_pos_min180 = NULL;
      PETViewgram* bc_neg_min180 = NULL;

      if (binwise_correction != NULL)
	{
	  bc_pos_view   = new PETViewgram(binwise_correction->get_viewgram_copy(view, segment_num));
	  bc_neg_view   = new PETViewgram(binwise_correction->get_viewgram_copy(view, -segment_num));
	  bc_pos_plus90 = new PETViewgram(binwise_correction->get_viewgram_copy(plus90, segment_num));
	  bc_neg_plus90 = new PETViewgram(binwise_correction->get_viewgram_copy(plus90, -segment_num));
	  
	  bc_pos_min90  = new PETViewgram(binwise_correction->get_viewgram_copy(min90, segment_num));
	  bc_neg_min90  = new PETViewgram(binwise_correction->get_viewgram_copy(min90, -segment_num));
	  bc_pos_min180 = new PETViewgram(binwise_correction->get_viewgram_copy(min180, segment_num)); 
	  bc_neg_min180 = new PETViewgram(binwise_correction->get_viewgram_copy(min180, -segment_num));
	 
	  if (bc_pos_view->get_num_bins() % 2 == 0)
	    {
	      int min_bin_orig = bc_pos_view->get_min_bin();
	      int max_bin_orig = bc_pos_view->get_max_bin();
		
	      bc_pos_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_pos_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_pos_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_pos_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	    }
	}

#ifndef PARALLEL
	  
      if (view != 0 && view != view45)
	{
	  RPC_process_8_viewgrams(lambda, image_x,
				  pos_view, neg_view,
				  pos_plus90, neg_plus90,
				  pos_min180, neg_min180,
				  pos_min90, neg_min90,
				  count, count2, f,
				  bc_pos_view, bc_neg_view,
				  bc_pos_plus90, bc_neg_plus90,
				  bc_pos_min180, bc_neg_min180,
				  bc_pos_min90, bc_neg_min90);
	}
      else
	{
	  RPC_process_4_viewgrams(lambda, image_x,
				  pos_view, neg_view,
				  pos_plus90, neg_plus90,
				  count, count2, f,
				  bc_pos_view, bc_neg_view,
				  bc_pos_plus90, bc_neg_plus90);
	};

#else // PARALLEL

      PMessage msg;

      if (view != 0 && view != view45)
        msg << FNID_RPC_PROCESS_8_VIEWGRAMS;
      else
        msg << FNID_RPC_PROCESS_4_VIEWGRAMS;

      msg << bool(proj_dat != NULL);

      if (proj_dat != NULL)
      {
	msg << *pos_view;
	msg << *neg_view;
	msg << *pos_plus90;
	msg << *neg_plus90;

	if (view != 0 && view != view45)
	{
	  msg << *pos_min90;
	  msg << *neg_min90;
	  msg << *pos_min180;
	  msg << *neg_min180;
	};
      };

      msg << bool(binwise_correction != NULL);

      if (binwise_correction != NULL)
      {
	msg << *bc_pos_view;
	msg << *bc_neg_view;
	msg << *bc_pos_plus90;
	msg << *bc_neg_plus90;

	if (view != 0 && view != view45)
	  {
	    msg << *bc_pos_min90;
	    msg << *bc_neg_min90;
	    msg << *bc_pos_min180;
	    msg << *bc_neg_min180;
	  };
      };

      PSubmitJob(msg, false, false, false, true); // wait, confirm

#endif // PARALLEL

      delete bc_pos_view;
      delete bc_neg_view;
      delete bc_pos_plus90;
      delete bc_neg_plus90;
      delete bc_pos_min90;
      delete bc_neg_min90;
      delete bc_pos_min180;
      delete bc_neg_min180;
    
      delete pos_view;
      delete neg_view;
      delete pos_plus90;
      delete neg_plus90;
      delete pos_min90;
      delete neg_min90;
      delete pos_min180;
      delete neg_min180;
    };

#ifndef PARALLEL /* Doesn't make much sense for parallel version */

    cerr<<"Number of (cancelled) singularities: "<<count<<endl;
    cerr<<"Number of (cancelled) negative numerators: "<<count2<<endl;
    
    cerr << "Segment " << segment_num << ": " << segment_timer.value() << "secs " <<endl;

#endif // PARALLEL
   
  }
  
#ifdef PARALLEL    
  {
#ifdef P_INFO
    cout << "Master: getting the images back" << endl;
#endif // P_INFO

    // AZ 10/02/99 Added
    PMessage msg;
    msg << FNID_RPC_RETURN_IMAGE_AND_F;
//    PEnv.BroadcastMessage(msg); // wait, noconfirm
    PSubmitJob(msg, false, true, true, false);
    PEnv.Reduce(image_x, ReductionAdd<PETImageOfVolume>());
    if (f != NULL)
    {
      PEnv.Reduce(*f, ReductionAdd<float>());
    };

#ifdef P_INFO
    cout << "Master: finished getting the images back" << endl;
#endif // P_INFO
  };
#endif //PARALLEL  
};

// AZ 04/10/99: added

void distributable_backproject(PETImageOfVolume& image_x,
			       const PETSinogramOfVolume& proj_dat,
			       int view45, int limit_segments,
			       bool zero_seg0_end_planes)
{
  image_x.fill(0);

#ifdef PARALLEL    
  {
#ifdef P_INFO
    cout << "Master: initialising parallel backprojector" << endl;
#endif // P_INFO

    PMessage msg;
    msg << FNID_RPC_INIT;
    msg << image_x;
    msg << bool(false); // Don't update f
    msg << zero_seg0_end_planes;
    PEnv.BroadcastMessage(msg); // nowait, noconfirm

#ifdef P_INFO
    cout << "Master: finished initialisation" << endl;
#endif // P_INFO
  };
#else // not PARALLEL
  RPC_slave_sens_zero_seg0_end_planes = zero_seg0_end_planes;
#endif //PARALLEL

  cerr << endl << "Now reading data for segment #: 0 " << endl;
  PETSegmentBySinogram y(proj_dat.get_segment_sino_copy(0));
  cerr << "Read data for segment #: 0" << endl;

  if (zero_seg0_end_planes)
  {
    cerr << "\nZeroing end-planes of segment 0" << endl;

    y[y.get_min_ring()].fill(0);
    y[y.get_max_ring()].fill(0);
  };
  
  if (y.get_num_bins() % 2 == 0)
  {
    y.grow_width(y.get_min_bin(), y.get_max_bin() + 1);
  };

#ifdef PARALLEL

#ifdef P_INFO
  cout << "Master: broadcasting data for segment 0" << endl;
#endif // P_INFO

  PMessage msg;

  msg << FNID_RPC_INIT_SEG0_DATA;
  msg << bool(true); // projection data follows
  msg << y;
  msg << bool(false); // no binwise_correction

//  PEnv.BroadcastMessage(msg); // nowait, confirm
  PSubmitJob(msg, false, true, false, false); // true);

#ifdef P_INFO
  cout << "Master: finished broadcasting data for segment 0" << endl;
#endif // P_INFO

#endif // PARALLEL

  for (int view = 0; view < view45; view++)
  {
#ifdef PARALLEL
    PMessage msg;
    msg << FNID_RPC_BACKPROJ_SEG0_VIEW;
    msg << view;
    msg << view45;
    PSubmitJob(msg, false, false, false, true); // wait, confirm
#else
    RPC_backproj_seg0_view(image_x, y, view, view45);
#endif // PARALLEL
  };

  for (int segment_num = 1; segment_num <= limit_segments; segment_num++)
  {
    cerr << "Starting to backproject segment pair " << segment_num << endl;

#ifndef PARALLEL
    CPUTimer segment_timer;
    segment_timer.start();
#endif // PARALLEL
    
    for (int view = 0; view <= view45; view++)
    {
      const int             view90 = view45*2;
      const int 	    plus90 = view90+view;
      const int 	    min90  = view90-view;
      const int 	    min180 = (view == 0) ? min90 : view45 * 4 - view;

#ifdef P_INFO
      cout << endl << "  - Getting 8 viewgrams" << endl;
#endif // P_INFO
      
      PETViewgram pos_view   = proj_dat.get_viewgram_copy(view, segment_num);
      PETViewgram neg_view   = proj_dat.get_viewgram_copy(view, -segment_num);
      PETViewgram pos_plus90 = proj_dat.get_viewgram_copy(plus90, segment_num);
      PETViewgram neg_plus90 = proj_dat.get_viewgram_copy(plus90, -segment_num);
      
      // KT 21/05/98 just read these viewgrams for view=0 || view45 as well
      // otherwise, some assert() things break in the backprojector
      //   cout <<"  - Getting other 4 viewgrams"  << endl;
      PETViewgram pos_min90  = proj_dat.get_viewgram_copy(min90, segment_num);
      PETViewgram neg_min90  = proj_dat.get_viewgram_copy(min90, -segment_num);
      PETViewgram pos_min180 = proj_dat.get_viewgram_copy(min180, segment_num); 
      PETViewgram neg_min180 = proj_dat.get_viewgram_copy(min180, -segment_num);
      
      if (pos_view.get_num_bins() % 2 == 0)
      {
	int min_bin_orig = pos_view.get_min_bin();
	int max_bin_orig = pos_view.get_max_bin();
	  
	pos_view.grow_width(min_bin_orig,  max_bin_orig + 1);
	neg_view.grow_width(min_bin_orig,  max_bin_orig + 1);
	pos_plus90.grow_width(min_bin_orig,  max_bin_orig + 1);
	neg_plus90.grow_width(min_bin_orig,  max_bin_orig + 1);
	pos_min180.grow_width(min_bin_orig,  max_bin_orig + 1);
	neg_min180.grow_width(min_bin_orig,  max_bin_orig + 1);
	pos_min90.grow_width(min_bin_orig,  max_bin_orig + 1);
	neg_min90.grow_width(min_bin_orig,  max_bin_orig + 1);
      };

#ifndef PARALLEL
	  
      if (view != 0 && view != view45)
      {
	RPC_backproj_8_viewgrams(image_x,
				 pos_view, neg_view,
				 pos_plus90, neg_plus90,
				 pos_min180, neg_min180,
				 pos_min90, neg_min90);
      }
      else
      {
	RPC_backproj_4_viewgrams(image_x,
				 pos_view, neg_view,
				 pos_plus90, neg_plus90);
      };

#else // PARALLEL

      PMessage msg;

      if (view != 0 && view != view45)
	msg << FNID_RPC_BACKPROJ_8_VIEWGRAMS;
      else
	msg << FNID_RPC_BACKPROJ_4_VIEWGRAMS;
      
      msg << bool(true); // projection data follows
      
      msg << pos_view;
      msg << neg_view;
      msg << pos_plus90;
      msg << neg_plus90;
      
      if (view != 0 && view != view45)
      {
	msg << pos_min90;
	msg << neg_min90;
	msg << pos_min180;
	msg << neg_min180;
      };

      msg << bool(false); // no binwise_correction

      PSubmitJob(msg, false, false, false, true); // wait, confirm

#endif // PARALLEL

    };
  };
  
#ifdef PARALLEL    
  {
#ifdef P_INFO
    cout << "Master: getting the images back" << endl;
#endif // P_INFO

    PMessage msg;
    msg << FNID_RPC_RETURN_IMAGE_AND_F;
    PSubmitJob(msg, false, true, true, false); // wait, noconfirm
    PEnv.Reduce(image_x, ReductionAdd<PETImageOfVolume>());

#ifdef P_INFO
    cout << "Master: finished getting the images back" << endl;
#endif // P_INFO
  };
#endif //PARALLEL  

};  

// AZ 07/10/99: added

void distributable_compute_sensitivity_image(PETImageOfVolume& result,
					     const PETSinogramOfVolume& s3d,
					     PETImageOfVolume& attenuation_image,
					     const bool do_attenuation,
					     const int subset_num,
					     const int num_subsets,
					     const int min_segment,
					     const int max_segment,
					     bool zero_seg0_end_planes,
					     PETSinogramOfVolume* multiplicative_sinogram /* = NULL */)
{
  result = attenuation_image.get_empty_copy();

  float dummy;

  distributable_compute_gradient(attenuation_image,
				 result,
				 &s3d,
				 subset_num,
				 num_subsets,
				 s3d.get_num_views() / 4,
				 min_segment,
				 max_segment,
				 zero_seg0_end_planes,
				 (do_attenuation ? &dummy : NULL),
				 multiplicative_sinogram);

};





void distributable_accumulate_loglikelihood(const PETImageOfVolume& lambda,
				    const PETSinogramOfVolume* proj_dat,
				    int subset_num, int num_subsets,
				    int view45, int min_segment, int max_segment,
				    bool zero_seg0_end_planes,
				    float* f /* = NULL */,
				    PETSinogramOfVolume* binwise_correction /* = NULL */)
{
  // AZ 06/10/99: added assertion

  assert(min_segment >= 0 && min_segment <= max_segment);

  // AZ 05/10/99: added assertion

  assert(proj_dat != NULL);

#ifdef P_INFO
  cout << "Processing segments " << min_segment << ".." << max_segment << endl;
#endif // P_INFO


  if (f != NULL)
  {
    (*f) = 0.0;
  };
  
#ifdef PARALLEL    
  {
#ifdef P_INFO
    cout << "Master: broadcasting the images" << endl;
#endif // P_INFO

    PMessage msg;
    msg << FNID_RPC_INIT;
    msg << lambda;
    // AZ 11/02/99 Commented out
    msg << bool(f != NULL); // Update f?
    msg << zero_seg0_end_planes;
    PEnv.BroadcastMessage(msg); // nowait, noconfirm

#ifdef P_INFO
    cout << "Master: finished broadcasting the images" << endl;
#endif // P_INFO
  };
#else // not PARALLEL
  RPC_slave_sens_zero_seg0_end_planes = zero_seg0_end_planes;
#endif //PARALLEL
        
  // first do segment 0

  if (min_segment == 0) // AZ 06/10/99 added
  {
    
#ifndef PARALLEL
    CPUTimer segment_timer;
    segment_timer.start();
#endif // PARALLEL
    
    PETSegmentBySinogram* binwise_correction_seg0 =
      (binwise_correction == NULL) ? NULL : new PETSegmentBySinogram(binwise_correction->get_segment_sino_copy(0));

    PETSegmentBySinogram* y = NULL;

#ifdef PARALLEL
    if (subset_num == 0)
    {
#endif // PARALLEL

    if (proj_dat != NULL)
    {
      cerr << endl << "Now reading data for segment #: 0 " << endl;
      y = new PETSegmentBySinogram(proj_dat->get_segment_sino_copy(0));
      cerr << "Read data for segment #: 0" << endl;
    };

    if (zero_seg0_end_planes)
      {
	cerr << "\nZeroing end-planes of segment 0" << endl;

        if (y != NULL)
	{
	  (*y)[y->get_min_ring()].fill(0);
	  (*y)[y->get_max_ring()].fill(0);
	};

	if (binwise_correction_seg0 != NULL)
	{
	  (*binwise_correction_seg0)[binwise_correction_seg0->get_min_ring()].fill(0);
	  (*binwise_correction_seg0)[binwise_correction_seg0->get_max_ring()].fill(0);
	};
      };

    if (y != NULL &&
	y->get_num_bins() % 2 == 0)
    {
      y->grow_width(y->get_min_bin(), y->get_max_bin() + 1);
    };

    if (binwise_correction_seg0 != NULL &&
	binwise_correction_seg0->get_num_bins() % 2 == 0)
    {
      binwise_correction_seg0->grow_width(binwise_correction_seg0->get_min_bin(),
					  binwise_correction_seg0->get_max_bin() + 1);
    };

#ifdef PARALLEL
#ifdef P_INFO
    cout << "Master: broadcasting data for segment 0" << endl;
#endif // P_INFO
    PMessage msg;
    msg << FNID_RPC_INIT_SEG0_DATA;
    msg << bool(y != NULL);
    if (y != NULL)
    {
      msg << (*y);
    };
    msg << bool(binwise_correction != NULL);
    if (binwise_correction != NULL)
    {
      msg << (*binwise_correction_seg0);
    };
//      PEnv.BroadcastMessage(msg); // nowait, confirm
    PSubmitJob(msg, false, true, false, false); // true);
#ifdef P_INFO
    cout << "Master: finished broadcasting data for segment 0" << endl;
#endif // P_INFO
    };
#endif // PARALLEL

    int count=0, count2=0;
    
    for (int view = subset_num; view < view45; view += num_subsets)
    {
      
      //num_processed_views++;

#ifdef PARALLEL
      PMessage msg;
      msg << FNID_RPC_ACCUMULATE_LOGLIKELIHOOD_SEG0_VIEW;
      msg << view;
      msg << view45;
      PSubmitJob(msg, false, false, false, true); // wait, confirm
#else
      RPC_accumulate_loglikelihood_seg0_view(lambda, y, view, view45, f, binwise_correction_seg0);
#endif // PARALLEL
    }

    if (binwise_correction_seg0 != NULL)
    {
      delete binwise_correction_seg0;
      binwise_correction_seg0 = NULL;
    };

#ifndef PARALLEL

    cerr << "Segment " << 0 << ": " << segment_timer.value() << "secs " <<endl;

#endif // PARALLEL
    
    delete y;
  }  

  //int num_processed_segments = 1;//Get rid of this later 
  
  // now do a loop over the other segments

  for (int segment_num = ((min_segment == 0) ? 1 : min_segment); segment_num <= max_segment; segment_num++){
    
     cerr << "Starting to process segment pair " << segment_num << endl;

#ifndef PARALLEL
    CPUTimer segment_timer;
    segment_timer.start();
#endif // PARALLEL
    

    for (int view=subset_num; view <= view45; view += num_subsets) {

      //if (view == 0 || view == view45) continue; //TODO: Remove this!!! -- FOR DEBUGGING ONLY

#ifndef PARALLEL
      //CPUTimer view_timer;
      //view_timer.start();
#endif // PARALLEL

      //num_processed_views++; //get rid of this later

      const int             view90 = view45*2;
      const int 	    plus90 = view90+view;
      const int 	    min90  = view90-view;
      const int 	    min180 = (view == 0) ? min90 : view45 * 4 - view;

      PETViewgram* pos_view   = NULL;
      PETViewgram* neg_view   = NULL;
      PETViewgram* pos_plus90 = NULL;
      PETViewgram* neg_plus90 = NULL;
      PETViewgram* pos_min90  = NULL;
      PETViewgram* neg_min90  = NULL;
      PETViewgram* pos_min180 = NULL;
      PETViewgram* neg_min180 = NULL;

      if (proj_dat != NULL)
      {

#ifdef P_INFO
	cout << endl << "  - Getting 8 viewgrams" << endl;
#endif // P_INFO
      
	pos_view   = new PETViewgram(proj_dat->get_viewgram_copy(view, segment_num));
	neg_view   = new PETViewgram(proj_dat->get_viewgram_copy(view, -segment_num));
	pos_plus90 = new PETViewgram(proj_dat->get_viewgram_copy(plus90, segment_num));
	neg_plus90 = new PETViewgram(proj_dat->get_viewgram_copy(plus90, -segment_num));
      
	// KT 21/05/98 just read these viewgrams for view=0 || view45 as well
	// otherwise, some assert() things break in the backprojector
	//   cout <<"  - Getting other 4 viewgrams"  << endl;
	pos_min90  = new PETViewgram(proj_dat->get_viewgram_copy(min90, segment_num));
	neg_min90  = new PETViewgram(proj_dat->get_viewgram_copy(min90, -segment_num));
	pos_min180 = new PETViewgram(proj_dat->get_viewgram_copy(min180, segment_num)); 
	neg_min180 = new PETViewgram(proj_dat->get_viewgram_copy(min180, -segment_num));
      
	if (pos_view->get_num_bins() % 2 == 0)
	{
	  int min_bin_orig = pos_view->get_min_bin();
	  int max_bin_orig = pos_view->get_max_bin();
	  
	  pos_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	  pos_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	  pos_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	  pos_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	  neg_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	};
      };

      // AZ 03/10/99: added

      PETViewgram* bc_pos_view   = NULL;
      PETViewgram* bc_neg_view   = NULL;
      PETViewgram* bc_pos_plus90 = NULL;
      PETViewgram* bc_neg_plus90 = NULL;
	  
      PETViewgram* bc_pos_min90  = NULL;
      PETViewgram* bc_neg_min90  = NULL;
      PETViewgram* bc_pos_min180 = NULL;
      PETViewgram* bc_neg_min180 = NULL;

      if (binwise_correction != NULL)
	{
	  bc_pos_view   = new PETViewgram(binwise_correction->get_viewgram_copy(view, segment_num));
	  bc_neg_view   = new PETViewgram(binwise_correction->get_viewgram_copy(view, -segment_num));
	  bc_pos_plus90 = new PETViewgram(binwise_correction->get_viewgram_copy(plus90, segment_num));
	  bc_neg_plus90 = new PETViewgram(binwise_correction->get_viewgram_copy(plus90, -segment_num));
	  
	  bc_pos_min90  = new PETViewgram(binwise_correction->get_viewgram_copy(min90, segment_num));
	  bc_neg_min90  = new PETViewgram(binwise_correction->get_viewgram_copy(min90, -segment_num));
	  bc_pos_min180 = new PETViewgram(binwise_correction->get_viewgram_copy(min180, segment_num)); 
	  bc_neg_min180 = new PETViewgram(binwise_correction->get_viewgram_copy(min180, -segment_num));
	 
	  if (bc_pos_view->get_num_bins() % 2 == 0)
	    {
	      int min_bin_orig = bc_pos_view->get_min_bin();
	      int max_bin_orig = bc_pos_view->get_max_bin();
		
	      bc_pos_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_view->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_pos_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_plus90->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_pos_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_min180->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_pos_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	      bc_neg_min90->grow_width(min_bin_orig,  max_bin_orig + 1);
	    }
	}

#ifndef PARALLEL
	  
      if (view != 0 && view != view45)
	{
	  RPC_accumulate_loglikelihood_8_viewgrams(lambda,
				  pos_view, neg_view,
				  pos_plus90, neg_plus90,
				  pos_min180, neg_min180,
				  pos_min90, neg_min90,
				  f,
				  bc_pos_view, bc_neg_view,
				  bc_pos_plus90, bc_neg_plus90,
				  bc_pos_min180, bc_neg_min180,
				  bc_pos_min90, bc_neg_min90);
	}
      else
	{
	  RPC_accumulate_loglikelihood_4_viewgrams(lambda,
				  pos_view, neg_view,
				  pos_plus90, neg_plus90,
				  f,
				  bc_pos_view, bc_neg_view,
				  bc_pos_plus90, bc_neg_plus90);
	};

#else // PARALLEL

      PMessage msg;

      if (view != 0 && view != view45)
        msg << FNID_RPC_ACCUMULATE_LOGLIKELIHOOD_8_VIEWGRAMS;
      else
        msg << FNID_RPC_ACCUMULATE_LOGLIKELIHOOD_4_VIEWGRAMS;

      msg << bool(proj_dat != NULL);

      if (proj_dat != NULL)
      {
	msg << *pos_view;
	msg << *neg_view;
	msg << *pos_plus90;
	msg << *neg_plus90;

	if (view != 0 && view != view45)
	{
	  msg << *pos_min90;
	  msg << *neg_min90;
	  msg << *pos_min180;
	  msg << *neg_min180;
	};
      };

      msg << bool(binwise_correction != NULL);

      if (binwise_correction != NULL)
      {
	msg << *bc_pos_view;
	msg << *bc_neg_view;
	msg << *bc_pos_plus90;
	msg << *bc_neg_plus90;

	if (view != 0 && view != view45)
	  {
	    msg << *bc_pos_min90;
	    msg << *bc_neg_min90;
	    msg << *bc_pos_min180;
	    msg << *bc_neg_min180;
	  };
      };

      PSubmitJob(msg, false, false, false, true); // wait, confirm

#endif // PARALLEL

      delete bc_pos_view;
      delete bc_neg_view;
      delete bc_pos_plus90;
      delete bc_neg_plus90;
      delete bc_pos_min90;
      delete bc_neg_min90;
      delete bc_pos_min180;
      delete bc_neg_min180;
    
      delete pos_view;
      delete neg_view;
      delete pos_plus90;
      delete neg_plus90;
      delete pos_min90;
      delete neg_min90;
      delete pos_min180;
      delete neg_min180;
    };

#ifndef PARALLEL /* Doesn't make much sense for parallel version */

    cerr << "Segment " << segment_num << ": " << segment_timer.value() << "secs " <<endl;

#endif // PARALLEL
   
  }
  
#ifdef PARALLEL    
  {
#ifdef P_INFO
    cout << "Master: getting the partial computations back" << endl;
#endif // P_INFO

    // AZ 10/02/99 Added
    PMessage msg;


  //MJ 03/01/2000  I hope this is right...
  //  msg << FNID_RPC_RETURN_IMAGE_AND_F;
 msg << FNID_RPC_RETURN_F;


//    PEnv.BroadcastMessage(msg); // wait, noconfirm
    PSubmitJob(msg, false, true, true, false);
 
    //MJ 03/01/2000  I hope this is right...
    //   PEnv.Reduce(image_x, ReductionAdd<PETImageOfVolume>());


    if (f != NULL)
    {
      PEnv.Reduce(*f, ReductionAdd<float>());
    };

#ifdef P_INFO
    cout << "Master: finished getting the partial computations back" << endl;
#endif // P_INFO
  };
#endif //PARALLEL  
};


//MJ 03/01/2000 computes the negative of the loglikelihood function (minimization).
void compute_loglikelihood(const PETImageOfVolume& lambda,
			   const PETImageOfVolume& sensitivity_image,
			   const PETSinogramOfVolume* proj_dat,
			   int subset_num, int num_subsets,
			   int view45, int min_segment, int max_segment,
			   bool zero_seg0_end_planes,
			   float* accum,
			   PETSinogramOfVolume* binwise_correction /* = NULL */,
			   float magic_number)
{



  *accum=0.0;

 distributable_accumulate_loglikelihood(lambda,	proj_dat,
				    subset_num, num_subsets,
				    view45, min_segment, max_segment,
				    zero_seg0_end_planes, accum,
				    binwise_correction /* = NULL */);

 *accum/=magic_number;
 PETImageOfVolume temp_image=sensitivity_image;
 temp_image*=lambda;
 // *accum+=temp_image.sum()/num_subsets; 
 cerr<<endl<<"Image Energy="<<temp_image.sum()/num_subsets<<endl;

}




void RPC_accumulate_loglikelihood_seg0_view(const PETImageOfVolume& lambda,
					 PETSegmentBySinogram* y, 
					 int view, int view45, 
					 float* f,
					 PETSegmentBySinogram* binwise_correction) 

{ // AZ 04/10/99 added

  assert(y != NULL);

  // AZ 06/11/98: get rid of copying
  PETSegmentBySinogram y_bar = (*y);
  y_bar.fill(0.0);

  forward_project_2D(lambda, y_bar, view);

  // current convention -- in 2D case forward project view45 and view0
  // together to be consistent with 2D backprojector
  if (view == 0) forward_project_2D(lambda, y_bar, view45);

  // AZ&MJ 03/10/99 added

  if (binwise_correction != NULL)
  {
    y_bar += (*binwise_correction);
  };


  
  //MJ 03/01/2000 adaptation to compute loglikelihood function


 accumulate_loglikelihood(view, (*y), y_bar, rim_truncation_sino, f);


};






// AZ&MJ 03/10/99 Added bc_*
void RPC_accumulate_loglikelihood_4_viewgrams(const PETImageOfVolume& lambda, 
					      PETViewgram* pos_view, PETViewgram* neg_view,
					   PETViewgram* pos_plus90, PETViewgram* neg_plus90,
					   float* f, PETViewgram* bc_pos_view /* = NULL */, 
					   PETViewgram* bc_neg_view /* = NULL */,
					   PETViewgram* bc_pos_plus90 /* = NULL */, 
					   PETViewgram* bc_neg_plus90 /* = NULL */)
{
  // AZ 04/10/99: all these should be non-NULL
  assert(pos_view != NULL && neg_view != NULL && pos_plus90 != NULL && neg_plus90 != NULL);

  // AZ 04/10/99: these should be either all NULL or all non-NULL
  assert((bc_pos_view != NULL && bc_neg_view != NULL && bc_pos_plus90 != NULL && bc_neg_plus90 != NULL) ||
	 (bc_pos_view == NULL && bc_neg_view == NULL && bc_pos_plus90 == NULL && bc_neg_plus90 == NULL));

  PETViewgram pos_bar_view   = pos_view->get_empty_copy();
  PETViewgram neg_bar_view   = neg_view->get_empty_copy();
  PETViewgram pos_bar_plus90 = pos_plus90->get_empty_copy();
  PETViewgram neg_bar_plus90 = neg_plus90->get_empty_copy();

  forward_project(lambda,
		  pos_bar_view, 
		  neg_bar_view, 
		  pos_bar_plus90, 
		  neg_bar_plus90);

  // AZ&MJ 03/10/99 Added

  if (bc_pos_view != NULL)
  {
    pos_bar_view   += (*bc_pos_view);
    neg_bar_view   += (*bc_neg_view);
    pos_bar_plus90 += (*bc_pos_plus90);
    neg_bar_plus90 += (*bc_neg_plus90);
  };
      
  // sinogram division
        
  accumulate_loglikelihood(*pos_view, pos_bar_view, rim_truncation_sino, f);
  accumulate_loglikelihood(*pos_plus90, pos_bar_plus90, rim_truncation_sino, f);
  accumulate_loglikelihood(*neg_view, neg_bar_view, rim_truncation_sino, f);
  accumulate_loglikelihood(*neg_plus90, neg_bar_plus90, rim_truncation_sino, f);
     

};

// AZ&MJ 03/10/99 Added bc_*
void RPC_accumulate_loglikelihood_8_viewgrams(const PETImageOfVolume& lambda,
                             PETViewgram* pos_view,   PETViewgram* neg_view,
	                     PETViewgram* pos_plus90, PETViewgram* neg_plus90,
                             PETViewgram* pos_min180, PETViewgram* neg_min180,
	                     PETViewgram* pos_min90,  PETViewgram* neg_min90,
	                     float* f /* = NULL */,
			     PETViewgram* bc_pos_view   /* = NULL */, 
			     PETViewgram* bc_neg_view   /* = NULL */,
			     PETViewgram* bc_pos_plus90 /* = NULL */, 
			     PETViewgram* bc_neg_plus90 /* = NULL */,
			     PETViewgram* bc_pos_min180 /* = NULL */, 
			     PETViewgram* bc_neg_min180 /* = NULL */,
			     PETViewgram* bc_pos_min90  /* = NULL */, 
			     PETViewgram* bc_neg_min90  /* = NULL */)
{
  // AZ 04/10/99: all these should be non-NULL
  assert(pos_view != NULL && neg_view != NULL && pos_plus90 != NULL && neg_plus90 != NULL &&
	 pos_min180 != NULL && neg_min180 != NULL && pos_min90 != NULL && neg_min90 != NULL);

  // AZ 04/10/99: these should be either all NULL or all non-NULL
  assert((bc_pos_view != NULL && bc_neg_view != NULL && bc_pos_plus90 != NULL && bc_neg_plus90 != NULL &&
	  bc_pos_min180 != NULL && bc_neg_min180 != NULL && bc_pos_min90 != NULL && bc_neg_min90 != NULL) ||
	 (bc_pos_view == NULL && bc_neg_view == NULL && bc_pos_plus90 == NULL && bc_neg_plus90 == NULL &&
	  bc_pos_min180 == NULL && bc_neg_min180 == NULL && bc_pos_min90 == NULL && bc_neg_min90 == NULL));

  PETViewgram pos_bar_view   = pos_view->get_empty_copy();
  PETViewgram neg_bar_view   = neg_view->get_empty_copy();
  PETViewgram pos_bar_plus90 = pos_plus90->get_empty_copy();
  PETViewgram neg_bar_plus90 = neg_plus90->get_empty_copy();
  PETViewgram pos_bar_min90  = pos_min90->get_empty_copy();
  PETViewgram neg_bar_min90  = neg_min90->get_empty_copy();
  PETViewgram pos_bar_min180 = pos_min180->get_empty_copy();
  PETViewgram neg_bar_min180 = neg_min180->get_empty_copy();

  forward_project(lambda,
		  pos_bar_view, 
		  neg_bar_view, 
		  pos_bar_plus90, 
		  neg_bar_plus90, 
		  pos_bar_min180, 
		  neg_bar_min180, 
		  pos_bar_min90, 
		  neg_bar_min90);
      
  // AZ&MJ 03/10/99 Added

  if (bc_pos_view != NULL)
  {
    pos_bar_view   += (*bc_pos_view);
    neg_bar_view   += (*bc_neg_view);
    pos_bar_plus90 += (*bc_pos_plus90);
    neg_bar_plus90 += (*bc_neg_plus90);
    pos_bar_min90  += (*bc_pos_min90);
    neg_bar_min90  += (*bc_neg_min90);
    pos_bar_min180 += (*bc_pos_min180);
    neg_bar_min180 += (*bc_neg_min180);
  };
      
  // sinogram division
        
  accumulate_loglikelihood(*pos_view, pos_bar_view, rim_truncation_sino, f);
  accumulate_loglikelihood(*pos_plus90, pos_bar_plus90, rim_truncation_sino, f);
  accumulate_loglikelihood(*neg_view, neg_bar_view, rim_truncation_sino, f);
  accumulate_loglikelihood(*neg_plus90, neg_bar_plus90, rim_truncation_sino, f);
  accumulate_loglikelihood(*pos_min90, pos_bar_min90, rim_truncation_sino, f);
  accumulate_loglikelihood(*pos_min180, pos_bar_min180, rim_truncation_sino, f);
  accumulate_loglikelihood(*neg_min90, neg_bar_min90, rim_truncation_sino, f);
  accumulate_loglikelihood(*neg_min180, neg_bar_min180, rim_truncation_sino, f);
     
};
