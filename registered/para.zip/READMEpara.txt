This is a collection of files from the PARAPET collaboration.
They were used to parallellise the PARAPET reconstruction software.

PARAPET afterwards released part of its code in a modified version.
This led to the STIR project, see
     http://stir.HammersmithImanet.com
     http://stir.sourceforge.net

This code is based on a C++ library providing an interface to
lower-level parallel libraries developed by Alexey Zverovich.. 
At the time, we used EPX (a proprietary library from Parsytec that
ran only on its machines) and PVM. Some skeleton code for MPI existed 
as well. 

Warning: the PVM code seemed to have a problem on Linux PVM, while it ran
fine on Parsytec PVM. This is probably (hopefully?) a minor thing.

These source files are distributed with the PARAPET license,
which you can find in PARAPETLICENSE.txt

STIR was never parallelised unfortunately. So the current files 
will not work with STIR, but need updating.

You could go about this as follows:

0) read parastrategy*doc

1) edit parablocks.h/.cxx and modify it for new STIR conversions.

Most of this is trivial. For example, Tensor2D<T> is not called Array<2,T>,
PETSinogram is now Sinogram<float>, PETScannerInfo is Scanner etc. 
It looks like the code for  VectorWithOffset needs an easy 
modification using get_data_ptr() etc.

The non-trivial part is in sending objects from a hierarchy to slaves and back.
In particular this is the case for images. In the first PARAPET version, 
we did not have the DiscretisedDensity hierarchy, but a single
PETImageOfVolume class. A quick work-around for this would be to
handle only VoxelsOnCartesianGrid, as that's the only leaf-class in the
hierarchy at the moment anyway.

This work-around would not work for projectors unfortunately (unless
you hard-wire the projector in the code).

Note that some of this stuff could be implemented in terms of
the parsing and parameter_info() (i.e. parameters could be sent as strings,
this string converted to a stream, and the objects can then be parsed from 
the stream).


2) expand test_para.cxx (or equivalent) to see if you can successfully
send STIR objects back and forth. (I don't seem to find any test-code
for PARAPET objects, strangely enough).

3) tackle recon_buildblock/distributable.cxx,

An updated, but non-parallel, version of this is in the STIR distribution.
You need to make sure that distributable_computation works in 
the parallel case exactly the same as it does in the serial case.
This is largely a matter of sending the appropriate objects around.

The version of distributable.cxx included worked with our old convention
for projectors. This code needs updating. However, the serial version
should make this easier. In fact, I suspect that the code can
be simplified dramatically as we do no longer need different calls for
segment 0 or 4 or 8 viewgrams, but just use RelatedViewgrams. Also,
statements like 
      grow_width(min_bin_orig,  max_bin_orig + 1);
are not needed anymore and should be deleted. (we required an odd number
of bins at some stage in the development).


For the slaves, you will need to store have a local
version of the projectors (which would be stored by set_projectors...)

4) you likely will have to use rename the main() function to master_main() for 
OSMAPOSL.cxx, such that para_stub.cxx can be used (even though this file
says its obsolete).

5) Once you've done this, you will have parallellised any algorithm
that uses distributable_computation!



You probably will have a lot of trouble with this. With any luck, some of the 
original PARAPET developers can help, in particular Alexey Zverovich and
Mustpha Sadki. Send email to the stir-devel mailing list. If Alexey nor
Mustapha reply, I can always try to find out where they are now.


Kris Thielemans
27 July 2005